﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BottompointsTest
{


    public partial class Form1 : Form
    {
        // data container, temporary server
        string[] server = new string[600];

        public string Code { get; set; }
        public string Name { get; set; }
        public string currentPrice;      // for receiving data splited from the real time data
        int price;
        int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        int bLocation = 0;                  // location of bottomPoints
        int waveFlag = 0;                       // flag for bottomPoints
        int strategicFlag;
        bool orderSent;                 // check if order is sent at the third bottom point.
        int timePassed;

        string e_srealData;
        string e_srealKey;

        //private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI02;

        List<string[]> listFromServer = new List<string[]>();       // container for real time data from Kiwoom Server.


        public Form1()
        {
            InitializeComponent();

            bottomPoints = new int[2, 1000];
            bottomPoints[0, 0] = 1000000;
            timePassed = 0;

            strategicFlag = 0;

            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;

            btnTR.Click += ButtonClick;
            btnBottompointsTest.Click += ButtonClick;
            btnStrategy.Click += ButtonClick;

            Start();


            axKHOpenAPI1.CommConnect();
        }

        public void Start()
        {
            Console.WriteLine("start");

            // Bottompoints test
            // step1 : collect chart data
            // step2 : apply bottompoints function for the data

            // step3 : find third wave
            // step4 : notify
        }


        // Find bottom Points to send order of buying. if lower price found, send the data to bottomPoints      
        // step 1 : compare the previous value with newly evented value
        // step 2 : if(true) insert the value, if not desert the value
        // step 3 : if(third bottom found) send order of buying stock.
        public void BottomPoints()
        {

            //Console.WriteLine($"Stock code : { this.Code }, Stock name : {this.Name}");

            // step 1 : compare the previous value with newly evented value
            int previous = bottomPoints[0, bLocation];  // extract data from in the bottomPoints
            int newly = this.price;                // extract data from the Kiwoom server

            //Console.WriteLine($"bottomPoints[0, {bLocation}] : {bottomPoints[0, bLocation]} ; 현재가 : {newly}, ;;; ");
            //Console.WriteLine($"flag : {flag}, (currentTime - bottomFoundTime).TotalSeconds : {(currentTime - bottomFoundTime).TotalSeconds}");
            //Console.WriteLine($"bottomFoundTime :{bottomFoundTime} ;; currentTime : {currentTime}");

            Compare(previous, newly, this.bLocation);        // compare A with B

            //Console.WriteLine("Comparing??");

            // step 2 : if(true) insert the value, if not desert the value ;  insert function called from compare function

            // step 3 : if(third bottom found) send order of buying stock. : check if third bottomPoint is found

            if (BuyingCondition())       //BuyingCondition()
            {
                //send_buying_order  here
                SendOrder_Buy(this.Code);
            }
        }

        public void Compare(int previous, int newly, int bLoc)
        {
            if (previous > newly)
            {
                // step 2 of BottomPoints : if(true) insert the value, if not desert the value
                // next bottom point
                string str = comboTiming.Text;
                int time = int.Parse(str);

                if (time < timePassed)          //  1 minutes. 
                {
                    this.bLocation++;

                    //Console.WriteLine($"bLocation : {bLocation}");
                    //Console.WriteLine($"currentTime - bottomFoundTime : {(currentTime - bottomFoundTime).TotalSeconds} 초");

                    // Register previous bottom information
                    Insert(0, this.bLocation, newly);
                    waveFlag++;

                    Console.WriteLine("inserted waveFlag++");
                    //bottomFoundTime = DateTime.Now;               //((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                }
                else
                {
                    Insert(0, bLoc, newly);
                    Console.WriteLine("inserted just");
                }

                timePassed = 0;
            }
            else
            {
                timePassed++;


            }

            Console.WriteLine($"waveflag : {waveFlag}");
        }

        public void Insert(int vertical, int location, int value)
        {
            this.bottomPoints[vertical, location] = value;
        }

        // algorithm for best buying condition
        public bool BuyingCondition()
        {
            string str = comboTiming.Text;
            int strategictime = int.Parse(str);

            string str2 = comboWave.Text;
            strategicFlag = int.Parse(str2);

            if (waveFlag == strategicFlag)
            {
                waveFlag = 0;
            }

            if (waveFlag == strategicFlag && orderSent == false && (timePassed > strategictime))
            {
                orderSent = true;

                return true;
            }
            else
            {
                return false;
            }
        }

        public void SendOrder_Buy(string code)
        {
            Console.WriteLine("매수 주문 요청 성공");


            //int result = axKHOpenAPI1.SendOrder("주식주문", "1001", "8008765411", 1, code, 1, 20000, "03", null);

            //if (result == 0)
            //{
            //Console.WriteLine("매수 주문 요청 성공");
            //}

        }

        public void initialize()
        {
            bottomPoints[0, 0] = 1000000;
            bLocation = 0;
            waveFlag = 0;
        }


        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {


            //if (e.sRQName == "일봉차트")
            //{
            int nCnt = axKHOpenAPI1.GetRepeatCnt("opt10081", "일봉차트");
            string strData1 = "";
            string strData2 = "";
            string strData3 = "";
            string strData4 = "";
            string strData5 = "";

            for (int nIdx = 0; nIdx < nCnt; nIdx++)
            {
                strData1 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "거래량").Trim(); // nIdx번째의 거래량 데이터 구함
                strData2 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "일자").Trim();
                strData5 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "현재가").Trim();


                //Console.WriteLine($"거래량 : {strData1}");
                //Console.WriteLine(strData2);
                //Console.WriteLine(strData3);
                //Console.WriteLine(strData4);
                //Console.WriteLine(strData5);

                server[nCnt - nIdx - 1] = strData5;
                //Console.WriteLine($"{strData5}  filled");

            }

            for (int i = 0; i < nCnt; i++)
            {
                Console.WriteLine($"{server[i]}  filled");
            }

        }

        public void ButtonClick(object sender, EventArgs e)
        {
            if (sender.Equals(btnTR))
            {
                //step1: collect chart data from onreceiveTRdata

                axKHOpenAPI1.SetInputValue("종목코드", "000020");

                //기준일자 = YYYYMMDD(20160101 연도4자리, 월 2자리, 일 2자리 형식)

                axKHOpenAPI1.SetInputValue("기준일자", "");

                //수정주가구분 = 0 or 1, 수신데이터 1:유상증자, 2:무상증자, 4:배당락, 8:액면분할, 16:액면병합, 32:기업합병, 64:감자, 256:권리락

                axKHOpenAPI1.SetInputValue("수정주가구분", "");

                Console.WriteLine($"result : {axKHOpenAPI1.CommRqData("일봉차트", "opt10081", 0, "1001")}");
            }

            else if (sender.Equals(btnBottompointsTest))
            {
                initialize();

                // step2 : apply bottompoints function for the data
                for (int i = 0; i < 600; i++)
                {
                    price = int.Parse(server[i]);
                    Console.WriteLine(server[i]);
                    BottomPoints();

                    Console.WriteLine($"bottomPoints[0,{bLocation}]  :  {bottomPoints[0, bLocation]} {i}");
                }

            }

            else if (sender.Equals(btnStrategy))
            {
                comboWave.Text = "3";
                comboTiming.Text = "10";
            }

        }
    }
}
