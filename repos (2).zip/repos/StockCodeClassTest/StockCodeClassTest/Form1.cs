﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockCodeClassTest
{
    public partial class Form1 : Form
    {
        string currentPrice;      // for receiving data splited from the real time data

        Stock stock;
        Stock[] stockArray;    
        Filter filter01;       
        Group group01;

        public Form1()
        {
            InitializeComponent();
 
            Init();
            Start();
        }

        public void Init()
        {
           
            filter01 = new Filter(this);
            group01 = new Group();

            loginButton.Click += Button_Click;
 
            //substep 1 :  send "setrealreg" function of codeList to the server.
            realDataButton.Click += Button_Click;

            // background event (system event) for real time data from Kiwoom Server.
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;

            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
        }

        public void StaticStrategyTest(Group group01)
        {
            // step 1 Call the code information list(second.txt)
            // step 2 Filter the code information list according to the strategy
            // step 3 Check some elements(e.g. number of stock list.)

            Console.WriteLine($"===============Count of codelist : { group01.codeList.Count}");
        }


        public void Start()
        {
        }

        // Distribute each code and price to each object.
        public void distribute(Stock stock, string code, string name, string curPrice)
        {
            stock.Code = code;
            stock.Name = name;
            stock.currentPrice = curPrice;
            stock.GetTheChance();
        }

        // call "first.txt"
        // build filtered Stock Array
        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
            {
                //Filter filter = new Filter();
                // step 1 Filter the codelist from "first.txt"
                var allCodesInfo = filter01.Start01();                                     // csv data filtering

                // step 2 Group the code list                                               // filtered csv data grouping; called from Filter.CsvToList()
                group01 = filter01.GroupProducer(allCodesInfo, 300);

                // step 3 observe one code of market items


                /**************************************
                *****************************************/
                
                int length = group01.codeList.Count;

                stockArray = new Stock[length];

                for (int i = 0; i < length; i++)
                {
                    stockArray[i] = new Stock(this, group01.codeList[i]);

                    Console.WriteLine($"Stock Code : {stockArray[i].Code}");
                }
                /**************************************
                *****************************************/
                int j = axKHOpenAPI1.CommConnect();

                if (j == 0)
                {
                    Console.WriteLine("Login success");
                }
            }

            // send "SetRealReg"
            else if (sender.Equals(realDataButton))
            {
                Console.WriteLine("real data button");
                string codeList = "";

                foreach (string str in group01.codeList)
                {
                    codeList = codeList + str + ";";
                }

                char[] toTrim = { ';' };
                codeList = codeList.TrimEnd(toTrim);

                Console.WriteLine("codeList : " + codeList);

                int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server               
                if (result == 0)
                {
                    Console.WriteLine("setRealReg 요청 성공");
                }
                else
                {
                    Console.WriteLine("주식기본 정보 요청에 실패하였습니다.");
                }
            }
        }

        // Distribute each code(group01.filteredCodeList) to each object(StockCode class) to find best condition and send order
        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            Console.WriteLine("          ");
            Console.WriteLine("+++++++++++ real data received +++++++++++");
            for (int i = 0; i < group01.codeList.Count; i++)
            {
                if (e.sRealKey == group01.codeList[i])
                {
                    // data splited from the real time data
                    currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가

                    distribute( stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice );
                }
            }
        }

        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            /**
            logListBox.Items.Add("e.nitemCnt : " + e.nItemCnt);
            logListBox.Items.Add("e.sFIdList : " + e.sFIdList);
            logListBox.Items.Add("e.sGubun : " + e.sGubun);

            if (e.sGubun.Equals("0"))       // 접수 or 체결
            {
                string account = axKHOpenAPI1.GetChejanData(9201);
                string orderNumber = axKHOpenAPI1.GetChejanData(9203);
                string orderState = axKHOpenAPI1.GetChejanData(913);        // 접수 or 체결

                if (orderState.Equals("접수"))
                {
                    logListBox.Items.Add("접수 호출");
                }

                else if (orderState.Equals("체결"))
                {
                    logListBox.Items.Add("체결 호출");
                }

                logListBox.Items.Add("Jesus");
            }

            else if (e.sGubun.Equals("1"))  // 잔고
            {

            }

            else if (e.sGubun.Equals("4"))  // 파생잔고
            {

            }

            **/

        }



    }

    // Class for each stock  to find bottom points and to send order
    public class Stock
    {
        Form1 form01;

        public string Code { get; set; }
        public string Name { get; set; }
        public string currentPrice;      // for receiving data splited from the real time data
        int price;        
        int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        int bLocation = 0;                  // location of bottomPoints
        int flag =0;                       // flag for bottomPoints
        bool orderSent;                 // check if order is sent at the third bottom point.
        DateTime bottomFoundTime;
        DateTime currentTime;             // to compare the current time with elapsed time

        string e_srealData;
        string e_srealKey;

        //private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI02;

        List<string[]> listFromServer = new List<string[]>();       // container for real time data from Kiwoom Server.

        public Stock()
        {
        }

        public Stock(Form1 form, string stockCode)
        {
            form01 = form;
            this.Code = stockCode;

            bottomFoundTime = DateTime.Now;      // ((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
            bottomPoints = new int[2, 1000];
            bottomPoints[0, 0] = 1000000;            
        }

        public Stock(string code, string name)
        {
            e_srealData = code;
            e_srealKey = name;         
        }

        public void GetTheChance()
        {
            //DateTime currentTime; // to compare the current time with elapsed time         
            this.currentTime = DateTime.Now;


            // remove "-" 
            this.currentPrice = currentPrice.Trim();
            this.price = int.Parse(currentPrice);
            this.price = Math.Abs(price);

            this.BottomPoints();    // Find bottom Points to send order of buying. if found, send the data to bottomPoints 
        }

        // Find bottom Points to send order of buying. if lower price found, send the data to bottomPoints      
        // step 1 : compare the previous value with newly evented value
        // step 2 : if(true) insert the value, if not desert the value
        // step 3 : if(third bottom found) send order of buying stock.
        public void BottomPoints()
        {
            Console.WriteLine($"Stock code : { this.Code }, Stock name : {this.Name}");

            // step 1 : compare the previous value with newly evented value
            int previous = bottomPoints[0, bLocation];  // extract data from in the bottomPoints
            int newly = this.price;                // extract data from the Kiwoom server

            Console.WriteLine($"bottomPoints[0, {bLocation}] : {bottomPoints[0, bLocation]} ; 현재가 : {newly}, ;;; ");
                

            Console.WriteLine($"flag : {flag}, (currentTime - bottomFoundTime).TotalSeconds : {(currentTime - bottomFoundTime).TotalSeconds}");

            Console.WriteLine($"bottomFoundTime :{bottomFoundTime} ;; currentTime : {currentTime}");


            Compare(previous, newly, this.bLocation);        // compare A with B

            // step 2 : if(true) insert the value, if not desert the value ;  insert function called from compare function

            // step 3 : if(third bottom found) send order of buying stock. : check if third bottomPoint is found

            if (BuyingCondition())       //BuyingCondition()
            {
                //send_buying_order  here
                SendOrder_Buy(this.Code);
            }

            if (5 == 5)       //BuyingCondition()
            {
                //send_buying_order  here
                //SendOrder_Sell(this.Code);
            }
        }

        public void Compare(int previous, int newly, int bLoc)
        {
            if (previous > newly)
            {
                // step 2 of BottomPoints : if(true) insert the value, if not desert the value
                // next bottom point
                if ((currentTime - bottomFoundTime).TotalSeconds >= 60)          //  1 minutes. 
                {
                    this.bLocation++;

                    Console.WriteLine($"bLocation : {bLocation}");

                    Console.WriteLine($"currentTime - bottomFoundTime : {(currentTime - bottomFoundTime).TotalSeconds} 초");

                    // Register previous bottom information
                    flag++;
                    Insert(0, this.bLocation, newly);

                    bottomFoundTime = DateTime.Now;               //((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                }
                else
                {
                    Insert(0, bLoc, newly);
                }
            }
            else
            {

            }
        }

        public void Insert(int vertical, int location, int value)
        {
            this.bottomPoints[vertical, location] = value;
        }

        // algorithm for best buying condition
        public bool BuyingCondition()
        {
            if (flag == 2 && orderSent == false && (currentTime - bottomFoundTime).TotalSeconds >= 60)
            {
                orderSent = true;
                flag = 0;

                return true;
            }
            else
            {
                return false;
            }
        }

        public bool SellingCondition()
        {
            if (9 == 9)
            {
                return true;
            }

            else
            {
                //return false;
            }
        }

        public void SendOrder_Buy(string code)
        {
            int result = form01.axKHOpenAPI1.SendOrder("주식주문", "1001", "8008765411", 1, code, 1, 20000, "03", null);

            if (result == 0)
            {
                Console.WriteLine("매수 주문 요청 성공");
            }
        }

        public void SendOrder_Sell(string code)
        {
            int result = form01.axKHOpenAPI1.SendOrder("주식주문", "1001", "8008765411", 2, code, 1, 20000, "03", null);

            if (result == 0)
            {
                Console.WriteLine("매도 주문 요청 성공");
            }
        }

        String[,] totalTrade;

        /**
        //Step 2 function
        private void Send_Order_Buying(string rqname, string scrNum, string accNum, int orderType, string itemCodee, int quantity, int price, string trType, string ori_Num)
        {
            // Send order to the server
            //int result = axKHOpenAPI02.SendOrder(rqname, scrNum, accNum, orderType, itemCodee, quantity, price, trType, ori_Num);

            //int result = axKHOpenAPI1.SendOrder(items.rqname, items.scrNum, items.accNum, items.orderType, items.itemCode, items.quantity, items.price, items.trType, items.ori_Num);
            if (result == 0)       // 요청성공
            {
                Console.WriteLine("주문요청 성공");
            }
            else    // sendOrder failed
            {
            }
        }
        **/

    }

    // Filter the fundamental information of stocks, for example, 영업이익, 자본금, EPS from all the market stocks.
    public class Filter
    {
        

        List<CodeInfo> allCodesInfo;

        Form1 form1;

        public Filter(Form1 form)
        {
            this.form1 = form;
        }

        public List<CodeInfo> Start01()
        {
            // csv file open into memory
            string[] csv = File.ReadAllLines("first.txt");

            // filter the csv file into List<class>
            allCodesInfo = CsvToList(csv);
            return allCodesInfo;
        }

        public List<CodeInfo> CsvToList(string[] csvLines)                    // filter to classList
        {
            allCodesInfo = new List<CodeInfo>();     // code object with fundamental information

            for (int i = 0; i < csvLines.Length; i++)
            {
                string[] rowdata = csvLines[i].Split(',');

                CodeInfo codeInfo = new CodeInfo(csvLines[i]);
                allCodesInfo.Add(codeInfo);
            }

            return allCodesInfo;
        }

        public Group GroupProducer(List<CodeInfo> allInfo, int capitalCondition)
        {
            var group01 = new Group();

            group01.codeList = new List<string>();
            group01.codeName = new List<string>();

            foreach (CodeInfo codeInfo in allInfo)
            {
                if (codeInfo.capital == "자본금")          // csv header data skipped.
                    continue;
                int num = int.Parse(codeInfo.capital);
                if (num >= capitalCondition)
                {
                    //Console.WriteLine(num);
                    string str = num.ToString();
                    group01.codeList.Add(codeInfo.code);
                    group01.codeName.Add(codeInfo.name);

                    Console.WriteLine("codeinfo");
                    Console.WriteLine("codeInfo.code : " + codeInfo.code);
                    Console.WriteLine("codeInfo.name : " + codeInfo.name);
                }
            }

            form1.StaticStrategyTest(group01);

            return group01;
        }
    }

    // Information for each code
    public class CodeInfo
    {
        public string code;
        public string name;
        public string capital;
        public string volume;
        public string profit;

        public CodeInfo(string rowData)
        {
            string[] rowInfo = rowData.Split(',');

            this.code = rowInfo[0];
            this.name = rowInfo[1];
            this.capital = rowInfo[2];
            this.volume = rowInfo[3];
            this.profit = rowInfo[4];
        }
    }

    public class Group
    {
        public List<string> codeList = new List<string>();
        public List<string> codeName = new List<string>();

        public Group()
        {

        }

        public Group(List<string> codeList, List<string> codeName)
        {
            this.codeList = codeList;
            this.codeName = codeName;
        }

        public class GroupType
        {

        }
    }


}
