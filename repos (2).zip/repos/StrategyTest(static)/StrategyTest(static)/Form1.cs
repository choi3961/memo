﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StrategyTest_static_
{
    public partial class Form1 : Form
    {
        string currentPrice;      // for receiving data splited from the real time data
        string[,] totalTrade;

        int screenNumber;

        Stock stock;
        Stock[] stockArray;
        Filter filter01;
        Group group01;

        public Form1()
        {
            InitializeComponent();

            Init();

            //StaticStrategyTest();
        }


        public void Init()
        {
            filter01 = new Filter(this);
            //stock = new Stock();
            group01 = new Group();

            loginButton.Click += Button_Click;

            //substep 1 :  send "setrealreg" function of codeList to the server.
            realDataButton.Click += Button_Click;

            // Sell All the stocks
            btnSellAll.Click += Button_Click;

            //Strategy Button
            btnStrategy01.Click += StrButton_Click;

            // background event (system event) for real time data from Kiwoom Server.
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;

            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;

            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
        }

        public void StaticStrategyTest(Group group01)
        {
            // step 1 Call the code information list(second.txt)
            // step 2 Filter the code information list according to the strategy
            // step 3 Check some elements(e.g. number of stock list.)

            //Console.WriteLine($"Count of codelist : { group01.codeList.Count}");
            logListBox.Items.Add($"Count of codelist : { group01.codeList.Count}");
        }

        // Distribute each code and price to each object.
        public void distribute(Stock stock, string code, string name, string curPrice)
        {
            stock.Code = code;
            stock.Name = name;
            stock.currentPrice = curPrice;

            try
            {
                stock.GetTheChance();
            }

            catch
            {
                logListBox.Items.Add("exception occured");
            }

            finally
            {
                string codeList = "";

                foreach (string str in group01.codeList)
                {
                    codeList = codeList + str + ";";
                }

                char[] toTrim = { ';' };
                codeList = codeList.TrimEnd(toTrim);
                int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");
            }
        }

        public void SendOrder_Sell(string code, string executionPrice)
        {
            double temp = double.Parse(executionPrice);

            double sellingPrice = temp + (temp * 0.01);

            logListBox.Items.Add(code);

            int result = axKHOpenAPI1.SendOrder("주식주문", "1003", "8008765411", 2, code, 1, (int)sellingPrice, "00", null);

            if (result == 0)
            {
                logListBox.Items.Add($"매도 주문 요청 성공 : {code}, 매도 가격: {sellingPrice}");
            }
        }

         //Sell All the stocks in once.
        public void SellAllStocks(List<string> stockcodes)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {
                //Console.WriteLine($"sell a stock {i}, {stockcodes[i]}, {GetScreenNumber()}");

                int result = axKHOpenAPI1.SendOrder("매도주문", GetScreenNumber(), "8008765411", 2, stockcodes[i], 1, 0, "03", null);     //("매도주문", GetScreenNumber(), "8008765411", 2, stockcodes[i], 1, 0, "03", null);

                if (result != 0)
                {
                    Console.WriteLine(result);
                }
                Thread.Sleep(300);
            }

        }

        public string GetScreenNumber()
        {
            if (screenNumber == 9999)
            {
                screenNumber = 1001;
            }
            screenNumber++;

            string str = screenNumber.ToString();

            return str;
        }


        // call "first.txt"
        // build filtered Stock Array
        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
            {
                //Filter filter = new Filter();
                // step 1 Filter the codelist from "first.txt"
                var allCodesInfo = filter01.Start01();                                     // csv data filtering

                // step 2 Group the code list                                               // filtered csv data grouping; called from Filter.CsvToList()
                string str = btnCapitalStr.Text;
                string str02 = btnProfitStr.Text;
                string str03 = btnDebtPortionStr.Text;

                int capital = int.Parse(str);
                int profit = int.Parse(str02);
                int debt = int.Parse(str03);


                group01 = filter01.GroupProducer(allCodesInfo, capital, profit);

                logListBox.Items.Add(capital);
                logListBox.Items.Add($"group01.codeList.Count : {group01.codeList.Count}");

                // step 3 observe one code of market items
                int length = group01.codeList.Count;

                stockArray = new Stock[length];

                for (int i = 0; i < length; i++)
                {
                    stockArray[i] = new Stock(this, group01.codeList[i]);
                }

                int j = axKHOpenAPI1.CommConnect();

                if (j == 0)
                {
                    Console.WriteLine("Login success");
                }
            }

            // send "SetRealReg"
            else if (sender.Equals(realDataButton))
            {
                Console.WriteLine("real data button");
                string codeList = "";

                foreach (string str in group01.codeList)
                {
                    codeList = codeList + str + ";";
                }

                char[] toTrim = { ';' };
                codeList = codeList.TrimEnd(toTrim);

                Console.WriteLine("codeList : " + codeList);

                int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server               
                if (result == 0)
                {
                    Console.WriteLine("setRealReg 요청 성공");
                }
                else
                {
                    Console.WriteLine("주식기본 정보 요청에 실패하였습니다.");
                }
            }

            // check reserved stocks
            else if (sender.Equals(btnSellAll))
            {
                Console.WriteLine("hello  ..");
                // 계좌 평가 현황 요청      // Invoke OnReceiveTrData()
                axKHOpenAPI1.SetInputValue("계좌번호", "8008765411");
                axKHOpenAPI1.SetInputValue("비밀번호", "");
                axKHOpenAPI1.SetInputValue("상장폐지조회구분", "");
                axKHOpenAPI1.SetInputValue("비밀번호입력매체구분", "");
                axKHOpenAPI1.CommRqData("계좌평가현황", "OPW00004", 0, "1000");       // Invoke OnReceiveTrData()
            }
        }

        private void StrButton_Click(object sender, EventArgs e)
        {
            if (sender.Equals(btnStrategy01))
            {
                StrategyStatic strategy01 = new StrategyStatic(2000, 100, 200, 3, 120);

                string capital = strategy01.capital.ToString();
                string profit = strategy01.profit.ToString();
                string debt = strategy01.debt.ToString();
                string wave = strategy01.wave.ToString();
                string timing = strategy01.timing.ToString();

                btnCapitalStr.Text = capital;           // static strategy
                btnProfitStr.Text = profit;             // static strategy
                btnDebtPortionStr.Text = debt;          // static strategy
                comboWave.Text = wave;                  // dynamic strategy
                comboTiming.Text = timing;              // dynamic strategy
            }

            else if (sender.Equals(btnStrategy02))
            {

            }

            else if (sender.Equals(btnStrategy03))
            {

            }

            else if (sender.Equals(btnStrategy04))
            {

            }

            else if (sender.Equals(btnStrategy05))
            {

            }

        }

        // Distribute each code(group01.filteredCodeList) to each object(StockCode class) to find best condition and send order
        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            //Console.WriteLine("          ");
            //Console.WriteLine("+++++++++++ real data received +++++++++++");
            for (int i = 0; i < group01.codeList.Count; i++)
            {
                if (e.sRealKey == group01.codeList[i])
                {
                    // data splited from the real time data
                    currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가

                    distribute(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice);
                }
            }
        }



        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            int stockCount = 0;      // 종목수
            Console.WriteLine("Tr data received");
            string str = axKHOpenAPI1.GetCommData("opw00004", "주식평가현황", 0, "예탁자산평가액");

            Console.WriteLine($"str : {str}");

            int count = axKHOpenAPI1.GetRepeatCnt("opw00004", "계좌평가현황요청");

            Console.WriteLine($"{count} found");

            // if 게좌평가현황요청일 경우

            if (e.sRQName == "계좌평가현황")
            {
                Console.WriteLine("++++++++++++주문 : 계좌평가현황");

                List<string> stocks = new List<string>();

                for (int i = 0; i < count; i++)
                {
                    string code = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, i, "종목코드");

                    code = code.Remove(0, 1).Trim();

                    Console.WriteLine(code);

                    comboReserved.Items.Add(code);
                    stocks.Add(code);



                    Thread.Sleep(300);
                    stockCount = i;
                }

                Console.WriteLine($"{stockCount} Finished");

                // Sell all the stocks
                SellAllStocks(stocks);

            }


            // if 매도 주문일 경우

            else if (e.sRQName == "매도주문")
            {
                Console.WriteLine("++++++++++++주문 : 매도주문");
            }

            //e.



        }



        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {         
            //logListBox.Items.Add("e.nitemCnt : " + e.nItemCnt);
            //logListBox.Items.Add("e.sFIdList : " + e.sFIdList);
            //logListBox.Items.Add("e.sGubun : " + e.sGubun);

            if (e.sGubun.Equals("0"))       // 접수 or 체결
            {
                string account = axKHOpenAPI1.GetChejanData(9201);
                string orderNumber = axKHOpenAPI1.GetChejanData(9203);
                string orderState = axKHOpenAPI1.GetChejanData(913);        // 접수 or 체결

                if (orderState.Equals("접수"))
                {
                    logListBox.Items.Add("접수 호출");
                }

                else if (orderState.Equals("체결"))
                {
                    logListBox.Items.Add("체결 호출");
                    string str = axKHOpenAPI1.GetChejanData(910);
                    string code = axKHOpenAPI1.GetChejanData(9001);
                    string distinguish = axKHOpenAPI1.GetChejanData(907);
                    code = code.Remove(0,1).Trim();

                    logListBox.Items.Add($"매도수 구분 : {distinguish}");

                    //send_selling_order  here if "체결신호 and 매매가 매수 인경우"
                    if (distinguish == "2")
                    {
                        SendOrder_Sell(code, str);
                    }
                    
                }
            }

            else if (e.sGubun.Equals("1"))  // 잔고
            {

            }

            else if (e.sGubun.Equals("4"))  // 파생잔고
            {

            }
        }
    }

    public class StrategyStatic
    {
        public double capital;
        public double profit;
        public double debt;
        public int wave;
        public int timing;

        public StrategyStatic(double cap, double profit, double debt, int wave, int timing)
        {
            this.capital = cap;
            this.profit = profit;
            this.debt = debt;
            this.wave = wave;
            this.timing = timing;
        }
    }

    public class StrategyDynamic
    {
        public string tail;
        public string tradeVolumn;
        public string separation;
        public string timing;
    }

    public class StrategyElements
    {
        public string capital;
        public string profit;
        public string Debt;
         
        public string tail;
        public string tradeVolumn;
        public string separation;
        public string timing;
    }

    // Class for each stock  to find bottom points and to send order
    public class Stock
    {
        Form1 form01;

        //SlopeProducer slopeProducer01;

        

        bool waveSent1 = false;      // temporary
        bool waveSent2 = false;      // temporary
        bool waveSent3 = false;      // temporary


        public int proposedPrice;

        public string Code { get; set; }
        public string Name { get; set; }
        public string currentPrice;      // for receiving data splited from the real time data
        int price;
        int[] slopeTotal;
        int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        int bLocation = 0;                  // location of bottomPoints

        int bTimeLocation = 0;
        int flag = 0;                       // flag for bottomPoints
        bool orderSent;                 // check if order is sent at the third bottom point.
        DateTime bottomFoundTime;
        DateTime currentTime;             // to compare the current time with elapsed time
        DateTime bottomFound;

        string e_srealData;
        string e_srealKey;

        //private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI02;

        List<string[]> listFromServer = new List<string[]>();       // container for real time data from Kiwoom Server.

        public Stock()
        {
        }

        public Stock(Form1 form, string stockCode)
        {
            form01 = form;
            this.Code = stockCode;

            bottomFoundTime = DateTime.Now;      // ((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
            bottomPoints = new int[2, 1000];
            bottomPoints[0, 0] = 1000000;
            bottomPoints[1,0] = 0;
            

            //long first = DateTime.Ticks;

            //bottomPoints[1, 0] = int.Parse(DateTime.Ticks);
        }

        public Stock(string code, string name)
        {
            e_srealData = code;
            e_srealKey = name;
        }

        public void GetTheChance()
        {
            //DateTime currentTime; // to compare the current time with elapsed time         
            this.currentTime = DateTime.Now;

            // remove "-" 
            this.currentPrice = currentPrice.Trim();
            this.price = int.Parse(currentPrice);
            this.price = Math.Abs(price);

            this.BottomPoints();    // Find bottom Points to send order of buying. if found, send the data to bottomPoints 
        }

        // Find bottom Points to send order of buying. if lower price found, send the data to bottomPoints      
        // step 1 : compare the previous value with newly evented value
        // step 2 : if(true) insert the value, if not desert the value
        // step 3 : if(third bottom found) send order of buying stock.
        public void BottomPoints()
        {
            //Console.WriteLine($"Stock code : { this.Code }, Stock name : {this.Name}");

            // step 1 : compare the previous value with newly evented value
            int previous = bottomPoints[0, bLocation];  // extract data from in the bottomPoints
            int newly = this.price;                // extract data from the Kiwoom server

            //Console.WriteLine($"bottomPoints[0, {bLocation}] : {bottomPoints[0, bLocation]} ; 현재가 : {newly}, ;;; ");
            //Console.WriteLine($"flag : {flag}, (currentTime - bottomFoundTime).TotalSeconds : {(currentTime - bottomFoundTime).TotalSeconds}");
            //Console.WriteLine($"bottomFoundTime :{bottomFoundTime} ;; currentTime : {currentTime}");

            Compare(previous, newly, this.bLocation);        // compare A with B

            // step 2 : if(true) insert the value, if not desert the value ;  insert function called from compare function

            // step 3 : if(third bottom found) send order of buying stock. : check if third bottomPoint is found

            if (BuyingCondition())       //BuyingCondition()
            {
                //send_buying_order  here
                SendOrder_Buy(this.Code, proposedPrice);
            }
        }



        public void Compare(int previous, int newly, int bLoc)
        {
            if (previous > newly)
            {
                // step 2 of BottomPoints : if(true) insert the value, if not desert the value
                // next bottom point
                string str = form01.comboTiming.Text;
                int totalSeconds = int.Parse(str);

                double timespan = (currentTime - bottomFoundTime).TotalSeconds;

                int timepassed = (int)timespan;

                if (timespan >= totalSeconds)          //  1 minutes. 
                {
                    this.bLocation++;

                    //Console.WriteLine($"bLocation : {bLocation}");
                    //Console.WriteLine($"currentTime - bottomFoundTime : {(currentTime - bottomFoundTime).TotalSeconds} 초");

                    // Register previous bottom information
                    flag++;
                    Insert(0, this.bLocation, newly);

                    Insert(1, this.bLocation, timepassed);

                    bottomFoundTime = DateTime.Now;               //((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                }
                else
                {
                    Insert(0, bLoc, newly);
                }
            }
            else
            {

            }
        }

        //Caculate price change average of slopeTotal to decide the price of buying order
        public int Caculate()
        {
            int downwave = int.Parse(form01.comboWave.Text);
            int changeaverage = 0;
            proposedPrice = 0;

            for (int i=0; i < slopeTotal.Length;i++)
            {
                int sum =0;
                sum += slopeTotal[i];
                changeaverage = sum / downwave;
            }
            
            proposedPrice = bottomPoints[0,downwave] + changeaverage;

            return proposedPrice;
        }

        public void Insert(int vertical, int location, int value)
        {
            this.bottomPoints[vertical, location] = value;
        }

        // algorithm for best buying condition
        public bool BuyingCondition()
        {
            int downwave = int.Parse(form01.comboWave.Text);    // downwave of stock price
    
            int totalSeconds = int.Parse(form01.comboTiming.Text);  // time span

             //temporary check
            if (flag == 1 && waveSent1 == false)
            {
                form01.logListBox.Items.Add($"flag wave : {this.Code} , {flag}");
                waveSent1 = true;
            }
            if (flag == 2 && waveSent2 == false)
            {
                form01.logListBox.Items.Add($"flag wave : {this.Code} , {flag}");
                waveSent2 = true;
            }
            if (flag == 3 && waveSent3 == false)
            {
                form01.logListBox.Items.Add($"flag wave : {this.Code} , {flag}");
                waveSent3 = true;
            }
            /***
            ***/

            if (flag == downwave && orderSent == false && (currentTime - bottomFoundTime).TotalSeconds >= totalSeconds)
            {
                form01.logListBox.Items.Add($"flag wave : {flag}");

                slopeTotal = totalSlope(downwave);      // e.g.  wave 1, wave 2, wave 3... in wave array.

                for (int i = 0; i < downwave; i++)
                {
                    form01.logListBox.Items.Add($"현재가 {i} : {bottomPoints[0, i]}");
                    form01.logListBox.Items.Add($"가격변화량 {i} : {slopeTotal[i]}");
                }

                //Caculate slopeTotal to decide the price of buying order
                proposedPrice = Caculate();

                orderSent = true;
                flag = 0;

                return true;
            }
            else
            {
                return false;
            }
        }


        // total slope
        public int[] totalSlope(int downwave)
        {
            int[] totalS = new int[downwave];

            for (int i=0; i<downwave;i++)
            {
                // slope of bottompoints
                int x = ChangeX(i, i+1);       // Time change
                int y = ChangeY(i, i + 1);       // price change

                totalS[i] = y;                  // just for stock price only not exactly slope
                //totalS[downwave] = y / x;     // slope
            }

            return totalS;
        }

        // Time change
        public int ChangeX(int a, int b)
        {
            //slopeProducer01 = new SlopeProducer(this);
            int change = bottomPoints[1, b] - bottomPoints[1, a] ;

            return change;
        }

        // price change
        public int ChangeY(int a, int b)
        {
            //slopeProducer01 = new SlopeProducer(this);        

            if (bottomPoints[0,0]==1000000)      // 초기값이 변하지 않았을때
            {
                bottomPoints[0,0] = bottomPoints[0,1];
            }
            int change = bottomPoints[0, b]- bottomPoints[0, a]; ;

            return change;
        }

        public void SendOrder_Buy(string code, int price)
        {
            int result = form01.axKHOpenAPI1.SendOrder("주식주문", "1001", "8008765411", 1, code, 1, price, "03", null);

            if (result == 0)
            {
                Console.WriteLine("매수 주문 요청 성공");
                form01.logListBox.Items.Add($"proposedPrice : {proposedPrice}");
            }
        }

        /**
        //Step 2 function
        private void Send_Order_Buying(string rqname, string scrNum, string accNum, int orderType, string itemCodee, int quantity, int price, string trType, string ori_Num)
        {
            // Send order to the server
            //int result = axKHOpenAPI02.SendOrder(rqname, scrNum, accNum, orderType, itemCodee, quantity, price, trType, ori_Num);

            //int result = axKHOpenAPI1.SendOrder(items.rqname, items.scrNum, items.accNum, items.orderType, items.itemCode, items.quantity, items.price, items.trType, items.ori_Num);
            if (result == 0)       // 요청성공
            {
                Console.WriteLine("주문요청 성공");
            }
            else    // sendOrder failed
            {
            }
        }
        **/





    }



    // Filter the fundamental information of stocks, for example, 영업이익, 자본금, EPS from all the market stocks.
    public class Filter
    {
        Form1 form1;
        List<CodeInfo> allCodesInfo;

        public Filter(Form1 form)
        {
            this.form1 = form;
        }

        public List<CodeInfo> Start01()
        {
            // csv file open into memory
            string[] csv = File.ReadAllLines("second.txt");

            // filter the csv file into List<class>
            allCodesInfo = CsvToList(csv);
            return allCodesInfo;
        }

        public List<CodeInfo> CsvToList(string[] csvLines)                    // filter to classList
        {

            allCodesInfo = new List<CodeInfo>();     // code object with fundamental information

            for (int i = 0; i < csvLines.Length; i++)
            {
                string[] rowdata = csvLines[i].Split(',');

                CodeInfo codeInfo = new CodeInfo(csvLines[i]);
                allCodesInfo.Add(codeInfo);

                //Console.WriteLine($"rowdata[0] : {rowdata[0]}");
                //Console.WriteLine($"rowdata[1] : {rowdata[1]}");
                //Console.WriteLine($"rowdata[2] : {rowdata[2]}");
                //Console.WriteLine($"rowdata[3] : {rowdata[3]}");
                //Console.WriteLine($"rowdata[4] : {rowdata[4]}");
            }

            return allCodesInfo;
        }

        public Group GroupProducer(List<CodeInfo> allInfo, int capitalCondition, int profitCondition)
        {
            var group = new Group();

            group.codeList = new List<string>();
            group.codeName = new List<string>();

            foreach (CodeInfo codeInfo in allInfo)
            {
                int num;
                int num02;

                if (codeInfo.capital == "자본금")          // csv header data skipped.
                    continue;
                num = int.Parse(codeInfo.capital);

                if (codeInfo.profit == "")
                {
                    num02 = 0;
                }
                else
                {
                    num02 = int.Parse(codeInfo.profit);
                }
               
                        
                     
                

                if (num >= capitalCondition && num02 >= profitCondition)
                {
                    string str = num.ToString();
                    group.codeList.Add(codeInfo.code);
                    group.codeName.Add(codeInfo.name);

                    Console.WriteLine("codeinfo");
                    Console.WriteLine("codeInfo.code : " + codeInfo.code);
                    Console.WriteLine("codeInfo.name : " + codeInfo.name);
                }
            }
            
            form1.StaticStrategyTest(group);

            return group;
        }
    }

    // Information for each code
    public class CodeInfo
    {
        public string code;
        public string name;
        public string capital;
        public string volume;
        public string profit;

        public CodeInfo(string rowData)
        {
            string[] rowInfo = rowData.Split(',');

            this.code = rowInfo[0];
            this.name = rowInfo[1];
            this.capital = rowInfo[4];
            this.volume = rowInfo[3];
            this.profit = rowInfo[20];
        }
    }

    public class Group
    {
        public List<string> codeList = new List<string>();
        public List<string> codeName = new List<string>();

        public Group()
        {

        }

        public Group(List<string> codeList, List<string> codeName)
        {
            this.codeList = codeList;
            this.codeName = codeName;
        }

        public class GroupType
        {

        }
    }
}
