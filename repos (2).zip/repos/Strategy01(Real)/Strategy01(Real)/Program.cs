﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Strategy01_Real_
{
    static class Program
    {
        /// <summary>
        /// 해당 애플리케이션의 주 진입점입니다.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }

    // Information for each code
    public class CodeInfo
    {
        public string code;
        public string name;
        public string capital;
        public string volume;
        public string profit;
        public string netProfit;
        public string revenue;                  // 매출액

        public string relativeToMaxPrice;       //250 최고가 대비율
        public string relativeToMinPrice;       //250 최저가 대비율
        public string currentPrice;             //현재가

        public CodeInfo(string rowData)
        {
            string[] rowInfo = rowData.Split(',');

            this.code = rowInfo[0];
            this.name = rowInfo[1];
            this.capital = rowInfo[4];
            this.volume = rowInfo[3];
            this.revenue = rowInfo[19];
            this.profit = rowInfo[20];                  //영업이익
            this.netProfit = rowInfo[21];               // 당기순이익

            this.relativeToMaxPrice = rowInfo[33];      //250 최고가 대비율
            this.relativeToMinPrice = rowInfo[35];      //250 최저가 대비율
            this.currentPrice = rowInfo[36];            //현재가
        }
    }

    public class Group
    {
        public List<string> codeList = new List<string>();
        public List<string> codeName = new List<string>();
        public List<string> codeCapital = new List<string>();
        public List<string> codeVolumn = new List<string>();
        public List<string> codeRevenue = new List<string>();
        public List<string> codeProfit = new List<string>();
        public List<string> codeNetProfit = new List<string>();

        public Group()
        {

        }

        public Group(List<string> codeList, List<string> codeName)
        {
            this.codeList = codeList;
            this.codeName = codeName;
        }

        public class GroupType
        {

        }
    }

    // Filter the fundamental information of stocks, for example, 영업이익, 자본금, EPS from all the market stocks.
    public class Filter
    {
        Form1 form1;
        List<CodeInfo> allCodesInfo;

        public Filter(Form1 form)
        {
            this.form1 = form;
        }

        public List<CodeInfo> Start01()
        {
            // csv file open into memory
            string[] csv = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\strategy1Daily\strDaily.txt");

            // filter the csv file into List<class>
            allCodesInfo = CsvToList(csv);
            return allCodesInfo;
        }

        public List<CodeInfo> CsvToList(string[] csvLines)                    // filter to classList
        {
            allCodesInfo = new List<CodeInfo>();     // code object with fundamental information

            for (int i = 0; i < csvLines.Length; i++)
            {
                string[] rowdata = csvLines[i].Split(',');

                CodeInfo codeInfo = new CodeInfo(csvLines[i]);
                allCodesInfo.Add(codeInfo);
            }

            return allCodesInfo;
        }

        public Group GroupProducer(List<CodeInfo> allInfo, int capCon, int profitCon, int debtCon, int netProRateCon, double relToMaxPCon)
        {
            var group = new Group();

            group.codeList = new List<string>();
            group.codeName = new List<string>();

            foreach (CodeInfo codeInfo in allInfo)
            {
                int num;
                double num02;
                double num03;
                double num04;
                double num05;       //250 최고가 대비율

                if (codeInfo.capital == "자본금")          // csv header data skipped.
                    continue;
                num = int.Parse(codeInfo.capital);

                if (codeInfo.profit == "")
                {
                    num02 = 0;
                }
                else
                {
                    num02 = int.Parse(codeInfo.profit);
                }

                if (codeInfo.netProfit == "")
                {
                    num03 = 0;
                }
                else
                {
                    num03 = double.Parse(codeInfo.netProfit);
                }

                if (codeInfo.revenue == "")
                {
                    num04 = 0;
                }
                else
                {
                    num04 = double.Parse(codeInfo.revenue);
                }

                if (codeInfo.relativeToMaxPrice == "")
                {
                    num05 = 0;
                }
                else
                {
                    num05 = double.Parse(codeInfo.relativeToMaxPrice);
                }

                // Should caculate "netProfit' with capital to produce "netprofitRate"
                // 순이익/매출액 * 100
                //num04 = (num04);
                //netProfit = int.Parse(codeInfo.netProfit);
                if (num03 == 0 || num04 == 0)
                {

                }
                else
                {
                    num03 = (num03 / num04) * 100;

                    //form1.logListBox.Items.Add(netProfitRatio);
                }

                if (num >= capCon && num02 >= profitCon && num03 >= netProRateCon && num05 <= relToMaxPCon)        // && netProfitRatio >= 20
                {
                    string str = num.ToString();
                    group.codeList.Add(codeInfo.code);
                    group.codeName.Add(codeInfo.name);
                    group.codeCapital.Add(codeInfo.capital);
                    group.codeVolumn.Add(codeInfo.volume);
                    group.codeProfit.Add(codeInfo.profit);
                    group.codeNetProfit.Add(codeInfo.netProfit);
                    group.codeRevenue.Add(codeInfo.revenue);

                    //Console.WriteLine(codeInfo.name);
                    //Console.WriteLine($"group.codeName.Count : {group.codeName.Count}");
                }
            }
            //Console.WriteLine($"group.codeName.Count : {group.codeName.Count}");
            return group;
        }
    }

    public class StrategyStatic
    {
        public double capital;
        public double profit;
        public double debt;        
        public int netProfitRate;
        public double relToMaxPrice;

        public StrategyStatic(double cap, double profit, double debt, int netProfitRate, double relToMaxP)//, int wave, int timing, int soar)
        {
            this.capital = cap;
            this.profit = profit;
            this.debt = debt;            
            this.netProfitRate = netProfitRate;
            this.relToMaxPrice = relToMaxP;
        }
    }

    public class StrategyDynamic
    {
        public int wave;
        public int timing;
        public int soaring;
        public string tail;
        public string tradeVolumn;
        public string separation;   

        public StrategyDynamic(int wave, int timing, int soar)
        {
            this.wave = wave;
            this.timing = timing;
            this.soaring = soar;
        }
    }

    public class StrategyElements
    {
        public string capital;
        public string profit;
        public string Debt;

        public string tail;
        public string tradeVolumn;
        public string separation;
        public string timing;
    }

    interface IFindChance
    {
        void GetTheChance();
        //void Order();
    }

    // Class for each stock  to find bottom points and to send order
    public class Stock 
    {
        Form1 form01;
        
        bool waveSent1 = false;      // temporary
        bool waveSent2 = false;      // temporary
        bool waveSent3 = false;      // temporary

        int bouthtVolumn = 0;       // 매수 총량
        double totalSum = 0; // 매입금액총량

        public int proposedPrice;
        public int continuity = 0;

        public string Code { get; set; }
        public string Name { get; set; }
        public string currentPrice;      // for receiving data splited from the real time data
        protected int priceToBuy;          // for buyingcondition
        protected int buyingPrice;        // for buyingcondition02
        
        int[] slopeTotal;
        int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        int bLocation = 0;                  // location of bottomPoints

        int bTimeLocation = 0;
        int flag = 0;                       // flag for bottomPoints
        bool orderSent;                 // check if order is sent at the third bottom point.
        DateTime bottomFoundTime;
        protected DateTime currentTime;             // to compare the current time with elapsed time
        DateTime bottomFound;
        DateTime initTime;                  // When the app start for soaring volumn(trade)
        DateTime startTime;                 // When starting comparing soaring volumn(trade) and average volumn(trade)

        protected string e_srealData;
        protected string e_srealKey;

        long tradeVolumn = 0;                                       // 거래 발생 횟수 마다증가
        double temVolumn = 0;                                       // 순간 거래량
        double volumnSum = 0;
        double volumnAverage = 0;                                         // 거래량 평균
        //public List<double> volumns = new List<double>();           // 거래량 list

        List<string[]> listFromServer = new List<string[]>();       // container for real time data from Kiwoom Server.

        public Stock(Form1 form, string stockCode, string stockName)
        {
            form01 = form;
            this.Code = stockCode;
            this.Name = stockName;
            this.initTime = DateTime.Now;

            bottomFoundTime = DateTime.Now;      // ((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
            bottomPoints = new int[2, 1000];
            bottomPoints[0, 0] = 1000000;
            bottomPoints[1, 0] = 0;
        }

        public Stock(string code, string name)
        {
            e_srealData = code;
            e_srealKey = name;
        }
        
        public void GetTheChance()
        {
            //DateTime currentTime; // to compare the current time with elapsed time         
            this.currentTime = DateTime.Now;

            // remove "-" 
            this.currentPrice = this.currentPrice.Trim();
            this.priceToBuy = int.Parse(this.currentPrice);
            this.priceToBuy = Math.Abs(this.priceToBuy);

            this.BottomPoints();    // Find bottom Points to send order of buying. if found, send the data to bottomPoints 
        }

        public void GetTheChance02(string volumn, string curprice)           // 거래량  급등 전략 
        {
            //form01.p();
            int limit = int.Parse(form01.dgvStrVolSoar.Rows[0].Cells[5].Value.ToString());
            double total = double.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[6].Value);
            double number = double.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[7].Value);
            int priceLimit = (int)IronBuyPrice(total, number);
            int num = 0;

            form01.ChangeRealTime(this.Code, curprice);

            if (bouthtVolumn >= limit) 
            {
                //form01.p($"{Name} : 총량제한");
                //form01.p($"{bouthtVolumn} : 매수수량");
                //form01.p($"{limit} : 제한매수");  
            }
            
            else
            {
                //form01.p($"{Name} : Not yet");
                //form01.p($"{limit} : Not yet");
                
                tradeVolumn++;
                this.currentTime = DateTime.Now;
                this.currentPrice = this.currentPrice.Trim();
                this.buyingPrice = int.Parse(this.currentPrice);                
                this.buyingPrice = Math.Abs(this.buyingPrice);

                this.temVolumn = Math.Abs(double.Parse(volumn.Trim()));
                this.volumnSum += temVolumn;
                this.volumnAverage = volumnSum / tradeVolumn;
                num = priceLimit / buyingPrice;
                
                FindSoaringVolumn(num);        // check the volumn is soaring 2times, 3times, 4times...              
            }
            DataView dv = form01.dtRealTime.DefaultView;
            dv.Sort = "continuity desc";

        }

        public void FindSoaringVolumn(int num) // check the volumn is soaring 2times, 3times, 4times...
        {
            if(BuyingCondition02())
                SendOrder_Buy(this.Code, buyingPrice, num);
        }

        public bool BuyingCondition02()
        {
            double timespan02 = (DateTime.Now - initTime).TotalSeconds;
            int soaring = int.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[0].Value);
            int timeLimit = int.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[1].Value);
            int con = int.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[2].Value);       // 거래량 증가 연속성
            double total= double.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[6].Value);
            double number = double.Parse((string)form01.dgvStrVolSoar.Rows[0].Cells[7].Value);
            int priceLimit = (int)IronBuyPrice(total, number);
            
            //form01.p($"Name : {Name}, volumnAverage :{volumnAverage}, temVolumn : {temVolumn}, continuity : {continuity}, soaring : {soaring}");

            if (Slope(volumnAverage, temVolumn) >= soaring)
                continuity++;
            
            if (Slope(volumnAverage, temVolumn) >= soaring && timespan02 > timeLimit && continuity > con && buyingPrice < priceLimit)
                return true;
            else
                return false;
            
            //return true;
        }

        public double IronBuyPrice(double Total, double number)       // Iron the buying price according to the total money and number of eadh stock
        {
            return Total / number;
        }

        public double IronSellPrice(double bouthtPrice, double rate)      // Iron the Selling price according to the boutht price and profit rate.
        {
            return bouthtPrice + bouthtPrice * rate;
        }

        // Find bottom Points to send order of buying. if lower price found, send the data to bottomPoints      
        // step 1 : compare the previous value with newly evented value
        // step 2 : if(true) insert the value, if not desert the value
        // step 3 : if(third bottom found) send order of buying stock.
        public void BottomPoints()
        {
            // step 1 : compare the previous value with newly evented value
            int previous = bottomPoints[0, bLocation];  // extract data from in the bottomPoints
            int newly = this.priceToBuy;                // extract data from the Kiwoom server
            int num = 1;                                // number of stocks to order.

            Compare(previous, newly, this.bLocation);        // compare A with B

            // step 2 : if(true) insert the value, if not desert the value ;  insert function called from compare function
            // step 3 : if(third bottom found) send order of buying stock. : check if third bottomPoint is found

            if (BuyingCondition())       //BuyingCondition()
            {
                //send_buying_order  here
                SendOrder_Buy(this.Code, proposedPrice, num);
            }
        }

        public void Compare(int previous, int newly, int bLoc)
        {
            if (previous > newly)
            {
                // step 2 of BottomPoints : if(true) insert the value, if not desert the value
                // next bottom point
                string str = form01.dgvDynamicStr.Rows[0].Cells[0].Value.ToString();
                int totalSeconds = int.Parse(str);

                double timespan = (currentTime - bottomFoundTime).TotalSeconds;

                int timepassed = (int)timespan;

                if (timespan >= totalSeconds)          //  1 minutes. 
                {
                    this.bLocation++;

                    // Register previous bottom information
                    flag++;
                    Insert(0, this.bLocation, newly);

                    Insert(1, this.bLocation, timepassed);

                    bottomFoundTime = DateTime.Now;               //((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                }
                else
                {
                    Insert(0, bLoc, newly);
                }
            }
            else
            {

            }
        }

        //Caculate price change average of slopeTotal to decide the price of buying order
        public int Calculate()
        {            
            int downwave = int.Parse((string)(form01.dgvDynamicStr.Rows[0].Cells[1].Value));
            int changeaverage = 0;
            proposedPrice = 0;
            slopeTotal = totalSlope(downwave);      // e.g.  wave 1, wave 2, wave 3... in wave array.

            for (int i = 0; i < slopeTotal.Length; i++)
            {
                int sum = 0;
                sum += slopeTotal[i];
                changeaverage = sum / downwave;
            }

            proposedPrice = bottomPoints[0, downwave] + changeaverage * 10;         //+ changeaverage
            /******/ // 호가단위
            proposedPrice = form01.justifyPrice(proposedPrice);
            return proposedPrice;
        }

        public void Insert(int vertical, int location, int value)
        {
            this.bottomPoints[vertical, location] = value;
        }

        // algorithm for best buying condition
        public bool BuyingCondition()
        {
            int downwave = int.Parse((string)(form01.dgvDynamicStr.Rows[0].Cells[1].Value));    // downwave of stock price
            int totalSeconds = int.Parse(form01.dgvDynamicStr.Rows[0].Cells[0].Value.ToString());  // time span

            //temporary check
            if (flag == 1 && waveSent1 == false)
            {
                form01.logListBox.Items.Add($"flag wave : {this.Code} :{this.Name},  {flag}");
                waveSent1 = true;
            }
            if (flag == 2 && waveSent2 == false)
            {
                form01.logListBox.Items.Add($"flag wave : {this.Code} :{this.Name} , {flag}");
                waveSent2 = true;
            }
            if (flag == 3 && waveSent3 == false)
            {
                form01.logListBox.Items.Add($"flag wave : {this.Code} :{this.Name} , {flag}");
                waveSent3 = true;
            }

            //Caculate slopeTotal to decide the price of buying order
            proposedPrice = Calculate();

            if (flag == downwave && orderSent == false && (currentTime - bottomFoundTime).TotalSeconds >= totalSeconds && proposedPrice < 100000)
            {
                form01.logListBox.Items.Add($"flag wave : {flag}");
                for (int i = 0; i < downwave; i++)
                {
                    form01.logListBox.Items.Add($"현재가 {i} : {bottomPoints[0, i]}");
                    form01.logListBox.Items.Add($"가격변화량 {i} : {slopeTotal[i]}");
                }

                orderSent = true;
                flag = 0;

                return true;
            }
            else
            {
                return false;
            }
        }

        // total slope
        public int[] totalSlope(int downwave)
        {
            int[] totalS = new int[downwave];

            for (int i = 0; i < downwave; i++)
            {
                // slope of bottompoints
                int x = ChangeX(i, i + 1);       // Time change
                int y = ChangeY(i, i + 1);       // price change

                totalS[i] = y;                  // just for stock price only not exactly slope
                //totalS[downwave] = y / x;     // slope
            }

            return totalS;
        }

        // Time change
        public int ChangeX(int a, int b)
        {
            //slopeProducer01 = new SlopeProducer(this);
            int change = bottomPoints[1, b] - bottomPoints[1, a];

            return change;
        }

        // price change
        public int ChangeY(int a, int b)
        {
            //slopeProducer01 = new SlopeProducer(this);        

            if (bottomPoints[0, 0] == 1000000)      // 초기값이 변하지 않았을때
            {
                bottomPoints[0, 0] = bottomPoints[0, 1];
            }
            int change = bottomPoints[0, b] - bottomPoints[0, a]; ;

            return change;
        }

        public void SendOrder_Buy(string code, int price, int num)
        {
            int result = form01.axKHOpenAPI1.SendOrder("주식주문", form01.GetScreenNumber(), "8008765411", 1, code, num, price, "00", null);

            if (result == 0)
            {
                form01.orderCount++;

                form01.logListBox.Items.Add($"매수 주문 요청 성공, 종목갯수 : {form01.orderCount}");
                form01.logListBox.Items.Add($"proposedPrice : {proposedPrice}, 계좌번호 : {form01.accNumber}, 종목 : {code}");

                form01.logListBox.Items.Add($"proposedPrice : {proposedPrice}");
                bouthtVolumn++;             // 주식 매입수 증가
                form01.p($"bouthtVolumn {bouthtVolumn}");
            }
        }

        // utilities of Stock class 
        public double Slope(double xMargin, double yMargin)
        {
            return yMargin/xMargin;
        }

        public double getAverage(List<double> list)
        {
            double sum = 0;
            double average = 0;

            foreach (double value in list)
            {
                sum += sum + value;
            }
            average = sum / list.Count;
            return average;
        }
    }

    public class StockForDailyStr : Stock, IFindChance
    {
        public StockForDailyStr(string code, string name) : base(code, name)
        {
            this.e_srealData = code;
            this.e_srealKey = name;
        }
        public void GetTheChance()
        {
            //DateTime currentTime; // to compare the current time with elapsed time         
            this.currentTime = DateTime.Now;

            // remove "-" 
            this.currentPrice = this.currentPrice.Trim();
            this.priceToBuy = int.Parse(this.currentPrice);
            this.priceToBuy = Math.Abs(this.priceToBuy);

            this.BottomPoints();    // Find bottom Points to send order of buying. if found, send the data to bottomPoints 
        }
    }

    public class StockForWindsStr : Stock, IFindChance
    {
        public StockForWindsStr(string code, string name) : base(code, name)
        {
            this.e_srealData = code;
            this.e_srealKey = name;
        }
        public void GetTheChance()
        {

        }
    }

    public class StockForVolumnStr : Stock, IFindChance
    {
        public StockForVolumnStr(string code, string name) : base(code, name)
        {
            this.e_srealData = code;
            this.e_srealKey = name;
        }
        public void GetTheChance()
        {

        }
    }

    // Parent class of all strategy classes
    public class Strategy
    {
        public string Title { get; set; }
        public string AccountNumber { get; set; }
        public string[] Codes { get; set; }
        public string[] Names { get; set; }
        public double TotalBoughtAmount { get; set; }
        public double ValuationAmount { get; set; }
        public double ReturnRate { get; set; }
        public string Portion { get; set; }
        public double Result { get; set; }
    }

    public class S_Daily50Drop : Strategy
    {
        public S_Daily50Drop() 
        {
        }

        public S_Daily50Drop(string title)
        {
            this.Title = title;
        }
    }

    public class S_Winds : Strategy
    {
        public S_Winds()
        {
        }

        public S_Winds(string title)
        {
            this.Title = title;
        }
    }

    public class S_TotalResult : Strategy
    {
        private double totalProperty;

        public S_TotalResult()
        {
        }

        public S_TotalResult(string title)
        {
            this.Title = title;
        }
    }

    // Represents the file of "dailycandle.txt" in server folder
    public class Server
    {
        public Server()
        {

        }
        public Server(string filePath)
        {
            string rootPath = @"C:\Users\user\Desktop\stock\strategy\server\";
            string fullPath = rootPath + filePath;
            this.csvStyle = File.ReadAllLines(fullPath);
        }

        public string[] csvStyle;
        //public DataTable dt;
    }
}
