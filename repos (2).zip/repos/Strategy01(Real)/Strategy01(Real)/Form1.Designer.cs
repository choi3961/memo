﻿
using System.Windows.Forms;

namespace Strategy01_Real_
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSaveResult = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tPSumInfo = new System.Windows.Forms.TabPage();
            this.dgvRealInfo = new System.Windows.Forms.DataGridView();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.btnReSet = new System.Windows.Forms.Button();
            this.btnResult = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSaveStr = new System.Windows.Forms.Button();
            this.btnRegRemove = new System.Windows.Forms.Button();
            this.listBoxAccount = new System.Windows.Forms.ListBox();
            this.btnCancelAllBuy = new System.Windows.Forms.Button();
            this.btnCancelAllSell = new System.Windows.Forms.Button();
            this.tcAccount = new System.Windows.Forms.TabControl();
            this.account1 = new System.Windows.Forms.TabPage();
            this.dgvAccount = new System.Windows.Forms.DataGridView();
            this.tabMissed = new System.Windows.Forms.TabPage();
            this.dgvMissed = new System.Windows.Forms.DataGridView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.logListBox = new System.Windows.Forms.ListBox();
            this.btnSellAll02 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.btnSellAll = new System.Windows.Forms.Button();
            this.realDataButton = new System.Windows.Forms.Button();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tcTotalInfo = new System.Windows.Forms.TabControl();
            this.account11 = new System.Windows.Forms.TabPage();
            this.dgvTotal = new System.Windows.Forms.DataGridView();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tcStrategies = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvDynamicStr = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvTest = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvStrVolSoar = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvStaticStr = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.loginButton = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tPSumInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRealInfo)).BeginInit();
            this.tcAccount.SuspendLayout();
            this.account1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccount)).BeginInit();
            this.tabMissed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMissed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.tcTotalInfo.SuspendLayout();
            this.account11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTotal)).BeginInit();
            this.tcStrategies.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDynamicStr)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStrVolSoar)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaticStr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnSaveResult);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tabControl3);
            this.groupBox1.Controls.Add(this.btnReSet);
            this.groupBox1.Controls.Add(this.btnResult);
            this.groupBox1.Controls.Add(this.btnReport);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSaveStr);
            this.groupBox1.Controls.Add(this.btnRegRemove);
            this.groupBox1.Controls.Add(this.listBoxAccount);
            this.groupBox1.Controls.Add(this.btnCancelAllBuy);
            this.groupBox1.Controls.Add(this.btnCancelAllSell);
            this.groupBox1.Controls.Add(this.tcAccount);
            this.groupBox1.Controls.Add(this.logListBox);
            this.groupBox1.Controls.Add(this.btnSellAll02);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.axKHOpenAPI1);
            this.groupBox1.Controls.Add(this.btnSellAll);
            this.groupBox1.Controls.Add(this.realDataButton);
            this.groupBox1.Controls.Add(this.tabControl2);
            this.groupBox1.Controls.Add(this.tcTotalInfo);
            this.groupBox1.Controls.Add(this.tcStrategies);
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Location = new System.Drawing.Point(13, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1593, 747);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btnSaveResult
            // 
            this.btnSaveResult.Location = new System.Drawing.Point(561, 304);
            this.btnSaveResult.Name = "btnSaveResult";
            this.btnSaveResult.Size = new System.Drawing.Size(103, 23);
            this.btnSaveResult.TabIndex = 1;
            this.btnSaveResult.Text = "SaveResult";
            this.btnSaveResult.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(222, 308);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 19);
            this.label2.TabIndex = 56;
            this.label2.Text = "RealTime Market";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tPSumInfo);
            this.tabControl3.Controls.Add(this.tabPage14);
            this.tabControl3.Location = new System.Drawing.Point(18, 308);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(665, 308);
            this.tabControl3.TabIndex = 55;
            // 
            // tPSumInfo
            // 
            this.tPSumInfo.Controls.Add(this.dgvRealInfo);
            this.tPSumInfo.Location = new System.Drawing.Point(4, 22);
            this.tPSumInfo.Name = "tPSumInfo";
            this.tPSumInfo.Padding = new System.Windows.Forms.Padding(3);
            this.tPSumInfo.Size = new System.Drawing.Size(657, 282);
            this.tPSumInfo.TabIndex = 0;
            this.tPSumInfo.Text = "SumInfo";
            this.tPSumInfo.UseVisualStyleBackColor = true;
            // 
            // dgvRealInfo
            // 
            this.dgvRealInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRealInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRealInfo.Location = new System.Drawing.Point(3, 3);
            this.dgvRealInfo.Name = "dgvRealInfo";
            this.dgvRealInfo.RowTemplate.Height = 23;
            this.dgvRealInfo.Size = new System.Drawing.Size(651, 276);
            this.dgvRealInfo.TabIndex = 0;
            // 
            // tabPage14
            // 
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(657, 282);
            this.tabPage14.TabIndex = 1;
            this.tabPage14.Text = "tabPage14";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // btnReSet
            // 
            this.btnReSet.Location = new System.Drawing.Point(539, 13);
            this.btnReSet.Name = "btnReSet";
            this.btnReSet.Size = new System.Drawing.Size(106, 23);
            this.btnReSet.TabIndex = 7;
            this.btnReSet.Text = "Reset";
            this.btnReSet.UseVisualStyleBackColor = true;
            // 
            // btnResult
            // 
            this.btnResult.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnResult.Location = new System.Drawing.Point(1317, 522);
            this.btnResult.Name = "btnResult";
            this.btnResult.Size = new System.Drawing.Size(107, 26);
            this.btnResult.TabIndex = 53;
            this.btnResult.Text = "Result";
            this.btnResult.UseVisualStyleBackColor = true;
            // 
            // btnReport
            // 
            this.btnReport.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnReport.Location = new System.Drawing.Point(1297, 284);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(134, 28);
            this.btnReport.TabIndex = 48;
            this.btnReport.Text = "Report";
            this.btnReport.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(207, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 19);
            this.label1.TabIndex = 52;
            this.label1.Text = "Dynamic Strategy";
            // 
            // btnSaveStr
            // 
            this.btnSaveStr.Location = new System.Drawing.Point(589, 159);
            this.btnSaveStr.Name = "btnSaveStr";
            this.btnSaveStr.Size = new System.Drawing.Size(92, 27);
            this.btnSaveStr.TabIndex = 50;
            this.btnSaveStr.Text = "Save Str";
            this.btnSaveStr.UseVisualStyleBackColor = true;
            // 
            // btnRegRemove
            // 
            this.btnRegRemove.Location = new System.Drawing.Point(489, 159);
            this.btnRegRemove.Name = "btnRegRemove";
            this.btnRegRemove.Size = new System.Drawing.Size(92, 27);
            this.btnRegRemove.TabIndex = 47;
            this.btnRegRemove.Text = "RegRemove";
            this.btnRegRemove.UseVisualStyleBackColor = true;
            // 
            // listBoxAccount
            // 
            this.listBoxAccount.FormattingEnabled = true;
            this.listBoxAccount.ItemHeight = 12;
            this.listBoxAccount.Location = new System.Drawing.Point(1450, 51);
            this.listBoxAccount.Name = "listBoxAccount";
            this.listBoxAccount.Size = new System.Drawing.Size(120, 172);
            this.listBoxAccount.TabIndex = 40;
            // 
            // btnCancelAllBuy
            // 
            this.btnCancelAllBuy.Location = new System.Drawing.Point(1114, 238);
            this.btnCancelAllBuy.Name = "btnCancelAllBuy";
            this.btnCancelAllBuy.Size = new System.Drawing.Size(109, 23);
            this.btnCancelAllBuy.TabIndex = 45;
            this.btnCancelAllBuy.Text = "매수취소(all)";
            this.btnCancelAllBuy.UseVisualStyleBackColor = true;
            // 
            // btnCancelAllSell
            // 
            this.btnCancelAllSell.Location = new System.Drawing.Point(999, 236);
            this.btnCancelAllSell.Name = "btnCancelAllSell";
            this.btnCancelAllSell.Size = new System.Drawing.Size(109, 23);
            this.btnCancelAllSell.TabIndex = 44;
            this.btnCancelAllSell.Text = "매도취소(all)";
            this.btnCancelAllSell.UseVisualStyleBackColor = true;
            // 
            // tcAccount
            // 
            this.tcAccount.Controls.Add(this.account1);
            this.tcAccount.Controls.Add(this.tabMissed);
            this.tcAccount.Controls.Add(this.tabPage10);
            this.tcAccount.Controls.Add(this.tabPage12);
            this.tcAccount.Controls.Add(this.tabPage13);
            this.tcAccount.Location = new System.Drawing.Point(730, 15);
            this.tcAccount.Name = "tcAccount";
            this.tcAccount.SelectedIndex = 0;
            this.tcAccount.Size = new System.Drawing.Size(701, 212);
            this.tcAccount.TabIndex = 39;
            // 
            // account1
            // 
            this.account1.Controls.Add(this.dgvAccount);
            this.account1.Location = new System.Drawing.Point(4, 22);
            this.account1.Name = "account1";
            this.account1.Padding = new System.Windows.Forms.Padding(3);
            this.account1.Size = new System.Drawing.Size(693, 186);
            this.account1.TabIndex = 2;
            this.account1.Text = "8008765411";
            this.account1.UseVisualStyleBackColor = true;
            // 
            // dgvAccount
            // 
            this.dgvAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAccount.Location = new System.Drawing.Point(3, 3);
            this.dgvAccount.Name = "dgvAccount";
            this.dgvAccount.RowTemplate.Height = 23;
            this.dgvAccount.Size = new System.Drawing.Size(687, 180);
            this.dgvAccount.TabIndex = 0;
            // 
            // tabMissed
            // 
            this.tabMissed.Controls.Add(this.dgvMissed);
            this.tabMissed.Location = new System.Drawing.Point(4, 22);
            this.tabMissed.Name = "tabMissed";
            this.tabMissed.Padding = new System.Windows.Forms.Padding(3);
            this.tabMissed.Size = new System.Drawing.Size(693, 186);
            this.tabMissed.TabIndex = 1;
            this.tabMissed.Text = "미체결";
            this.tabMissed.UseVisualStyleBackColor = true;
            // 
            // dgvMissed
            // 
            this.dgvMissed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMissed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMissed.Location = new System.Drawing.Point(3, 3);
            this.dgvMissed.Name = "dgvMissed";
            this.dgvMissed.RowTemplate.Height = 23;
            this.dgvMissed.Size = new System.Drawing.Size(687, 180);
            this.dgvMissed.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(693, 186);
            this.tabPage10.TabIndex = 3;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabPage12
            // 
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(693, 186);
            this.tabPage12.TabIndex = 4;
            this.tabPage12.Text = "tabPage12";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabPage13
            // 
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Size = new System.Drawing.Size(693, 186);
            this.tabPage13.TabIndex = 5;
            this.tabPage13.Text = "tabPage13";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // logListBox
            // 
            this.logListBox.FormattingEnabled = true;
            this.logListBox.ItemHeight = 12;
            this.logListBox.Location = new System.Drawing.Point(26, 638);
            this.logListBox.Name = "logListBox";
            this.logListBox.Size = new System.Drawing.Size(564, 100);
            this.logListBox.TabIndex = 17;
            // 
            // btnSellAll02
            // 
            this.btnSellAll02.Location = new System.Drawing.Point(864, 236);
            this.btnSellAll02.Name = "btnSellAll02";
            this.btnSellAll02.Size = new System.Drawing.Size(109, 23);
            this.btnSellAll02.TabIndex = 33;
            this.btnSellAll02.Text = "일괄매도(지정가)";
            this.btnSellAll02.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(222, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 21);
            this.label9.TabIndex = 27;
            this.label9.Text = "Static Strategy";
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(1450, 656);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 21;
            // 
            // btnSellAll
            // 
            this.btnSellAll.Location = new System.Drawing.Point(734, 238);
            this.btnSellAll.Name = "btnSellAll";
            this.btnSellAll.Size = new System.Drawing.Size(109, 19);
            this.btnSellAll.TabIndex = 2;
            this.btnSellAll.Text = "일괄매도(시장가)";
            this.btnSellAll.UseVisualStyleBackColor = true;
            // 
            // realDataButton
            // 
            this.realDataButton.Location = new System.Drawing.Point(390, 159);
            this.realDataButton.Name = "realDataButton";
            this.realDataButton.Size = new System.Drawing.Size(87, 27);
            this.realDataButton.TabIndex = 1;
            this.realDataButton.Text = "SetRealReg";
            this.realDataButton.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Location = new System.Drawing.Point(737, 532);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(694, 190);
            this.tabControl2.TabIndex = 54;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dgvResult);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(686, 164);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dgvResult
            // 
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(3, 3);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.RowTemplate.Height = 23;
            this.dgvResult.Size = new System.Drawing.Size(680, 158);
            this.dgvResult.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(686, 164);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tcTotalInfo
            // 
            this.tcTotalInfo.Controls.Add(this.account11);
            this.tcTotalInfo.Controls.Add(this.tabPage11);
            this.tcTotalInfo.Location = new System.Drawing.Point(734, 296);
            this.tcTotalInfo.Name = "tcTotalInfo";
            this.tcTotalInfo.SelectedIndex = 0;
            this.tcTotalInfo.Size = new System.Drawing.Size(704, 209);
            this.tcTotalInfo.TabIndex = 49;
            // 
            // account11
            // 
            this.account11.Controls.Add(this.dgvTotal);
            this.account11.Location = new System.Drawing.Point(4, 22);
            this.account11.Name = "account11";
            this.account11.Padding = new System.Windows.Forms.Padding(3);
            this.account11.Size = new System.Drawing.Size(696, 183);
            this.account11.TabIndex = 0;
            this.account11.Text = "8008765411";
            this.account11.UseVisualStyleBackColor = true;
            // 
            // dgvTotal
            // 
            this.dgvTotal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTotal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTotal.Location = new System.Drawing.Point(3, 3);
            this.dgvTotal.Name = "dgvTotal";
            this.dgvTotal.RowTemplate.Height = 23;
            this.dgvTotal.Size = new System.Drawing.Size(690, 177);
            this.dgvTotal.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(696, 183);
            this.tabPage11.TabIndex = 1;
            this.tabPage11.Text = "tabPage11";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // tcStrategies
            // 
            this.tcStrategies.Controls.Add(this.tabPage1);
            this.tcStrategies.Controls.Add(this.tabPage2);
            this.tcStrategies.Controls.Add(this.tabPage4);
            this.tcStrategies.Controls.Add(this.tabPage5);
            this.tcStrategies.Location = new System.Drawing.Point(16, 175);
            this.tcStrategies.Name = "tcStrategies";
            this.tcStrategies.SelectedIndex = 0;
            this.tcStrategies.Size = new System.Drawing.Size(669, 120);
            this.tcStrategies.TabIndex = 43;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvDynamicStr);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(661, 94);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "StrDaily";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvDynamicStr
            // 
            this.dgvDynamicStr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDynamicStr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDynamicStr.Location = new System.Drawing.Point(3, 3);
            this.dgvDynamicStr.Name = "dgvDynamicStr";
            this.dgvDynamicStr.RowTemplate.Height = 23;
            this.dgvDynamicStr.Size = new System.Drawing.Size(655, 88);
            this.dgvDynamicStr.TabIndex = 42;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgvTest);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(661, 94);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "StrWinds";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvTest
            // 
            this.dgvTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTest.Location = new System.Drawing.Point(3, 3);
            this.dgvTest.Name = "dgvTest";
            this.dgvTest.RowTemplate.Height = 23;
            this.dgvTest.Size = new System.Drawing.Size(655, 88);
            this.dgvTest.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dgvStrVolSoar);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(661, 94);
            this.tabPage4.TabIndex = 2;
            this.tabPage4.Text = "StrVolSoaring";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dgvStrVolSoar
            // 
            this.dgvStrVolSoar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStrVolSoar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStrVolSoar.Location = new System.Drawing.Point(0, 0);
            this.dgvStrVolSoar.Name = "dgvStrVolSoar";
            this.dgvStrVolSoar.RowTemplate.Height = 23;
            this.dgvStrVolSoar.Size = new System.Drawing.Size(661, 94);
            this.dgvStrVolSoar.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(661, 94);
            this.tabPage5.TabIndex = 3;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(17, 20);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(669, 127);
            this.tabControl1.TabIndex = 51;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgvStaticStr);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(661, 101);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvStaticStr
            // 
            this.dgvStaticStr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStaticStr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStaticStr.Location = new System.Drawing.Point(3, 3);
            this.dgvStaticStr.Name = "dgvStaticStr";
            this.dgvStaticStr.RowTemplate.Height = 23;
            this.dgvStaticStr.Size = new System.Drawing.Size(655, 95);
            this.dgvStaticStr.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(661, 101);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(13, 12);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(109, 29);
            this.loginButton.TabIndex = 0;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea1.AxisX.IsStartedFromZero = false;
            chartArea1.AxisY.IsStartedFromZero = false;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(1612, 63);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(819, 420);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            // 
            // chart3
            // 
            chartArea2.AxisX.IsStartedFromZero = false;
            chartArea2.AxisY.IsStartedFromZero = false;
            chartArea2.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart3.Legends.Add(legend2);
            this.chart3.Location = new System.Drawing.Point(1612, 507);
            this.chart3.Name = "chart3";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart3.Series.Add(series2);
            this.chart3.Size = new System.Drawing.Size(819, 344);
            this.chart3.TabIndex = 2;
            this.chart3.Text = "chart3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2445, 911);
            this.Controls.Add(this.chart3);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.loginButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tPSumInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRealInfo)).EndInit();
            this.tcAccount.ResumeLayout(false);
            this.account1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccount)).EndInit();
            this.tabMissed.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMissed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.tcTotalInfo.ResumeLayout(false);
            this.account11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTotal)).EndInit();
            this.tcStrategies.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDynamicStr)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStrVolSoar)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStaticStr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        public AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.Button btnReSet;
        private System.Windows.Forms.Button btnSellAll;
        private System.Windows.Forms.Button realDataButton;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnSellAll02;
        private System.Windows.Forms.Button btnCancelAllBuy;
        private System.Windows.Forms.Button btnCancelAllSell;
        private System.Windows.Forms.Button btnRegRemove;
        private System.Windows.Forms.ListBox listBoxAccount;
        public System.Windows.Forms.ListBox logListBox;
        private System.Windows.Forms.Button btnReport;
        private TabControl tcTotalInfo;
        private TabPage account11;
        private DataGridView dgvTotal;
        private TabPage tabPage11;
        private TabControl tcAccount;
        private TabPage account1;
        private DataGridView dgvAccount;
        private TabPage tabMissed;
        private DataGridView dgvMissed;
        private TabPage tabPage10;
        private TabPage tabPage12;
        private TabPage tabPage13;
        private TabControl tcStrategies;
        private TabPage tabPage1;
        public DataGridView dgvDynamicStr;
        private TabPage tabPage2;
        private DataGridView dgvTest;
        private TabPage tabPage4;
        public DataGridView dgvStrVolSoar;
        private TabPage tabPage5;
        private Button btnSaveStr;
        private TabControl tabControl1;
        private TabPage tabPage3;
        private DataGridView dgvStaticStr;
        private TabPage tabPage6;
        private Label label1;
        private Button btnResult;
        private TabControl tabControl2;
        private TabPage tabPage7;
        private DataGridView dgvResult;
        private TabPage tabPage8;
        private Label label2;
        private TabControl tabControl3;
        private TabPage tPSumInfo;
        private DataGridView dgvRealInfo;
        private TabPage tabPage14;
        private Button btnSaveResult;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
    }



}

