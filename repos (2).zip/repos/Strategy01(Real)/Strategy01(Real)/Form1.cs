﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Strategy01_Real_
{
    public partial class Form1 : Form
    {
        public int orderCount = 0;              // 매수 주문 종목 갯수
        public string accNumber = "";
        string currentPrice;      // for receiving data splited from the real time data
        int screenNumber = 1001;
        string codeList = "";       // for SetRealReg()        
        Stock[] stockArray;
        Stock[] stockArray02;
        Filter filter01;
        Group group01;
        Group group02;
        public DataTable dtRealTime;       // from chejandata to datagridview of realtime data

        public Form1()
        {
            InitializeComponent();
            Init();
        }

        public void Test()
        {
            S_Daily50Drop Drop50 = new S_Daily50Drop("first");
            Console.WriteLine(Drop50.Title);
        }

        public void Init()
        {
            filter01 = new Filter(this);
            group01 = new Group();
            loginButton.Click += Button_Click;
            realDataButton.Click += Button_Click;               //substep 1 :  send "setrealreg" function of codeList to the server.
            btnSellAll.Click += Button_Click;                   // Sell All the stocks
            btnSellAll02.Click += Button_Click;
            btnCancelAllBuy.Click += Button_Click;              // 매수취소(전량)
            btnCancelAllSell.Click += Button_Click;             // 매도취소(전량)            
            btnRegRemove.Click += Button_Click;              // remove setrealreg 
            btnReport.Click += Button_Click;
            btnReSet.Click += Button_Click;
            btnSaveStr.Click += Button_Click;
            btnResult.Click += Button_Click;
            btnSaveResult.MouseHover += Button_Click;
            tcStrategies.SelectedIndexChanged += Str_SelectedIndexChanged;    // TabControl Event
            tcAccount.SelectedIndexChanged += Account_SelectedIndexChanged;    // TabControl Event
            tcTotalInfo.SelectedIndexChanged += Total_SelectedIndexChanged;    // TabControl Event 

            dgvRealInfo.CellClick += RealTimeTableClick;                                 // Datagridview Event            

            listBoxAccount.SelectedIndexChanged += SelectedIndexChanged;
            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;            
            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;            
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;
            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;        // background event (system event) for real time data from Kiwoom Server.

            

            //Chart();

            //axKHOpenAPI1.CommConnect();
        }

        public void RequestDailyChart(string code)         // from kiwoom server to realtime chart via trdata request.
        {
            if (code[0]== '0'|| code[0] == '1'|| code[0] == '2'|| code[0] == '3'|| code[0] == '4')  
            {
                axKHOpenAPI1.SetInputValue("종목코드", code);
                axKHOpenAPI1.SetInputValue("기준일자", "");
                axKHOpenAPI1.SetInputValue("수정주가구분", "");
                int result = axKHOpenAPI1.CommRqData("DailyCandle2", "opt10081", 0, GetScreenNumber());
            }
        }

        public void RequestMinuitChart(string code)         // from kiwoom server to realtime chart via trdata request.
        {
            if (code[0] == '0' || code[0] == '1' || code[0] == '2' || code[0] == '3' || code[0] == '4')
            {
                axKHOpenAPI1.SetInputValue("종목코드", code);
                axKHOpenAPI1.SetInputValue("틱범위", "1:1");
                axKHOpenAPI1.SetInputValue("수정주가구분", "");
                int result = axKHOpenAPI1.CommRqData("MinuiteCandle", "opt10080", 0, GetScreenNumber());
            }
        }

        public void Chart()         // Draw chart of dailyCandle
        {
            //step 1 :  collect data from server folder in local computer  // csvstyle in memory from the file.
            Server server = new Server("dailyCandle000020.txt");
            DataTable dt = CSVStyleToDataTable(server.csvStyle);

            //step 2 :  Add points in the chart series.
            for (int i = 599; i >= 0; i--)
            {
                string x = (dt.Rows[i][5].ToString().Trim());
                long y = long.Parse(dt.Rows[i][4].ToString().Trim());

                chart1.Series["Series1"].Points.AddXY(x, y);
            }
        }

        public void RealTimeTableClick(object sender, EventArgs e)
        {
            //p(dgvRealInfo.SelectedCells[0].Value.ToString());
            RequestDailyChart(dgvRealInfo.SelectedCells[0].Value.ToString());
            RequestMinuitChart(dgvRealInfo.SelectedCells[0].Value.ToString());
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
                axKHOpenAPI1.CommConnect();
            else if (sender.Equals(realDataButton))         // send "SetRealReg"
                RQSetRealReg(codeList);
            else if (sender.Equals(btnSellAll))             // check account And Sell all the socks
                RQAccountInfo(accNumber, "일괄매도(시장가)");
            else if (sender.Equals(btnSellAll02))           // check account And Sell all the socks
                RQAccountInfo(accNumber, "일괄매도(지정가)");
            else if (sender.Equals(btnCancelAllBuy))        // check reserved stocks And Sell all the socks
                RQMissedStock(accNumber, "전량매수주문취소");
            else if (sender.Equals(btnCancelAllSell))        // check reserved stocks And Sell all the socks
                RQMissedStock(accNumber, "전량매도주문취소");
            else if (sender.Equals(btnRegRemove))              // SetRealRegRemove                
                axKHOpenAPI1.SetRealRemove("ALL", "ALL");
            else if (sender.Equals(btnReport))
                RQAccountInfo(accNumber, "Report");
            else if (sender.Equals(btnReSet))        // check reserved stocks And Sell all the socks
                Setting();
            else if (sender.Equals(btnSaveStr))        // Save a Strategy
                SaveStr();
            else if (sender.Equals(btnResult))
                ComputeResult();
            else if (sender.Equals(btnSaveResult))
                SaveResult();
                //TestSituation();
        }

        public void SaveResult()
        {
            string[] result = DataTableToCSVStyle(dtRealTime);
            File.WriteAllLines(@"C:\Users\user\Desktop\stock\strategy\commonData\result.txt", result);
            //dgvRealInfo
        }

        public void ComputeResult()         // Total Result
        {           
            double totalSum = 0;
            string[] filenames = Directory.GetFiles(@"C:\Users\user\Desktop\stock\strategy\commondata\Report");

            foreach (string file in filenames)
            {                
                string[] result = File.ReadAllLines(@file);
                DataTable dt = CSVStyleToDataTable(result);
                //string header = "종목코드,종목명,보유수량,평균단가,현재가,M손익금액,M손익율";
                double sum = 0;                

                for (int i = 0; i < result.Length - 1; i++)                  //step 2 : caluate each stockcode
                {
                    sum = sum + double.Parse(dt.Rows[i]["M손익금액"].ToString());
                }
                totalSum += sum;

                //result = DataTableToCSVStyle(dt, header);
                //dt = CSVStyleToDataTable(result);
                //dgvResult.DataSource = dt;
                //p(sum);
            }
            //p(totalSum);
        }

        private void SaveStr()
        {
            //step1:file open
            string[] str = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\commondata\DynamicStr\StrVolSoar.txt");
            string[] compare = new string[1];
            string dgvRowData = "";
            for (int i=0; i< dgvStrVolSoar.Rows.Count-1;i++)
            {
                if (i< dgvStrVolSoar.Rows.Count - 2)
                {

                }
                else
                {
                    //p(rowData.Cells[0].Value.ToString());  DataGridViewRow rowData in dgvStrVolSoar.Rows  DataGridViewCell cell in rowData.Cells 
                    dgvRowData = "";
                    for (int j = 0; j < dgvStrVolSoar.Columns.Count; j++)
                    {
                        string data = dgvStrVolSoar.Rows[i].Cells[j].Value.ToString();
                        p(data);

                        dgvRowData = dgvRowData + data + ',';

                        //p(cell.Value.ToString());                    
                    }
                    dgvRowData = dgvRowData.TrimEnd(',');
                    compare[0] = dgvRowData;
                }
            }

            //step2:check line by line if the strategy already exists
            for (int i= 0; i<str.Length; i++)
            {
                if (str[i] == compare[0])
                {
                    p("same");
                    break;
                }
                else   // append the rowdata to the file
                {
                    if (i== str.Length-1)
                    {
                        p("end line");
                        compare[0] = "\r\n" + compare[0];
                        File.AppendAllText(@"C:\Users\user\Desktop\stock\strategy\commondata\DynamicStr\StrVolSoar.txt", compare[0]);
                    }
                }                
            }
        }

        private void Str_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tcStrategies.SelectedTab == tabPage1)
                StrDaily();

            else if (tcStrategies.SelectedTab == tabPage2)
                StrWinds();

            else if (tcStrategies.SelectedTab == tabPage4)
                StrVolSoar();
        }

        private void Account_SelectedIndexChanged(object sender, EventArgs e)   //Tabs_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tcAccount.SelectedTab == tabMissed)
                RQMissedStock(accNumber, "미체결요청");
            else if (tcAccount.SelectedTab == account1)
                RQAccountInfo(account1.Text, "Account");            
        }
        public void Total_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tcTotalInfo.SelectedTab == account11)
                RQAccountInfo(account11.Text, "TotalInfo");
        }

        public void ReportToFile()      // 1.save strategy, 2. save account info, 3. save time
        {
            string[] str = Collect();              // step 1: collect the result
            string time = DateTime.Now.ToString("yyyy_MM_dd");
            time = time + ".txt";
            //time = "bb b.txt";
            File.WriteAllLines(@"C:\Users\user\Desktop\stock\strategy\commondata\Report\"+ time, str);

            //p(time);

        }
        public string[] Collect()
        {
            DataTable dt;
            List<string> list = new List<string>() { "종목코드","종목명","보유수량","평균단가","현재가","M손익금액","M손익율" };        //step 1 : receive 계좌평가현황
            string header = "종목코드,종목명,보유수량,평균단가,현재가,M손익금액,M손익율";
            string[] csv = TRToCsvStyle(list, "opw00004", "Report");
            dt = CSVStyleToDataTable(csv);

            for (int i = 0; i < csv.Length - 1; i++)                  //step 2 : caluate each stockcode
            {
                double curPrice = double.Parse(dt.Rows[i]["현재가"].ToString());
                double averagePrice = double.Parse(dt.Rows[i]["평균단가"].ToString());
                double volumn = double.Parse(dt.Rows[i]["보유수량"].ToString());
                double profitPerOne = ((curPrice - curPrice * 0.0026) - averagePrice);

                dt.Rows[i]["M손익금액"] = ((curPrice - curPrice * 0.0026) - averagePrice) * volumn;
                dt.Rows[i]["M손익율"] = (profitPerOne - averagePrice)/averagePrice;
            }
            csv = DataTableToCSVStyle(dt);
            //csv = DataTableToCSVStyle(dt, header);
            return csv;
        }

        // 계좌 평가 현황 요청      // Invoke OnReceiveTrData()
        public void RQAccountInfo(string accountNum, string RQName)     // Request of Representstion of an account information.
        {            
            axKHOpenAPI1.SetInputValue("계좌번호", accountNum);
            axKHOpenAPI1.SetInputValue("비밀번호", "");
            axKHOpenAPI1.SetInputValue("상장폐지조회구분", "0");
            axKHOpenAPI1.SetInputValue("비밀번호입력매체구분", "00");
            axKHOpenAPI1.CommRqData(RQName, "OPW00004", 0, GetScreenNumber());       // Invoke OnReceiveTrData()
        }       

        // 미체결 주식 요청
        public void RQMissedStock(string accountNum, string rqName)
        {
            axKHOpenAPI1.SetInputValue("계좌번호", accountNum);
            axKHOpenAPI1.SetInputValue("전체종목구분", "0");
            axKHOpenAPI1.SetInputValue("매매구분", "0");
            axKHOpenAPI1.SetInputValue("종목코드", "");
            axKHOpenAPI1.SetInputValue("체결구분", "1");        // 체결구분 0:전체, 체결구분 1 : 순수 미체결
            axKHOpenAPI1.CommRqData(rqName, "opt10075", 0, "2030");       // Invoke OnReceiveTrData()
        }

        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            if (e.sRQName == "일괄매도(시장가)")           // if 게좌평가현황요청일 경우
                AccountInfo();      // 시장가 일괄 매도              
            else if (e.sRQName == "일괄매도(지정가)")          // if 게좌평가현황요청일 경우
                AccountInfo02();      // 지정가 일괄 매도  
            else if (e.sRQName == "전량매수주문취소")
                CancelAll(3);
            else if (e.sRQName == "전량매도주문취소")
                CancelAll(4);
            else if (e.sRQName == "미체결요청")
                MissedContract("opt10075", "미체결요청");
            else if (e.sRQName == "원주문번호")
            {
                List<string> list = new List<string>() { "종목코드", "종목명", "주문수량", "주문가격", "주문수량", "현재가", "주문번호" }; // FID item
            }
            else if (e.sRQName == "매도주문")
            {
            }
            else if (e.sRQName == "일봉차트a")
                DailyCandleCollect();
            else if (e.sRQName == "Account")
                AccInfo(dgvAccount);
            else if (e.sRQName == "TotalInfo")
                TotalInfo(dgvTotal);
            else if (e.sRQName == "Report")
                ReportToFile();
            else if (e.sRQName == "DailyCandle2")
                Chart2();
            else if (e.sRQName == "MinuiteCandle")
                Chart3();
                
        }

        public void Chart3()         // from kiwoom server(minuite candle) to chart
        {
            List<string> list = new List<string>() { "거래량", "시가", "고가", "저가", "현재가", "체결시간", };
            string[] csv = TRToCsvStyle(list, "opt10080", "MinuiteCandle");
            DataTable dt = CSVStyleToDataTable(csv);

            //step 2 :  from datatable to chart
            chart3.Series["Series1"].Points.Clear(); ;
            for (int i = dt.Rows.Count/5 - 1; i >= 0; i--)
            {
                string x = (dt.Rows[i][5].ToString().Trim());
                long y = Math.Abs(long.Parse(dt.Rows[i][4].ToString().Trim()));
                chart3.Series["Series1"].Points.AddXY(x, y);
            }
        }


        public void Chart2()         // from kiwoom server(daily candle) to chart
        {
            List<string> list = new List<string>() { "거래량", "시가", "고가", "저가", "현재가", "일자", };            
            string[] csv = TRToCsvStyle(list, "opt10081", "DailyCandle2");
            DataTable dt = CSVStyleToDataTable(csv);           

            //step 2 :  from datatable to chart
            chart1.Series["Series1"].Points.Clear();;
            for (int i = dt.Rows.Count-1; i >= 0; i--)
            {
                string x = (dt.Rows[i][5].ToString().Trim());
                long y = Math.Abs(long.Parse(dt.Rows[i][4].ToString().Trim()));
                chart1.Series["Series1"].Points.AddXY(x, y);
            }
        }

        public void AccountInfo()   // from server to csv style data to sell stocks
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가" }; // FID item
            string[] csv = TRToCsvStyle(list, "opw00004", "일괄매도(시장가)");
            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)
                list04.Add(code.Remove(0, 1));
            SellAllStocks(list04, list02, list03);          // 시장가 일괄 매도
        }

        public void AccountInfo02() // from server to csv style data to sell stocks
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가", "매입금액" }; // FID item
            string[] csv = TRToCsvStyle(list, "opw00004", "일괄매도(지정가)");
            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list05 = ExtractColumndata(csv, "매입금액");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)
                list04.Add(code.Remove(0, 1));

            SellAllStocks02(list04, list02, list03);          // 지정가 일괄 매도
        }

        
        public void CancelAll(int orderType)     // from server to csvstyle data to cancel 전량매수주문취소// 전량매도주문취소
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "미체결수량", "평균단가", "주문번호" }; // FID item
            string[] csv = TRToCsvStyle(list, "opt10075", "전량매도주문취소");

            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "미체결수량");            // return column data from csvstyle data
            List<string> list07 = ExtractColumndata(csv, "주문번호");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)
            {
                //list04.Add(code.Remove(0, 1).Trim());
            }
            p();
            CancelEachAndEvery(list01, list02, list03, list07, orderType);
        }

        //Sell All the stocks in once.
        public void CancelEachAndEvery(List<string> stockcodes, List<string> boughtPrices, List<string> volumn, List<string> originNum, int orderType)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {

                //int vol = int.Parse(volumn[i]);
                p();
                p(volumn[i]);

                int vol = 1;

                //boughtPrice = PriceUnit(boughtPrice);
                int result = axKHOpenAPI1.SendOrder("그냥", GetScreenNumber(), accNumber, orderType, stockcodes[i], vol, 0, "03", originNum[i]);
                
                if (result == 0)
                {
                    logListBox.Items.Add("매도취소주문");
                }
                Thread.Sleep(300);
            }
            /*********
            *********/
        }

        public void MissedContract(string trCode, string rqName)    //from server(미체결 정보) to datatable
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "주문수량", "주문가격", "현재가", "주문번호" }; // FID item
            string[] list02 = TRToCsvStyle(list, trCode, rqName);
            DataTable dt = CSVStyleToDataTable(list02);
            dgvMissed.DataSource = dt;
        }

        public void AccInfo(DataGridView dgv)   //from server(계좌 정보) to datatable
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가", "현재가","M손익금액", "M손익율","평가금액", "결제잔고" };        //step 1 : receive 계좌평가현황
            string[] csv = TRToCsvStyle(list, "opw00004", "Account");
            DataTable dt = CSVStyleToDataTable(csv);
            
            for (int i = 0; i < csv.Length - 1; i++)                  //step 2 : caluate each stockcode
            {
                double curPrice = double.Parse(dt.Rows[i]["현재가"].ToString());
                double averagePrice = double.Parse(dt.Rows[i]["평균단가"].ToString());
                double volumn = double.Parse(dt.Rows[i]["보유수량"].ToString());
                double profitPerOne = ((curPrice - curPrice * 0.0026) - averagePrice);
                dt.Rows[i]["M손익금액"] = ((curPrice - curPrice * 0.0026) - averagePrice) * volumn;                
                dt.Rows[i]["M손익율"] = (profitPerOne - averagePrice)/averagePrice;
            }

            //object result;
            //result = dt.Compute("Sum(M손익금액)", "");
            //DataRow row = dt.NewRow();
            //dt.Rows.Add(row);
            //dt.Rows[dt.Rows.Count-1][5] = result.ToString();


            //PrintDataTable(dt);
            dgv.DataSource = dt;                              //step 4 : return the reault(show the result to the datagridview)            
        }

        public void TotalInfo(DataGridView dgv) //from server(계좌 정보) to datatable
        {
            List<string> list = new List<string>() { "종목번호", "종목명", "결제잔고", "매입단가", "현재가", "현재잔고", "M손익율", "평가금액" };        //step 1 : receive 계좌평가현황
            string[] csv = TRToCsvStyle(list, "opw00004", "TotalInfo");
            DataTable dt = CSVStyleToDataTable(csv); 
            dgv.DataSource = dt;                              
        }

        private void PrintDataTable(DataTable table)    //from datatable to console out
        {
            foreach (DataRow row in table.Rows)
            {
                foreach (DataColumn column in table.Columns)
                {
                    Console.Write(row[column]);
                    Console.Write(',');
                }
                //p();
                Console.WriteLine();
            }
        }

        
        public DataTable CSVStyleToDataTable(string[] csvStyleData)     // from csv style to datatable
        {
            DataTable dt = new DataTable();
            DataRow rowData;
            DataColumn column;
            DataColumn[] columns2 = new DataColumn[1];
            string[] cellData;
            int j = 0;

            foreach (string line in csvStyleData)
            {
                cellData = line.Split(',');
                if (j == 0)
                {
                    for (int i = 0; i < cellData.Length; i++)
                    {
                        column = new DataColumn(cellData[i]);
                        dt.Columns.Add(column);
                    }
                    column = new DataColumn("Key", typeof(int));
                    column.AutoIncrement = true;
                    column.AutoIncrementSeed = 1;
                    column.AutoIncrementStep = 1;
                    columns2[0] = column;
                    dt.Columns.Add(column);
                    dt.PrimaryKey = columns2;
                    j++;
                    continue;
                }

                rowData = dt.NewRow();
                for (int i = 0; i < cellData.Length; i++)
                {
                    rowData[i] = cellData[i];  
                }               

                dt.Rows.Add(rowData);
                j++;
            }            
            return dt;
        }

        public string[] DataTableToCSVStyle(DataTable dt)   // from datatable to csv style
        {
            int rowLength = dt.Rows.Count;
            int columnLength = dt.Columns.Count;
            string[] csvStyle = new string[rowLength + 1];
            string str = "";
            string str02 = "";      // for header
            string temp = "";

            foreach (DataColumn column in dt.Columns)       // for header
            {
                str02 = str02 + column.ToString() + ',';
            }
            str02 = str02.TrimEnd(',');
            csvStyle[0] = str02;                            // for header
            

            for (int i = 0; i < rowLength; i++)
            {
                str = "";
                for (int j = 0; j < columnLength; j++)
                {
                    temp = dt.Rows[i][j].ToString();
                    str = str + temp + ',';
                }
                str = str.TrimEnd(',');
                csvStyle[i + 1] = str;
            }
            return csvStyle;
        }
        public string[] DataTableToCSVStyle(DataTable dt, string header)    // from datatable to csv style
        {
            int rowLength = dt.Rows.Count;
            int columnLength = dt.Columns.Count;
            string[] csvStyle = new string[rowLength +1];
            string str = "";            
            string temp = "";


            csvStyle[0] = header;           // input header

            for (int i = 0; i < rowLength ; i++)
            {
                str = "";
                for (int j=0; j<columnLength; j++)
                {
                    temp = dt.Rows[i][j].ToString();
                    str = str + temp + ',';
                }
                str = str.TrimEnd(',');
                csvStyle[i+1] = str;
            }
            return csvStyle;
        }

        public void StrDaily()  //setting
        {
            logListBox.Items.Clear();
            DynamicStrDaily("StrDaily.txt");
            Setting();
        }

        public void StrWinds()  // from file(stock codes) to stockArray02
        {
            logListBox.Items.Clear();
            // Step 1 : Collect stock codes from data of stock list
            string codeName = "";
            string[] codes = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\strategy11Winds\strWinds.txt");
            
            List<string> list = ExtractColumndata(codes, "code");
            List<string> name = ExtractColumndata(codes, "name");

            group02 = new Group(list, name);
            int length02 = group02.codeList.Count;
            stockArray02 = new Stock[length02];

            for (int i = 0; i < length02; i++)            
                stockArray02[i] = new Stock(this, group02.codeList[i], group02.codeName[i]);
            
            RefreshCodeList(group02.codeList);

            // FilterDailyCandle();
            
            ShowFilteredCodeList(group02);          //Show the result of the filtered codelist before sending SetRealReg
        }

        public void StrVolSoar()            // Strategy : 거래량 급증
        {
            logListBox.Items.Clear();           
            DynamicStrVolSoar("strVolSoar.txt");
            Setting();
        }

        //public void StaticSetting(double cap, double profit, double debt, int netProfitRate, double relToMaxP)//, int wave, int timing, int soaring)
        public void StaticSetting(string filename)//, int wave, int timing, int soaring)
        {
            string filePath = @"C:\Users\user\Desktop\stock\strategy\commondata\StaticStr\" + filename;
            string[] csvStyle = File.ReadAllLines(filePath);        // step1  : file to csvstyle            
            DataTable dt04 = CSVStyleToDataTable(csvStyle);         // step2  : csvstyle to datatable  
            dgvStaticStr.DataSource = dt04;                        // step3  : datable to datagridview

        }
        public void Setting()
        {
            logListBox.Items.Clear();            

            var allCodesInfo = filter01.Start01();      // step 1 Filter the codelist from "first.txt"  // csv data filtering
            string str = dgvStaticStr.Rows[0].Cells[0].Value.ToString();
            string str02 = dgvStaticStr.Rows[0].Cells[1].Value.ToString();
            string str03 = dgvStaticStr.Rows[0].Cells[2].Value.ToString();
            string str04 = dgvStaticStr.Rows[0].Cells[3].Value.ToString();
            string str05 = dgvStaticStr.Rows[0].Cells[4].Value.ToString();
            
            int capital = int.Parse(str);
            int profit = int.Parse(str02);
            int debt = int.Parse(str03);
            int netProfitRate = int.Parse(str04);
            double relToMaxP = double.Parse(str05);
            
            //int volRate = int.Parse(str06);

            group01 = filter01.GroupProducer(allCodesInfo, capital, profit, debt, netProfitRate, relToMaxP);    // step 1.2 Group the code list
            int length = group01.codeList.Count;        // step 1.3 observe one code of market items
            stockArray = new Stock[length];

            for (int i = 0; i < length; i++)            
                stockArray[i] = new Stock(this, group01.codeList[i], group01.codeName[i]);
            
            RefreshCodeList(group01.codeList);      // refresh codelist for SetRealReg accoding to the strategy. e.g. code;code;code

            // FilterDailyCandle();

            //Show the result of the filtered codelist before sending SetRealReg
            ShowFilteredCodeList(group01);
            RealTimeTableSetting();

        } 

        public void RealTimeTableSetting()
        {
            dtRealTime = new DataTable();         // for chejandata to datagridview of realtime data
            string header = "code,name,continuity,현재가,매수가,매도가,거래량,매수거래량,매도거래량,체결시간,체결강도,등락율,거래대금증감,시가총액,체결횟수";

            int rowNumber = group01.codeList.Count;
            List<string> list = group01.codeList;
            List<string> listN = group01.codeName;
            int[] numbers = new int[rowNumber];                 // for the item of "continuity"
            for (int i = 0; i < rowNumber; i++)                 // dummy data
                numbers[i] = 1;
            List<int> listNum = new List<int>(numbers);         // for the item of "continuity"

            string[] csvStyle = new string[rowNumber + 1];
            csvStyle[0] = header;
            for (int i = 1; i < rowNumber + 1; i++)                     // each row data
            {
                string list2 = "";
                list2 = list[i - 1] + ',' + listN[i - 1] +','+ listNum[i-1];
                csvStyle[i] = list2;
            }
            dtRealTime = CSVStyleToDataTable(csvStyle);

            
            dgvRealInfo.DataSource = dtRealTime;
            dgvRealInfo.Columns[2].Width = 60;
            dgvRealInfo.Columns[3].Width = 60;
            dgvRealInfo.Columns[4].Width = 60;
            dgvRealInfo.Columns[5].Width = 60;
            dgvRealInfo.Columns[6].Width = 60;
            dgvRealInfo.Columns[7].Width = 60;
            dgvRealInfo.Columns[8].Width = 60;
            dgvRealInfo.Columns[9].Width = 60;
            dgvRealInfo.Columns[10].Width = 60;
            dgvRealInfo.Columns[11].Width = 60;
        }

        public void TestSituation()
        {
            //int k = 1;
            //string ex = "Key > " + k;
            //DataRow[] dr = dtRealTime.Select(ex);
            //p(dr[1][1]);
            //int sum = int.Parse(dr[0][2].ToString()) + 20;
            //dr[0][2] = sum;
            //dr[1][4] = "aaa";

            //dgvRealInfo.DataSource = dtRealTime;

            //DataView dv = dtRealTime.DefaultView;
            //dv.Sort = "code desc";
            //dtRealTime = dv.ToTable();

            dtRealTime.DefaultView.Sort = "code desc";
            dtRealTime = dtRealTime.DefaultView.ToTable(true);            

            dgvRealInfo.DataSource = dtRealTime;
        }

        public void ChangeRealTime(string code, string curprice)
        {
            string ex = "code = " + code;
            DataRow[] dr = dtRealTime.Select(ex);

            dr[0][3] = curprice;
            int sum = int.Parse(dr[0][2].ToString()) + 1;
            dr[0][2] = sum;

            //DataView dv = dtRealTime.DefaultView;
            //dv.Sort = "code desc";
            //dtRealTime = dv.ToTable();


            //dr[1][4] = "aaa";

            //dgvRealInfo.DataSource = dtRealTime;
        }



        // Return a string to be sent as SetRealReg parameter from input
        public string FilterDailyCandle(Group group)
        {
            // step 1 : collect the daily candles according to the code list. And Save them to the file
            string[] list = group.codeList.ToArray();
            Arrange(list);
            // step 2 : Filter the daily candles.
            string str = FilterCandles("aa");

            return str;
        }
 
        public void DailyCandleCollect()
        {
            string str04 = "";
            string str05 = "";
            string strData1 = "";
            string strData2 = "";
            string strData3 = "";
            string strData4 = "";
            string strData5 = "";
            string strData6 = "";
            string strData7 = "";

            string title = "거래량,시가,고가,저가,현재가,거래일자\r\n";

            int nCnt = axKHOpenAPI1.GetRepeatCnt("opt10081", "일봉차트");

            str05 = title;

            for (int nIdx = 0; nIdx < nCnt; nIdx++)
            {
                if (nIdx == 0)
                {
                    strData7 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "종목코드").Trim();
                }
                strData1 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "거래량").Trim(); // nIdx번째의 거래량 데이터 구함
                strData2 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "시가").Trim();
                strData3 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "고가").Trim();
                strData4 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "저가").Trim();
                strData5 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "현재가").Trim();
                strData6 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "일자").Trim();

                str04 = str04 + strData1 + "," + strData2 + "," + strData3 + "," + strData4 + "," + strData5 + "," + strData6 + "\r\n";
                str05 += str04;

                str04 = "";
            }
            File.WriteAllText(@"C:\Users\user\Desktop\stock\strategy\server\dailyCandle" + strData7 + ".txt", str05);
        }

        // step 3 Arrange the list with code name.
        public void Arrange(string[] strArr)
        {
            foreach (string str in strArr)
            {
                // step 2 : Tr Data 요청 OnreceiveTrData
                axKHOpenAPI1.SetInputValue("종목코드", str);

                //기준일자 = YYYYMMDD(20160101 연도4자리, 월 2자리, 일 2자리 형식)
                axKHOpenAPI1.SetInputValue("기준일자", "");

                //수정주가구분 = 0 or 1, 수신데이터 1:유상증자, 2:무상증자, 4:배당락, 8:액면분할, 16:액면병합, 32:기업합병, 64:감자, 256:권리락
                axKHOpenAPI1.SetInputValue("수정주가구분", "");

                int result = axKHOpenAPI1.CommRqData("일봉차트a", "opt10081", 0, GetScreenNumber());
                Thread.Sleep(1000);
            }
        }

        // step 2 : Filter the daily candles. And return a string of newly filtered code list. e.g. "000020;000040;000050" (semi colon separated)
        public string FilterCandles(string str)
        {
            List<string> list09 = new List<string>();
            foreach (string str03 in list09)
            {
                // step 1 : file data to momory in csvstyle

                // step 2 : csvstyle to DataTable

                // step 3 : apply algorithm to the DataTable
                FilterCandle();

                // step 4 : for if

                // step 5 : return file name.
            }
            return "a";
        }

        public void FilterCandle()
        {

        } 

        public void ShowFilteredCodeList(Group group)
        {
            logListBox.Items.Add($"항목수 : {group.codeName.Count}");
            logListBox.Items.Add($"항목수02 : {group.codeList.Count}");
            foreach (string str05 in group.codeName)
            {
                logListBox.Items.Add(str05);            
            }
        }

        public void RefreshCodeList(List<string> codes)     // refresh codelist for SetRealReg accoding to the strategy. e.g. code;code;code
        {
            codeList = "";
            foreach (string str in codes)
                codeList = codeList + str + ";";
            codeList = codeList.Trim(';');
        }

        public void SelectedIndexChanged(object sender, EventArgs e)
        {
            accNumber = listBoxAccount.SelectedItem.ToString();
            RQAccountInfo(accNumber, "Account");         // StockInfo to DataGridView
        }

         // oneventconnect
        private void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            listBoxAccount.Items.Clear();
            if (e.nErrCode == 0)
            {
                string accountList = axKHOpenAPI1.GetLoginInfo("ACCLIST");
                accountList = accountList.Trim(new char[] { ';' });
                string[] accountArray = accountList.Split(';');

                for (int i = 0; i < accountArray.Length; i++)                    
                    listBoxAccount.Items.Add(accountArray[i]);

                //StaticSetting(100, 100, 200, 5, -30);
                StaticSetting("staticStr.txt");
                Setting();
                StrVolSoar();
                //DynamicStrToDgvDynamicStr();
            }

            RequestDailyChart("000040");
            RequestMinuitChart("000040");

            //StrDaily();         // strategy daily
            //RQSetRealReg(codeList);     // send SetRealReg
        }

        private void API_OnReceiveMsg(object sendeer, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            logListBox.Items.Add($"Msg from server : {e.sMsg}");
            Console.WriteLine($"Msg from server : {e.sMsg}");
        }

        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            if (e.sGubun.Equals("0"))       // 접수 or 체결
            {
                string orderState = axKHOpenAPI1.GetChejanData(913);        // 접수 or 체결
                if (orderState.Equals("접수"))                
                    logListBox.Items.Add("접수 호출");        
                else if (orderState.Equals("체결"))
                {
                    string distinguish = axKHOpenAPI1.GetChejanData(907);
                    logListBox.Items.Add($"매도수 구분 : {distinguish}");
                    if (distinguish == "1")         // 매도 체결 인경우    send the info to the DataTable of dgvRealInfo
                    {
                        string code = axKHOpenAPI1.GetChejanData(9001);
                        string account = axKHOpenAPI1.GetChejanData(9201);
                        string orderNum = axKHOpenAPI1.GetChejanData(9203);
                        string soldPrice = axKHOpenAPI1.GetChejanData(910);
                        string volumn = axKHOpenAPI1.GetChejanData(911);
                        code = code.Trim().Remove(0, 1);
                        int vol = int.Parse(volumn);
                        ToRealInfoTableS(code, soldPrice, volumn);                  // send the info to the realtime datatable
                    }
                    
                    else if (distinguish == "2")        // "매수체결 인경우" send_selling_order and send the info to the DataTable of dgvRealInfo
                    {
                        string code = axKHOpenAPI1.GetChejanData(9001);
                        string account = axKHOpenAPI1.GetChejanData(9201);
                        string orderNum = axKHOpenAPI1.GetChejanData(9203);
                        string boughtPrice = axKHOpenAPI1.GetChejanData(910);
                        string volumn = axKHOpenAPI1.GetChejanData(911);
                        code = code.Trim().Remove(0, 1);
                        int vol = int.Parse(volumn);

                        double proposedPrice = double.Parse(boughtPrice) * 0.02 + double.Parse(boughtPrice);
                        int proposed = (int)proposedPrice;
                        int priceToSell = justifyPrice(proposed);

                        SendOrder_Sell(code, priceToSell, vol);

                        ToRealInfoTableB(code, boughtPrice, volumn);          // send the info to the realtime datatable
                    }                    
                }
            }             
        } 

        public void ToRealInfoTableS(string code, string price, string volumn)      // 매도체결 시
        {
            string ex = "code = " + code;
            DataRow[] dr = dtRealTime.Select(ex);

            dr[0][5] = price;

            int vol = int.Parse(volumn.ToString());
            int sum = int.Parse(dr[0][8].ToString()) + vol;     // 매도 거래량합계
            dr[0][8] = sum;
        }

        public void ToRealInfoTableB(string code, string price, string volumn)      // 매수체결 시
        {
            string ex = "code = " + code;
            DataRow[] dr = dtRealTime.Select(ex);

            dr[0][4] = price;

            int vol = int.Parse(volumn.ToString());
            int sum = int.Parse(dr[0][7].ToString()) + vol;     // 매수 거래량 합계
            dr[0][7] = sum;
        }


        public void justifyAll()
        {
            //justifyPrice();
        }



        // Distribute each code(group01.filteredCodeList) to each object(StockCode class) to find best condition and send order
        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            string volumn;

            for (int i = 0; i < group01.codeList.Count; i++)
            {
                if (e.sRealKey == group01.codeList[i])
                {
                    // data splited from the real time data
                    currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가
                    currentPrice = currentPrice.Trim(). Remove(0,1);
                    volumn = axKHOpenAPI1.GetCommRealData(e.sRealKey, 15);    // 거래량                    

                    Distribute02(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice, volumn);
                }
            }

            /***
            for (int i = 0; i < group01.codeList.Count; i++)
            {
                if (e.sRealKey == group01.codeList[i])
                {
                    // data splited from the real time data
                    currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가

                    Distribute(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice);
                    //Thread th = new Thread(()=>Distribute(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice));
                    //th.Start();
                }
            }
            ***/
        }



        //============TrRequest function===============


        //============TrReceive function===============
        // 미체결 정보

        public void ReceiveTr(List<string> list, string trCode, string rqName)
        {
            string[] list02 = TRToCsvStyle(list, trCode, rqName);
            DataTable dt = CSVStyleToDataTable(list02);
            //dgvAccountInfo.DataSource = dt;            
        }



        public string[] TRToCsvStyle(List<string> list, string orderCode, string rqName)         // Return csv-styled table data of List<string> from OnReceiveTrData
        {
            List<string> csvStyle = new List<string>();     // csv style in memory.
            string csvStyleHeader = "";         // header
            string rowData = "";                // rowdata

            //1. header part
            foreach (string item in list)            
                csvStyleHeader = csvStyleHeader + $"{item},";        
            csvStyleHeader = csvStyleHeader.TrimEnd(',');
            csvStyle.Add(csvStyleHeader);

            //2. body part
            int count = axKHOpenAPI1.GetRepeatCnt(orderCode, rqName);
            for (int i = 0; i < count; i++)
            {
                rowData = "";
                foreach (string item in list)                
                    rowData = rowData + axKHOpenAPI1.GetCommData(orderCode, rqName, i, item).Trim() + ",";                
                rowData = rowData.TrimEnd(',');
                csvStyle.Add(rowData);
            }
            string[] csvType = csvStyle.ToArray();
            return csvType;
        }
       
        //============TrReceive function===============


        //============Send order function===============
        public void SendOrder_Sell(string code, int proposedP, int volumn)
        {
            int result = axKHOpenAPI1.SendOrder("주식주문", GetScreenNumber(), accNumber, 2, code, volumn, proposedP, "00", null);
            if (result == 0)
            {
                logListBox.Items.Add($"매도 주문 요청 성공 : {code}, 매도 가격: {proposedP}");
            }
        }

        //Sell All the stocks in once.
        public void SellAllStocks(List<string> stockcodes, List<string> boughtPrices, List<string> volumn)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {
                int boughtPrice = int.Parse(boughtPrices[i]);
                int vol = int.Parse(volumn[i]);                     // 보유 수량
                boughtPrice = justifyPrice(boughtPrice);
                int result = axKHOpenAPI1.SendOrder("orderAll(시장가)", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, 0, "03", null);

                Thread.Sleep(300);
            }
        }

        //Sell All the stocks in once.
        public void SellAllStocks02(List<string> stockcodes, List<string> boughtPrices, List<string> volumn)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {
                int boughtPrice = int.Parse(boughtPrices[i]);
                int vol = int.Parse(volumn[i]);                     // 보유 수량
                boughtPrice = justifyPrice(boughtPrice);
                int result = axKHOpenAPI1.SendOrder("지정가매도주문", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, boughtPrice, "00", null);                
                
                Thread.Sleep(300);
            }
        }

        //============send order function===============

        // Distribute each code and price to each Stock object.        

 

        public void Distribute(Stock stock, string code, string name, string curPrice)
        {
            stock.Code = code;
            stock.Name = name;
            stock.currentPrice = curPrice;

            try
            {
                stock.GetTheChance();
            }

            catch
            {
                logListBox.Items.Add("exception occured");
            }
        }

        // Distribute each code and price to each Stock object.
        public void Distribute02(Stock stock, string code, string name, string curPrice, string volumn)
        {
            stock.Code = code;
            stock.Name = name;
            stock.currentPrice = curPrice;
            //stock.volumn.Add(volumn);

            try
            {
                stock.GetTheChance02(volumn, curPrice);
            }

            catch
            {
                logListBox.Items.Add("exception occured==========");
            }
        }

        //================= 실시간 데이터 요청
        public void RQSetRealReg(string codeList)
        {
            logListBox.Items.Add("codeList : " + codeList);

            int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server               
            if (result == 0)
                logListBox.Items.Add("setRealReg 요청 성공");
        }
        //================= 실시간 데이터 요청


        //============== utility function ======================
        public List<string> ExtractColumndata(string[] csvStyleData, string columnName)     // extract column data from csvstyle data
        {
            int j = 0;
            int index = 0;      // for column index
            List<string> columnData = new List<string>();

            foreach (string str in csvStyleData)
            {
                string[] items = str.Split(',');

                // header part
                if (j == 0)
                {
                    for (int i = 0; i < items.Length; i++)
                    {
                        if (items[i] == columnName)     // find the index of column asked of the columName
                        {
                            index = i;
                        }
                    }
                }

                // body part
                else
                {
                    for (int k = 0; k < items.Length; k++)
                    {
                        if (k == index)
                        {
                            columnData.Add(items[k]);
                        }
                    }
                }
                j++;
            }
            return columnData;
        }

        public string GetScreenNumber()
        {
            if (screenNumber == 9999)
                screenNumber = 1001;

            screenNumber++;
            string str = screenNumber.ToString();
            return str;
        }

        public void p()
        {
            Console.WriteLine("here===================");
        }
        public void p(object obj)
        {
            Console.WriteLine(obj);
        }

        public int justifyPrice(int proposedPrice)
        {
            if (proposedPrice < 1000)
            {
                proposedPrice = (proposedPrice / 1) * 1;
            }

            else if (proposedPrice < 5000)
            {
                proposedPrice = (proposedPrice / 5) * 5;
            }
            else if (proposedPrice < 10000)
            {
                proposedPrice = (proposedPrice / 10) * 10;
            }
            else if (proposedPrice < 50000)
            {
                proposedPrice = (proposedPrice / 50) * 50;
            }
            else if (proposedPrice < 100000)
            {
                proposedPrice = (proposedPrice / 100) * 100;
            }
            else if (proposedPrice < 500000)
            {
                proposedPrice = (proposedPrice / 500) * 500;
            }

            else
            {
                proposedPrice = (proposedPrice / 1000) * 1000;
            }
            return proposedPrice;
        }

        public void DynamicStrDaily(string filename)     // Csv file (of DynamicStr) to datagridview (of DynamicStr) onEventConnect.
        {
            string filePath = @"C:\Users\user\Desktop\stock\strategy\commondata\DynamicStr\" + filename;            
            string[] csvStyle = File.ReadAllLines(filePath);            // step1  : file to csvstyle
            DataTable dt03 = CSVStyleToDataTable(csvStyle);         // step2  : csvstyle to datatable
            dgvDynamicStr.DataSource = dt03;            // step3  : datable to datagridview
        }

        public void DynamicStrVolSoar(string filename)     // Csv file (of DynamicStr) to datagridview (of DynamicStr) onEventConnect.
        {
            string filePath = @"C:\Users\user\Desktop\stock\strategy\commondata\DynamicStr\" + filename;            
            string[] csvStyle = File.ReadAllLines(filePath);        // step1  : file to csvstyle            
            DataTable dt04 = CSVStyleToDataTable(csvStyle);         // step2  : csvstyle to datatable    
            dgvStrVolSoar.DataSource = dt04;                        // step3  : datable to datagridview
        }
        //============== utility function ======================
    }
}