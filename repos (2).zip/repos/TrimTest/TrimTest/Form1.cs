﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrimTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // String with whitespaces  
            string hello = " hello C# Corner has white spaces ";
            // Remove whitespaces from both ends  
            Console.WriteLine(hello.Trim());

            // String with characters  
            string someString = ".....My name is Mahesh Chand****";
            char[] charsToTrim = { '*', '.' };
            string cleanString = someString.Trim(charsToTrim);
            Console.WriteLine(cleanString);


            string codeList = "";

            List<string> filteredCodeList = new List<string>() {"aaa","bbb","ccc" };

            foreach (string str in filteredCodeList)
            {
                codeList = codeList + str + ";";
            }

            char[] toTrim = { ';' };

            //codeList.TrimEnd(toTrim);   // You have to return like below.
            codeList = codeList.TrimEnd(toTrim);

            Console.WriteLine("codeList : " + codeList );


            string str4 = "aaabbbc cc;,";

            char[] addd = { ',', 'k', ';'};

            str4 = str4.TrimEnd(',');

            Console.WriteLine(str4);
        }
    }
}
