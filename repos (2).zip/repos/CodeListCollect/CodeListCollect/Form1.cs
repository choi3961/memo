﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CodeListCollect
{
    // code list information of fundamental
    public partial class Form1 : Form
    {
        string codeList;
        string[] codeInfo = new string[20000];
        int iterator = 0;

        // step 1 Collect Codelist from the Kiwoom server : 
        // step 2 Filter the Code list into codeList[]
        // step 3 Arrange the list with code name.
        // step 4 Collect all the code list information into csv file.
        // step 5 Call the all the raw code list information from csv into memory.
        // step 6 Group the codeAndName
        public Form1()
        {
            InitializeComponent();

            string str = "종목코드,종목명,결산월,액면가,자본금,상장주식,신용비율,연중최고,연중최저,시가총액,시가총액비중,외인소진율,대용가,PER,EPS,ROE,PBR,EV,BPS,매출액,영업이익,당기순이익,250최고,250최저,시가,고가,저가,상한가,하한가,기준가,예상체결가,예상체결수량,250최고가일,250최고가대비율,250최저가일,250최저가대비율,현재가,대비기호,전일대비,등락율,거래량,거래대비,액면가단위,유통주식,유통비율\r\n";
            File.AppendAllText("codelistinfo.txt", str);

            codeList = "";                                          // 코스피 종목 리스트
         
            codeListButton01.Click += Button_Click;                 // button event
            codeListButton02.Click += Button_Click;
            codeListInfoButton01.Click += Button_Click;             // step 5 Call the all the raw code list information from csv into memory.
                                                                   
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;    // collect the code list information into csv file. step 4

            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;      // connect event
            axKHOpenAPI1.CommConnect();                             // connect
        }

        public void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(codeListButton01))
            {
                // step 1 Collect Codelist from the Kiwoom server : 
                codeList = axKHOpenAPI1.GetCodeListByMarket("0");         

                // step 2 Filter the raw data of the Code list into codeList[] ; remove " ; "
                Filter(codeList);

                // step 3 Arrange the list with code name.
                //arrange(); is called in Filter() function.
            }

            else if (sender.Equals(codeListButton02))
            {
                // step 1 Collect Codelist from the Kiwoom server : 
                codeList = axKHOpenAPI1.GetCodeListByMarket("10");

                // step 2 Filter the raw data of the Code list into codeList[] ; remove " ; "
                Filter(codeList);

                // step 3 Arrange the list with code name.
                //arrange(); is called in Filter() function.                                   // step 5 Call all the raw code list information from csv into memory.
            }

            else if (sender.Equals(codeListInfoButton01))
            {
                codeListInfoListBox01.Items.Add("success");
                rawInfo();                                            // step 5 Call all the raw code list information from csv into memory.
            }
        }

        public void Filter(string s)
        {
            codeList.Trim();

            string[] codeListArr = s.Split(';');

            // step 3 Arrange the list with code name.
            Arrange(codeListArr);

        }

        // step 3 Arrange the list with code name.
        public void Arrange(string[] strArr)
        {            
            for (int i = 0; i<strArr.Length; i++)
            {
                if (strArr[i].Length == 0)
                {
                }
                else
                {
                    axKHOpenAPI1.SetInputValue("종목코드", strArr[i]);                             //주식 기본정보요청
                    int sig = axKHOpenAPI1.CommRqData("주식기본정보요청", "opt10001", 0, "1001"); // OnReceivetTrData event 발생

                    string str = axKHOpenAPI1.GetMasterCodeName(strArr[i]);
                    string codeAndName = strArr[i] + " , " + str + ",";
                    Console.WriteLine(codeAndName);

                    File.AppendAllText("first02.txt", codeAndName);
                    //codeListBox01.Items.Add(codeAndName);

                    Thread.Sleep(4000);
                }            
            }
    
            // Group the codeAndName list
            //Group();
        }

        // Calll code list information form csv into memory
        public void rawInfo()
        {
            //matrix.GetLength(0)  -> Gets the first dimension size
            //matrix.GetLength(1)  -> Gets the second dimension size
        }

        // Group the codeAndName list
        public void Group()
        {

        }

        public void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            if (e.nErrCode == 0)
            {
                //Console.WriteLine("success");
            }
        }

        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            codeInfo[iterator] = e.ToString();
            iterator++;

            string str = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "종목코드").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "종목명").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "결산월").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "액면가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "자본금").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "상장주식").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "신용비율").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "연중최고").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "연중최저").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "시가총액").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "시가총액비중").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "외인소진율").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "대용가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "PER").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "EPS").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "ROE").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "PBR").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "EV").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "BPS").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "매출액").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "영업이익").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "당기순이익").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "250최고").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "250최저").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "시가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "고가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "저가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "상한가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "하한가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "기준가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "예상체결가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "예상체결수량").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "250최고가일").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "250최고가대비율").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "250최저가일").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "250최저가대비율").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "현재가").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "대비기호").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "전일대비").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "등락율").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "거래량").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "거래대비").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "액면가단위").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "유통주식").Trim();
            str += "," + axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "유통비율").Trim();
            str += "\r\n";

            File.AppendAllText("codelistinfo02.txt", str);

            Console.WriteLine("e.sTrcode = " + str);
        }
    }
}
