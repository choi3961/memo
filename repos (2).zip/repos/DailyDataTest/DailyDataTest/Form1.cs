﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DailyDataTest
{
    public partial class Form1 : Form
    {
        string codeToCall = "000020;000040;000050";
        string codeList;
        string[] codeInfo = new string[20000];
        int iterator = 0;
        string stockCode = "";

        int startNumber = 1001;

        DateTime bottomFoundTime;

        public Form1()
        {
            InitializeComponent();
            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;
            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;
            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;  
            btnDailyData.Click += ButtonClick;
            btnKw.MouseHover += ButtonEnter;
            btnVolAverage.MouseHover += ButtonEnter;

            Start();
            Chart();
        }

        public void Chart()         // Draw chart of dailyCandle
        {
            //step 1 :  collect data from server folder in local computer
            // csvstyle in memory from the file.
            Server server = new Server("dailyCandle000020.txt");
            DataTable dt = CSVStyleToDataTable(server.csvStyle);

            //step 2 :  Add points in the chart series.
            for (int i = 0; i < 600; i++)
            {
                string x = (dt.Rows[i][5].ToString().Trim());
                long y = long.Parse(dt.Rows[i][4].ToString().Trim());

                chart1.Series["Series1"].Points.AddXY(x,y);

                Console.WriteLine(x);
                Console.WriteLine(y);
            }

            //step 3 : 
            //step 4 : 
            //step 5 : 

        }


        public void Compare(int previous, int newly)
        {
            if (previous > newly)
            {
 
            }
            else
            {

            }
        }

        public void Insert(int vertical, int location, int value)
        {
            
        }

        public List<int> FindBottomPoints()
        {
            int newly;
            int flag = 0;
            int timePassed = 0;

            List<int> bPoints = new List<int>();
            bPoints.Add(3000000);

            // csvstyle in memory from the file.
            Server server = new Server("dailyCandle.txt");
            DataTable dt = CSVStyleToDataTable(server.csvStyle);

            for (int i =0; i<dt.Rows.Count ; i++)
            {
                // step 1 : retrieve data from the server
                newly = int.Parse(dt.Rows[i][3].ToString());

                // step 2 : compare the two data
                if (bPoints[flag] > newly)
                {
                    bPoints[flag] = newly;
                }
                else
                {
                    timePassed++;
                }

                if (timePassed>=20)
                {
                    bPoints.Add(newly);
                    flag++;
                    timePassed = 0;
                }
                // step 3 : if newly is low, change the data

            }

            foreach (int price in bPoints)
            {
                Console.WriteLine(price);
            }

            return bPoints;
        }

        public void Start()
        {
            axKHOpenAPI1.CommConnect();
            
        }



        // Return DataTable from csv styled data to show into DataGridView ================
        public DataTable CSVStyleToDataTable(string[] csvStyleData)
        {
            DataTable dt = new DataTable();
            DataRow rowData;
            DataColumn column;

            string[] cellData;

            int j = 0;

            foreach (string line in csvStyleData)
            {
                cellData = line.Split(',');

                if (j == 0)
                {
                    for (int i = 0; i < cellData.Length; i++)
                    {
                        column = new DataColumn(i + " " + cellData[i]);
                        dt.Columns.Add(column);
                    }
                    j++;
                    continue;
                }

                rowData = dt.NewRow();

                for (int i = 0; i < cellData.Length; i++)
                {
                    rowData[i] = cellData[i];
                }

                dt.Rows.Add(rowData);

                j++;
            }

            // step 3 : Return DataTable object
            return dt;
        }



        public void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            
            string[] str = { "aa, bb, cc" };

            string str9 = "aaa";
            //List<string> list4 = new List<string>(str9);   //{ "ss","vv","aa"};


            string[] codeList = new string[]{ "000050", "000040", "000020", "000060", "000070", "000075" };
            Arrange(codeList);
            //FindBottomPoints();
            //Chart();
        }
        // step 3 Arrange the list with code name.
        public void Arrange(string[] strArr)
        {
            foreach (string str in strArr)
            {
                // step 2 : Tr Data 요청 OnreceiveTrData
                axKHOpenAPI1.SetInputValue("종목코드", str);

                //기준일자 = YYYYMMDD(20160101 연도4자리, 월 2자리, 일 2자리 형식)
                axKHOpenAPI1.SetInputValue("기준일자", "");

                //수정주가구분 = 0 or 1, 수신데이터 1:유상증자, 2:무상증자, 4:배당락, 8:액면분할, 16:액면병합, 32:기업합병, 64:감자, 256:권리락
                axKHOpenAPI1.SetInputValue("수정주가구분", "");

                int result = axKHOpenAPI1.CommRqData("일봉차트a", "opt10081", 0, GetNumber());
                Thread.Sleep(1000);
            }
        }

 

        public void API_OnReceiveMsg(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            Console.WriteLine(e.sMsg);
        }

        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {            
            string str04 = "";
            string str05 = "";
            List<string> list05 = new List<string>();
            
            if (e.sRQName == "복수종목조회")
            {
                Console.WriteLine("복수종목조회");
                int count = axKHOpenAPI1.GetRepeatCnt("OPTKWFID", "복수종목조회");

                Console.WriteLine($"count11 : {count}");
            }

            else if (e.sRQName == "단수종목조회")
            {
                Console.WriteLine("단수종목조회");
            }
            //Console.WriteLine($"count : {axKHOpenAPI1.GetRepeatCnt("opt10081", "일봉차트")}");
 
            else if (e.sRQName == "일봉차트a")
            {
                List<string> getCommData = new List<string>() { "거래량", "시가", "고가", "저가", "현재가", "일자" };
                string[] CSVStyle = TRToCsvStyle(getCommData, "opt10081", "일봉차트a");

                File.WriteAllLines(@"C:\Users\user\Desktop\stock\strategy\server\dailyCandle" + stockCode + ".txt", CSVStyle);            
            }
        }


        public string[] TRToCsvStyle(List<string> getCommData, string orderCode, string rqName)         // Return csv-styled table data of string[] from OnReceiveTrData
        {
            List<string> csvStyle = new List<string>();     // csv style in memory.
            string csvStyleHeader = "";         // header
            string rowData = "";                // rowdata            

            //1. header part
            foreach (string item in getCommData)
            {
                csvStyleHeader = csvStyleHeader + $"{item},";
            }
            csvStyleHeader.Trim(',');
            csvStyle.Add(csvStyleHeader);

            //2. body part
            int count = axKHOpenAPI1.GetRepeatCnt(orderCode, rqName);
            for (int i = 0; i < count; i++)
            {
                if (i == 0)     // for each file name attach stock code in file name.                
                    stockCode = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", i, "종목코드").Trim();                
                rowData = "";
                foreach (string item in getCommData)
                    rowData = rowData + axKHOpenAPI1.GetCommData(orderCode, rqName, i, item).Trim() + ",";
                rowData.Trim(',');
                csvStyle.Add(rowData);                
            }
            string[] csvType = csvStyle.ToArray();
            
            return csvType;
        }

        public void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {

        }

        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {

        }

        public void ButtonEnter(object sender, EventArgs e)
        {
            if (sender.Equals(btnKw))
            {
                Console.WriteLine("enter");
                axKHOpenAPI1.CommKwRqData("000020", 0, 3, 0, "복수종목조회", "2005");
            }
            else if(sender.Equals(btnVolAverage))
            {
                //Console.WriteLine("average");
                GetAverage();
            }
        }

        public double GetAverage()
        {
            double sum = 0;
            double average = 0;
            List<double> dData = new List<double>();
            List<string> columnData = new List<string>();
            // step 1 : collect data
            string[] csvStyle = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\server\dailyCandle000040.txt");
            // step 2 : ExtractColumn
            columnData = ExtractColumndata(csvStyle, "거래량");

            Console.WriteLine($"columnData.Count  :: {columnData.Count}");

            
            for (int i = 0; i<columnData.Count ;i++)
            {
                dData.Add(double.Parse(columnData[i]))  ;             // string type to double type
            }           


            for (int i = 0; i<dData.Count ;i++)
            {
                sum += dData[i];
            }
            /**
            **/
            average = sum;//dData.Count;
            Console.WriteLine($"average  {average}");
            // step 3 : get average
            // step 4 : return the average
            // step 5 : 
            // step 1 : 
            // step 1 : 
            return 0;
        }

        public void ButtonClick(object sender, EventArgs e)
        {
            if (sender.Equals(btnDailyData))
            {
                // step 1 Collect Codelist from the Kiwoom server : 
                codeList = axKHOpenAPI1.GetCodeListByMarket("0");
                codeList = codeList.Trim(';');

                // step 2 Filter the code list and bind each code with code name like "000020:동화약품"
                Filter(codeList);

                // step 3 request dailyCandle.
                //arrange(); is called in Filter() function.
            }

            else if (sender.Equals(btnKw))
            {

            }

        }

        // step 2 Filter the code list and bind each code with code name like "000020:동화약품"
        public void Filter(string s)
        {
            //s = s.TrimEnd(';');

            string str02 = "";
            string str03 = "";
            List<string> list = new List<string>();
            string[] codeListArr = s.Split(';');

            foreach (string str in codeListArr)
            {
                str02 = str + ":" + axKHOpenAPI1.GetMasterCodeName(str);

                list.Add(str02);

                str03 = str03 + str02 + "\r\n";
                str02 = "";
            }

            File.WriteAllText(@"C:\Users\user\Desktop\stock\strategy\commondata\codeAndName.txt", str03);

            Console.WriteLine($"codeListArr.Length : {codeListArr.Length}");

            // request dailyCandles of code list .


        }

        public string GetNumber()
        {
            string num = "";
            startNumber++;
            num = startNumber.ToString();
            return num;
        }

        public List<string> ExtractColumndata(string[] csvStyleData, string columnName)     // extract column data from csvstyle data
        {
            int j = 0;
            int index = 0;      // for column index
            List<string> columnData = new List<string>();

            foreach (string str in csvStyleData)
            {
                string[] items = str.Split(',');
                // header part
                if (j == 0)
                {
                    for (int i = 0; i < items.Length; i++)
                    {
                        if (items[i] == columnName)     // find the index of column asked of the columName
                        {
                            index = i;
                        }
                    }
                }
                // body part
                else
                {
                    for (int k = 0; k < items.Length; k++)
                    {
                        if (k == index)
                        {
                            columnData.Add(items[k]);
                        }
                    }
                }
                j++;
            }
            //3. return
            return columnData;
        }
    }

    // Represents the file of "dailycandle.txt" in server folder
    public class Server
    {
        public Server()
        {
            
        }
        public Server(string filePath)
        {
            string rootPath = @"C:\Users\user\Desktop\stock\strategy\server\";
            string fullPath =  rootPath + filePath;
            this.csvStyle = File.ReadAllLines(fullPath);
        }

        public string[] csvStyle;
        //public DataTable dt;
    }
}
