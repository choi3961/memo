﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChartTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Test();
        }

        public void Test()
        {
            DataTable dt = new DataTable();

            DataColumn dc = new DataColumn("first");

            dt.Columns.Add(dc);

            DataRow dr = dt.NewRow();

            dt.Rows.Add(dr);


            chart1.DataSource = dt;
        }

        
    }
}
