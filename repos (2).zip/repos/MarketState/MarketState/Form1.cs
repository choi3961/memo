﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarketState
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Kospistocks();

            //Console.WriteLine(FieldValues(1, 21));
            int number = FieldValues(1000, 21);

            Console.WriteLine($"number : {number}");
        }

        // The number of Kospistocks.
        public void Kospistocks()
        {
            string[] stocksInfo = File.ReadAllLines("kospistocks.txt");

            Console.WriteLine($"stocks.Length : {stocksInfo.Length}");

            txtKospiStocks.Text = stocksInfo.Length.ToString();
        }

        public int FieldValues(int condition, int sessionProfit)
        {
            string[] stocksInfo = File.ReadAllLines("kospistocks.txt");
            int iterator = 0;
            int num = 0;

            foreach (string str in stocksInfo)
            {
                iterator++;
                int profit =0;

                if (iterator == 1)
                {
                    continue;
                }
                string[] eachInfo = str.Split(',');

                Console.WriteLine($"eachInfo[21] : {eachInfo[21]}");

                try 
                {
                    profit = int.Parse(eachInfo[21]);
                }

                catch
                {

                }

                finally
                {
                    if (condition <= profit)
                    {
                        num++;
                    }
                }
            }

            return num;
        }
    }
}
