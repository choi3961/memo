﻿using System;

namespace ClassLibrary1
{
    public class ProduceDataTable
    {
        public void ProDataTable()
        {

        }
    }
}
