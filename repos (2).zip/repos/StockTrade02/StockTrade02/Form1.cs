﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockTrade02
{
    public partial class Form1 : Form
    {      
        public Items_For_Buying items;                              // an object of class for buying order 
        List<string[]> listFromServer = new List<string[]>();       // container for real time data from Kiwoom Server.
        int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        int i;                          //horizontal location of bottomPoints
        int j;                          //vertical   location of bottomPoints
        int bLocation;                  // location of bottomPoints
        int flag;                       // flag for bottomPoints
        bool orderSent;                 // check if order is sent at the third bottom point.
        int timeElapsed;                //check the time elapsed
        int[] test;                     // vitual server data

        Strategy01 str01;                      // Strategy in perfect machine trading. One strategy for one stock item.
        Strategy01 str02;                      // Strategy in perfect machine trading. One strategy for one stock item.
        Strategy01 str03;                      // Strategy in perfect machine trading. One strategy for one stock item.

        // Information about the all the lowest bottom points
        BottomInfo firstBottom;         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        BottomInfo secondtBottom;       // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        BottomInfo thirdBottom;         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        List<BottomInfo> bottomsInfo;   // List that contains the information of all the bottoms

        int bottomCount = 0;             //temporary variable for onreceiveiverealData test.
        int eventCount = 0;                //temporary variable for onreceiveiverealData test.
        string lowPrice = "";              //temporary variable for onreceiveiverealData test.

        public Form1()
        {
            InitializeComponent();

            i = 1;
            j = 0;
            bLocation = 0;                          // location of bottomPoints
            timeElapsed = 0;                        //check the time elapsed
            bottomPoints = new int[2, 200];
            flag = 0;
            orderSent = false;
            bottomPoints[0, 0] = 200000;            // temporary
            str01 = new Strategy01();
            firstBottom = new BottomInfo();         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
            secondtBottom = new BottomInfo();       // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
            thirdBottom = new BottomInfo();         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)

            //Login
            Login();

            //Start trading
            str01.Init();
            str01.StartTrading();

            //StartTrading();
            //foreach (int i in bottomPoints)
            //{
                //Console.WriteLine(i + " in bottomPoints");
            //}

            //Logout
            Logout();
            //end
        }

        //Login function
        private void Login()
        {
            Console.WriteLine("Login function");
            int a = axKHOpenAPI1.CommConnect();
            if (a == 0)
            {
                Console.WriteLine("Login Success");
            }
        }

        //Start Trading
        /************************************************************
         Step 1. : Produce the best buying condition and timing

         Step 2. : If the step 1 chance is caught, send order to buy the stock
                    else, waiting... try to catch the best chance of buying and timing.

         Step 3. : If bought, send ordeer to sell the stock.
                    else, waiting

         Step 4. : if sold out, Chedk the market is closed.

         Step 5. : If the market is closed, output the result of the day into the outside file.
                    else, return to Step 1.
         ******************************************************/
        private void StartTrading()
        {
            Console.WriteLine("StartTrading function");
            // Step 1
            Catch_Best_Condition();

            // Step 2
            //Send_Order_Buying();

            // Step 3
            //Send_Order_Selling();

            // Step 4
            //Check_Market();

            // Step 5
            //Output_Result();
        }

        //Logout function
        private void Logout()
        {
            Console.WriteLine("Logout function");
        }

        //Step 1 function : find best buying condition
        //     substep 1 : algorithm for best buying condition
        //     substep 2 : call send order function
        public void Catch_Best_Condition()
        {
            ////////////////////////////////////////substep 1 :  algorithm for best buying condition
            realDataButton.Click += Button_Click;

            // background event (system event) for real time data from Kiwoom Server.
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;

            axKHOpenAPI1.SetRealReg("1001", "000020", "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server
        
            test = new int[20] { 70, 69, 80, 90, 100, 90, 60, 90, 93, 100, 70, 39, 40, 41, 42, 43, 44, 45, 30, 47 }; // vitual server data

            ////////////////////////////////////////substep 1 :  algorithm for best buying condition

            /////////////////////////////////////// substep 2 : call send order function
            if (true)
            {
                Send_Order_Buying();
            }
            else
            {
                //waiting...
            }
            ////////////////////////////////////// substep 2 : call send order function

            if (true)
            {
                Send_Order_Buying();
            }
            else
            {
                //waiting...
            }
        }

        //Step 2 function
        private void Send_Order_Buying()
        {
            Console.WriteLine("Send order of buying");

            // Create an object of "items for buying order
            items = new Items_For_Buying("주식주문", "1001", "8008765411", 1, "000020", 1, 0, "03", null);

            // Send order to the server
            int result = axKHOpenAPI1.SendOrder(items.rqname, items.scrNum, items.accNum, items.orderType, items.itemCode, items.quantity, items.price, items.trType, items.ori_Num);
            if (result == 0)       // 요청성공
            {
                Console.WriteLine("주문요청 성공");
            }
            else    // sendOrder failed
            {
                Console.WriteLine("failed");
            }

            // Calls the Selling order if a stock is bought.
            if (true)       // if bought
            {
                Send_Order_Selling();
            }
            else
            {
                //waiting...
            }
        }

        //Step 3 function
        private void Send_Order_Selling()
        {
            Console.WriteLine("Send order of selling");

            if (true)           // if sould out
            {
                Check_Market();
            }
            else
            {
                //Catch_Best_Condition();
            }
        }

        //Step 4 function
        private void Check_Market()
        {
            Console.WriteLine("Check if the market is closed");
            if (true)               // if the market is closed
            {
                Output_Result();
            }
        }

        //Step 5 function
        private void Output_Result()
        {
            Console.WriteLine("Output the result of the day");
        }

        // Showing the result of realtime data from the Kiwoom server.
        // algorithm for best buying condition
        private void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            string first;       // for receiving data splited from the real time data
            string second;      // for receiving data splited from the real time data
            string lowP;       // for receiving data splited from the real time data
            //DateTime currentTime; // to compare the current time with elapsed time
            string currentTime; // to compare the current time with elapsed time

            string[] strArr = new string[10];
            eventCount++;

            //listBox.Items.Add(eventCount);

            /*
            e.sRealType;    // 실시간 타입
            e.sRealKey;     // 종목코드
            e.sRealData;    // 실시간 데이터
            */

            // data splited from the real time data
            first = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);
            second = axKHOpenAPI1.GetCommRealData(e.sRealKey, 17);
            lowP = axKHOpenAPI1.GetCommRealData(e.sRealKey, 18);


            // remove "-" 
            String s = lowP;
            lowP = s.Trim();
            lowPrice = s.Remove(0,1);
            

            //currentTime = DateTime.Now;

            currentTime = "aaa";

            //BottomPoints(third, currentTime);

 
            int low = int.Parse(lowPrice);
            BottomPoints(low, "42");    // Find bottom Points to send order of buying. if found, send the data to bottomPoints 
 


            strArr[0] = first;
            strArr[1] = second;
            strArr[2] = lowP;

            listFromServer.Add(strArr);                     // container for real time data to use for algorithm from Kiwoom Server.


            // algorithm for best buying condition
            BestCondition();
            // algorithm for best buying condition
        }

        // algorithm for best buying condition
        public void
            BestCondition()
        {

        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(realDataButton))
            {
                //string itemCode = itemCodeTextBox.Text;
                //axKHOpenAPI1.SetInputValue("종목코드", "000020");                                       // 일반 주식 TR 요청

                int result = axKHOpenAPI1.SetRealReg("1001", "005930", "9001;10", "0");
                //int result = axKHOpenAPI1.CommRqData("주식기본정보요청", "opt10001", 0, "1001");        // 일반 주식 TR 요청

                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //axKHOpenAPI1.SetInputValue("종목코드", "101rc000");                                   // 코스피 200 선물 TR 요청

                //axKHOpenAPI1.SetInputValue("종목코드", itemCode);                                       // 코스피 200 선물 TR 요청
                //axKHOpenAPI1.SetInputValue("기준일자", "20210923");                                     // 코스피 200 선물 TR 요청

                //int result ;

                //result = axKHOpenAPI1.CommRqData("코스피200지수요청", "opt50037", 0, "1001");        // 코스피 200 선물 TR 요청
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                if (result == 0)
                {
                    Console.WriteLine("setRealReg 요청");
                }
                else
                {
                    Console.WriteLine("주식기본 정보 요청에 실패하였습니다.");
                }
            }
            foreach (int i in bottomPoints)
            {
                Console.WriteLine(i + " in bottomPoints");
            }
        }

        // Find bottom Points to send order of buying. if found, send the data to bottomPoints      
        // step 1 : compare the previous value with newly evented value
        // step 2 : if(true) insert the value, if not desert the value
        // step 3 : if(third bottom found) send order of buying stock.
        public void BottomPoints(int lowPrice, string currentTime)
        {
            // step 1 : compare the previous value with newly evented value
            int previous = bottomPoints[0, bLocation];  // extract data from in the bottomPoints
            int newly = lowPrice;                // extract data from the Kiwoom server
            compare(previous, newly, bLocation);        // compare A with B

            // step 2 : if(true) insert the value, if not desert the value

            // step 3 : if(third bottom found) send order of buying stock. : check if third bottomPoint is found
            if (flag == 3 && orderSent == false)
            {
                Console.WriteLine("third bottom found");
                orderSent = true;
            }
        }

        public void compare(int previous, int newly, int bLoc)
        {
            if (previous > newly)
            {
                // step 2 of BottomPoints : if(true) insert the value, if not desert the value
                // next bottom point
                if (timeElapsed >= 1000)
                {
                    bLocation++;

                    // Register previous bottom information
                    flag++;
                    insert(0, bLocation, newly);

                    timeElapsed = 0;
                }
                else
                {
                    insert(0, bLoc, newly);
                }

                Console.WriteLine("bottom found");
                show_result(lowPrice);
            }
            else
            {
                timeElapsed++;
                if (timeElapsed%100 == 0)
                {
                    listBox.Items.Add(timeElapsed);
                }              
            }
        }

        public void insert(int vertical, int location, int value)
        {
            bottomPoints[vertical, location] = value;
        }

        public void show_result(string lowP)
        {
            listBox.Items.Add("저가 : " + lowP);
        }


        // strategy class for trading.    one strategy is for one item.
        // step 1 Filter the codelist
        // step 2 Group the code list
        // step 3 observe one code of market items
        // step 4 send buying signal
        public class Strategy01             // perfect machine trading.
        {
            string[] codelist;
            List<string> fundamentalInfo;
            Filter filter01;
            Group group01;
            Observer observer01;
            Signal signal01;
            
            public void Init()
            {
                fundamentalInfo = new List<string>();
                filter01 = new Filter();
                group01 = new Group();
                observer01 = new Observer();
                signal01 = new Signal();
            }

            public void StartTrading()
            {
                //group01 = new Group();

                // step 1 Filter the codelist
                filter01.Start01();                                     // csv data filtering

                // step 2 Group the code list
                group01.SetGroup();                                    // filtered csv data grouping; called from Filter.CsvToList()
                string group = group01.GetGroup();


                // step 3 observe one code of market items
                observer01.Observe(group);                                   // Listen for the market

                //outerform.StartTrading();
                                                                             // step 4 send buying signal
                                                                             // Send buying signal
            }


            // Filter the fundamental information of stocks, for example, 영업이익, 자본금, EPS from all the market stocks.
            private class Filter
            {
                private string code;
                Group group01;
                Observer observer01;

                public void Start01()
                {
                    Console.WriteLine("Started the filtering");

                    // csv file open into memory
                    string[] csv = File.ReadAllLines("first.txt");

                    // filter the csv file into List<class>
                    CsvToList(csv);
                }

                public void CsvToList(string[] csvLines)
                {
                    group01 = new Group();
                    //observer01 = new Observer();

                    Console.WriteLine("Initialize the csv into List<T>");
                    List<string> codeNum = new List<string>();
                    List<string> codeName = new List<string>();            // each value of each field from csv file.
                    List<string> month = new List<string>();            // each value of each field from csv file.
                    List<string> price = new List<string>();            // each value of each field from csv file.
                    List<string> capital = new List<string>();            // each value of each field from csv file.
                    List<CodeInfo> allCodesInfo = new List<CodeInfo>();     // code object with fundamental information

                    for (int i = 0; i < csvLines.Length; i++)
                    {
                        string[] rowdata = csvLines[i].Split(',');

                        codeNum.Add(rowdata[0]);
                        codeName.Add(rowdata[1]);
                        month.Add(rowdata[2]);
                        price.Add(rowdata[3]);
                        capital.Add(rowdata[4]);

                        CodeInfo codeInfo = new CodeInfo(csvLines[i]);
                        allCodesInfo.Add(codeInfo);
                    }

                    string[] temporary = new string[5];           // temporaty command

                    Sort(temporary);

                    group01.GetGroup();                              // Group the code list
                                                                     //observer01.Observe();
                }

                // Sort the csv field data.
                public void Sort(string[] str)
                {

                }

                // Information for each code
                private class CodeInfo
                {
                    public string code;
                    public string name;
                    public string capital;
                    public string volume;
                    public string profit;

                    public CodeInfo(string rowData)
                    {
                        string[] rowInfo = rowData.Split(',');

                        this.code = rowInfo[0];
                        this.name = rowInfo[1];
                        this.capital = rowInfo[2];
                        this.volume = rowInfo[3];
                        this.profit = rowInfo[4];
                    }
                }
            }

            private class Group
            {
                public string first;
                public List<string> list;
                public string codeName01 = "000020";          // temporary code.
                public string codeName02 = "";              // temporary code.


                public List<string> group01;


                public Group()
                {
                }

                public string GetGroup()
                {
                    Console.WriteLine("return string type");

                    return codeName01;
                }

                public void SetGroup()
                {

                }

                public class GroupType
                {

                }
            }

            private class Observer
            {
                public string second;

                public void Observe(string str)
                {
                    Console.WriteLine("observing : " + str);
                    //StartTrading();
                }
            }

            private class Signal
            {
                public bool Sig { get; set; }

                public string Code { get; set; }
            }
        }

        // Items for Buying Order : for API.SendOrder
        public class Items_For_Buying
        {
            public string rqname;
            public string scrNum;
            public string accNum;
            public int orderType;
            public string itemCode;
            public int quantity;
            public int price;
            public string trType;
            public string ori_Num;
            public Items_For_Buying(string rqname, string scrNum, string accNum, int orderType, string itemCode, int quantity, int price, string tradingType, string ori_Num)
            {
                this.rqname = rqname;
                this.scrNum = scrNum;
                this.accNum = accNum;
                this.orderType = orderType;
                this.itemCode = itemCode;
                this.quantity = quantity;
                this.price = price;
                this.trType = tradingType;
                this.ori_Num = ori_Num;
            }
        }

        // objects containing information about bottompoint
        public class BottomInfo
        {
            public string Name { set; get; }        // name of the bottompoint
            public bool Set { set; get; }           // Check if or not bottompoint is established.
            public int Location { set; get; }       // the location of the bottompoint in bottomPoints Array.
            public int Price { set; get; }          // the lowest price of the stock
        }
    }

}
