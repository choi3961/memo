﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextFileApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Console.WriteLine("start");
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            Console.WriteLine("button clicked...");
            
            using(OpenFileDialog ofd = new OpenFileDialog() { Filter ="Test file|*.txt" })
            {
                if(ofd.ShowDialog() == DialogResult.OK)
                {
                    List<string> lines = File.ReadAllLines(ofd.FileName).ToList();
                    List<Customer> list = new List<Customer>();
                    for (int i =0; i<lines.Count; i++)
                    {
                        string[] data = lines[i].Split(',');
                        //CustomerID,CompanyName,ContactName
                        list.Add(new Customer() { CustomerID = data[0], CompanyName= data[1], ContactName= data[2] });
                    }
                    customerBindingSource.DataSource = list;
                }
            }
            
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            Console.WriteLine("button clicked");
        }
    }
}
