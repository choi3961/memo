﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataGridViewTest
{
    public partial class Form1 : Form
    {
        //DataGridView dgv;
        DataTable dt;
        public Form1()
        {
            InitializeComponent();
            showStockInfo.Click += Button_Click;        // Stock information
            btnAccount.Click += Button_Click;           // Account information
            btnTest.Click += Button_Click;              // Test ProduceDataTable() function
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;
            axKHOpenAPI1.CommConnect();                 // Login 

            TabControlTest();
            tabControl1.TabPages[0].Text = "hello";
            //tabControl1.TabPages[0].Controls.Add(dgvAccountInfo);
        }

        public void TabControlTest()
        {
            tabControl1.TabPages[0].Text = "hello";
            //tabControl1.TabPages[0].Controls.Add(dgvAccountInfo);
        }

        public void ReadCSV(string filePath)
        {
            string[] csvData = File.ReadAllLines("second.txt");
            dt = CsvStyleToDataTable(csvData);       // DataTable
            dgvShow.DataSource = dt;
        }

        public void accountInfoRequest()
        {
            //1.Open API 조회 함수 입력값을 설정합니다.
            //계좌번호 = 전문 조회할 보유계좌번호
            axKHOpenAPI1.SetInputValue("계좌번호", "8008765411");

            //비밀번호 = 사용안함(공백)
            axKHOpenAPI1.SetInputValue("비밀번호", "");

            //상장폐지조회구분 = 0:전체, 1:상장폐지종목제외
            //axKHOpenAPI1.SetInputValue("상장폐지조회구분", "입력값 3");

            //비밀번호입력매체구분 = 00
            axKHOpenAPI1.SetInputValue("비밀번호입력매체구분", "입력값 4");

            //2.Open API 조회 함수를 호출해서 전문을 서버로 전송합니다.
            axKHOpenAPI1.CommRqData("계좌평가현황", "OPW00004", 0, "화면번호");
        }

        // show the accountInfo into datagridview
        public void accountInfoResult()
        {
            string header = "종목코드," + "종목명," + "보유수량," + "현재가" ;
            string row = "";

            // step 1 : collect the account information in csv style from the server
            int count = axKHOpenAPI1.GetRepeatCnt("opw00004", "계좌평가현황요청");
            string[] csvStyle = new string[count+1];

            csvStyle[0] = header;

            for (int i = 1; i < count+1; i++)
            {
                Console.WriteLine("성공");
                row = axKHOpenAPI1.GetCommData("opw00004", "계좌평가현황요청", i, "종목코드").Trim();
                row += ",";
                row += axKHOpenAPI1.GetCommData("opw00004", "계좌평가현황요청", i, "종목명").Trim();
                row += ",";
                row += axKHOpenAPI1.GetCommData("opw00004", "계좌평가현황요청", i, "보유수량").Trim();
                row += ",";
                row += axKHOpenAPI1.GetCommData("opw00004", "계좌평가현황요청", i, "현재가").Trim();
                csvStyle[i] = row;
            }

            dt = CsvStyleToDataTable(csvStyle);        // Build Datable in memory
            dgvAccountInfo.DataSource = dt;                     // Bind data source
        }

        public void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(showStockInfo))
            {
                ReadCSV("path");
            }

            else if (sender.Equals(btnAccount))
            {
                accountInfoRequest();
            }

            else if (sender.Equals(btnTest))
            {
                Console.WriteLine("Testing");
                Test();
            }
        }

        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            if (e.sRQName == "계좌평가현황")
            {
                accountInfoResult();
            }
        }

        public void Test()
        {
            //string[]  csvData = File.ReadAllLines("second.txt");
            //dt = CsvStyleToDataTable(csvData);
            //dgvShow.DataSource = dt;

            DataView dv = dt.DefaultView;
            dv.Sort = "2 보유수량 desc";
            //dt = dv.ToTable();
        }



        // Return DataTable from csv styled data to show into DataGridView ================
        public DataTable CsvStyleToDataTable(string[] csvStyleData)
        {
            DataTable dt = new DataTable();
            DataRow rowData;
            DataColumn column;

            string[] cellData;

            int j = 0;

            foreach (string line in csvStyleData)
            {
                cellData = line.Split(',');

                if (j==0)
                {
                    for (int i = 0; i < cellData.Length; i++)
                    {
                        column = new DataColumn(i + " " + cellData[i]);
                        dt.Columns.Add(column);
                    }
                    j++;
                    continue;
                }

                rowData = dt.NewRow();

                for (int i = 0; i < cellData.Length; i++)
                {
                    rowData[i] = cellData[i];
                }

                dt.Rows.Add(rowData);

                j++;
            }

            // step 3 : Return DataTable object
            return dt;
        }
    }
}
