﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Report
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Init();
            //Test();
        }

        public void Init()
        {
            btnReport.Click += ButtonClick;         // Report the result of the trade daily to the file
        }

        public void ButtonClick(object sender, EventArgs e)
        {
            if (sender.Equals(btnReport))
            {
                p();
                collect();              // step 1: collect the result
                reportToFile();         // step 2: report the result to the file in csv style
                // step 3:
                // step 4:
                // step 5:
                // step 6:
                // step 7:
                // step 9:

            }
        }

        public void collect()
        {

        }
        public void reportToFile()
        {

        }

        public void Test()
        {

        }

        public void p()
        {
            Console.WriteLine("here++++++++++++");
        }
    }
}
