﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        int screenNum = 1000;

        public Form1()
        {
            InitializeComponent();

            loginButton.Click += Button_Click;
            orderButton.Click += Button_Click;

            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;
            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;
            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTRData;
        }

        private void API_OnReceiveTRData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            Console.WriteLine("Trdata");
        }

        private void Button_Click(object sender, EventArgs e)
        {
            //Console.WriteLine("Hello");
            if (sender.Equals(loginButton))
            {
                logListBox.Items.Add("로그인 버튼 클릭");
                axKHOpenAPI1.CommConnect();
            }
            else if(sender.Equals(orderButton))
            {
                logListBox.Items.Add("order 버튼 클릭");
                Console.WriteLine("order button");

                string orderType = orderTypeComboBox.Text;
                string itemCode = itemCodeTextBox.Text;
                int order = OrderTypeCode(orderType);
                int quantity = (int)quantityNumericUpDown.Value;
                int price = (int)priceNumericUpDown.Value;
                string tradingType = tradingTypeComoBox.Text;
                string oriOrderNumber = orderNumberTextBox.Text;


                int orderResult = axKHOpenAPI1.SendOrder("주식주문", GetScreenNumber(), accountComboBox.Text, order, itemCode, quantity, price, tradingType, oriOrderNumber);
                if (orderResult == 0)       // 요청성공
                {
                    logListBox.Items.Add("주문요청 성공");
                }
                else    // sendOrder failed
                {
                    logListBox.Items.Add("failed");
                    logListBox.Items.Add(orderResult);
                }
            }
        }

        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            Console.WriteLine("chejandata");

            logListBox.Items.Add("e.nitemCnt : " + e.nItemCnt + "");
            logListBox.Items.Add("e.sFIdList : " + e.sFIdList + "");
            logListBox.Items.Add("e.sgubun : " + e.nItemCnt + "");

            if (e.sGubun.Equals("0"))           //접수 or 체결
            {
                Console.WriteLine("접수 체결");
                string account = axKHOpenAPI1.GetChejanData(9201);
                string orderNumber = axKHOpenAPI1.GetChejanData(9203);
                string orderState = axKHOpenAPI1.GetChejanData(913);

                Console.WriteLine(account + orderNumber + orderState);
            }

            else if (e.sGubun.Equals("1"))      //잔고
            {
                Console.WriteLine("잔고");
            }
            else if (e.sGubun.Equals("2"))      //파생잔고
            {
                Console.WriteLine("파생잔고");
            }
        }

        private void API_OnReceiveMsg(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            string msg = e.sMsg;
            string rqName = e.sRQName;
            string screenNumber = e.sScrNo;
            string trCode = e.sTrCode;

            logListBox.Items.Add("OnReceiveMsg() - " + " msg : " + msg + "rqName = " + rqName + " screenNumber : " + screenNum +" trCode : " + trCode);
        }


        private void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            if (e.nErrCode ==0)
            {
                string accountList = axKHOpenAPI1.GetLoginInfo("ACCLIST");
                string[] accountArray = accountList.Split(';');

                for (int i=0; i<accountArray.Length; i++)
                {
                    if (accountArray[i].Length > 0)
                        accountComboBox.Items.Add(accountArray[i]);

                }
            }
            else
            {

            }

        }

        private string GetScreenNumber()
        {
            if(screenNum >= 9999)
            {
                screenNum = 1000;
            }

            screenNum++;
            
            return screenNum.ToString();
        }

        private int OrderTypeCode(string orderType)
        {
            switch (orderType)
            {
                case "신규매수":
                    return 1;

                case "신규매도":
                    return 2;

                case "매수취소":
                    return 3;

                case "매도취소":
                    return 4;

                case "매수정정":
                    return 5;

                case "매도정정":
                    return 6;

                default:
                    return -1;
            }
        }

        private string TradingTypeCode(string tradingType)
        {
            switch (tradingType)
            {
                case "지정가":
                    return "00";

                case "시장가":
                    return "00";

                case "조건부지정가":
                    return "05";

                default:
                    return "00";
                
 
            }
        }
        /*****************
         데이터 수집

        @꼭지점 찾기 (변곡점 찾기)
        1. 데이터 요청
        2. 꼭지점 정의

         ****************/
        /***************************************************************************************************************
         거래 알고리즘
        갑작스럽고 과도한 물규칙성으로 손실을 본다. 그러므로 그러한 불규칙성을 반대로 이용하여야 한다.
        급변 상뢍인지 박스권 상황인지 상황 구별을 해야한다. 급변 상황시 signal을 파악해야 한다.
        매매 거래 실패시 대응 방법을 연구해야한다.
         *************************************************************************************************************/
        /*****************************************************************************
         매수 거래 알고리즘
         *******************************************************************************/
        /****************************************************************************
         

        true : 1. 가격폭락, 2. 거래량 증가, 3. 폭락꼬리 형성 4. 3파 형성, 4파, 5파
            1. 가격폭락 : 

            2. 거래량 증가 :
            
            3, 폭락꼬리 형성 : 
            
            4. 3파 형성 : 

         
        if(true) 
        {
            
            if(거래 체결)
            {
                거래 체결 통보
                매도 주문 
            }
        }
        
        
        가격 폭락 & 거래량 증가& 폭락꼬리 형성

         *************************************************************************/






        /********************************************************************************
         매도 거래 알고리즘
         *******************************************************************************/
        /****************************************************************************
         if() 가격 폭등 & 거래량 증가 & 폭등꼬리 형성

         *************************************************************************/
    }
}
