﻿
namespace BottompointsTest
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnBottompointsTest = new System.Windows.Forms.Button();
            this.btnTR = new System.Windows.Forms.Button();
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.comboTiming = new System.Windows.Forms.ComboBox();
            this.listBox = new System.Windows.Forms.ListBox();
            this.btnStrategy = new System.Windows.Forms.Button();
            this.comboWave = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBottompointsTest
            // 
            this.btnBottompointsTest.Location = new System.Drawing.Point(52, 177);
            this.btnBottompointsTest.Name = "btnBottompointsTest";
            this.btnBottompointsTest.Size = new System.Drawing.Size(152, 57);
            this.btnBottompointsTest.TabIndex = 0;
            this.btnBottompointsTest.Text = "BottompointsTest";
            this.btnBottompointsTest.UseVisualStyleBackColor = true;
            // 
            // btnTR
            // 
            this.btnTR.Location = new System.Drawing.Point(52, 87);
            this.btnTR.Name = "btnTR";
            this.btnTR.Size = new System.Drawing.Size(152, 49);
            this.btnTR.TabIndex = 1;
            this.btnTR.Text = "CommRQData";
            this.btnTR.UseVisualStyleBackColor = true;
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(1018, 454);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 2;
            // 
            // comboTiming
            // 
            this.comboTiming.FormattingEnabled = true;
            this.comboTiming.Items.AddRange(new object[] {
            "3",
            "6",
            "10",
            "20",
            "30",
            "60",
            "120",
            "180",
            "240"});
            this.comboTiming.Location = new System.Drawing.Point(301, 111);
            this.comboTiming.Name = "comboTiming";
            this.comboTiming.Size = new System.Drawing.Size(141, 20);
            this.comboTiming.TabIndex = 3;
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 12;
            this.listBox.Location = new System.Drawing.Point(113, 315);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(663, 160);
            this.listBox.TabIndex = 4;
            // 
            // btnStrategy
            // 
            this.btnStrategy.Location = new System.Drawing.Point(806, 87);
            this.btnStrategy.Name = "btnStrategy";
            this.btnStrategy.Size = new System.Drawing.Size(178, 43);
            this.btnStrategy.TabIndex = 5;
            this.btnStrategy.Text = "Strategy1";
            this.btnStrategy.UseVisualStyleBackColor = true;
            // 
            // comboWave
            // 
            this.comboWave.FormattingEnabled = true;
            this.comboWave.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.comboWave.Location = new System.Drawing.Point(301, 80);
            this.comboWave.Name = "comboWave";
            this.comboWave.Size = new System.Drawing.Size(141, 20);
            this.comboWave.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(475, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Wave";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(479, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Timing";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 549);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboWave);
            this.Controls.Add(this.btnStrategy);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.comboTiming);
            this.Controls.Add(this.axKHOpenAPI1);
            this.Controls.Add(this.btnTR);
            this.Controls.Add(this.btnBottompointsTest);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBottompointsTest;
        private System.Windows.Forms.Button btnTR;
        private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.ComboBox comboTiming;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button btnStrategy;
        private System.Windows.Forms.ComboBox comboWave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

