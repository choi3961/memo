﻿
namespace CodeListCollect
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.codeListButton01 = new System.Windows.Forms.Button();
            this.codeListBox01 = new System.Windows.Forms.ListBox();
            this.codeListButton02 = new System.Windows.Forms.Button();
            this.codeListBox02 = new System.Windows.Forms.ListBox();
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.ListNameBox01 = new System.Windows.Forms.ComboBox();
            this.ListNameBox02 = new System.Windows.Forms.ComboBox();
            this.codeListInfoListBox01 = new System.Windows.Forms.ListBox();
            this.codeListInfoButton01 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.SuspendLayout();
            // 
            // codeListButton01
            // 
            this.codeListButton01.Location = new System.Drawing.Point(611, 41);
            this.codeListButton01.Name = "codeListButton01";
            this.codeListButton01.Size = new System.Drawing.Size(177, 34);
            this.codeListButton01.TabIndex = 0;
            this.codeListButton01.Text = "코스피 List";
            this.codeListButton01.UseVisualStyleBackColor = true;
            // 
            // codeListBox01
            // 
            this.codeListBox01.FormattingEnabled = true;
            this.codeListBox01.ItemHeight = 12;
            this.codeListBox01.Location = new System.Drawing.Point(48, 41);
            this.codeListBox01.Name = "codeListBox01";
            this.codeListBox01.Size = new System.Drawing.Size(447, 88);
            this.codeListBox01.TabIndex = 1;
            // 
            // codeListButton02
            // 
            this.codeListButton02.Location = new System.Drawing.Point(611, 103);
            this.codeListButton02.Name = "codeListButton02";
            this.codeListButton02.Size = new System.Drawing.Size(167, 38);
            this.codeListButton02.TabIndex = 2;
            this.codeListButton02.Text = "코스닥 List";
            this.codeListButton02.UseVisualStyleBackColor = true;
            // 
            // codeListBox02
            // 
            this.codeListBox02.FormattingEnabled = true;
            this.codeListBox02.ItemHeight = 12;
            this.codeListBox02.Location = new System.Drawing.Point(48, 317);
            this.codeListBox02.Name = "codeListBox02";
            this.codeListBox02.Size = new System.Drawing.Size(236, 76);
            this.codeListBox02.TabIndex = 3;
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(639, 377);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 4;
            // 
            // ListNameBox01
            // 
            this.ListNameBox01.FormattingEnabled = true;
            this.ListNameBox01.Location = new System.Drawing.Point(533, 41);
            this.ListNameBox01.Name = "ListNameBox01";
            this.ListNameBox01.Size = new System.Drawing.Size(58, 20);
            this.ListNameBox01.TabIndex = 5;
            // 
            // ListNameBox02
            // 
            this.ListNameBox02.FormattingEnabled = true;
            this.ListNameBox02.Location = new System.Drawing.Point(307, 315);
            this.ListNameBox02.Name = "ListNameBox02";
            this.ListNameBox02.Size = new System.Drawing.Size(284, 20);
            this.ListNameBox02.TabIndex = 6;
            // 
            // codeListInfoListBox01
            // 
            this.codeListInfoListBox01.FormattingEnabled = true;
            this.codeListInfoListBox01.ItemHeight = 12;
            this.codeListInfoListBox01.Location = new System.Drawing.Point(50, 177);
            this.codeListInfoListBox01.Name = "codeListInfoListBox01";
            this.codeListInfoListBox01.Size = new System.Drawing.Size(444, 64);
            this.codeListInfoListBox01.TabIndex = 7;
            // 
            // codeListInfoButton01
            // 
            this.codeListInfoButton01.Location = new System.Drawing.Point(609, 179);
            this.codeListInfoButton01.Name = "codeListInfoButton01";
            this.codeListInfoButton01.Size = new System.Drawing.Size(168, 42);
            this.codeListInfoButton01.TabIndex = 8;
            this.codeListInfoButton01.Text = "Call csv into memory";
            this.codeListInfoButton01.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.codeListInfoButton01);
            this.Controls.Add(this.codeListInfoListBox01);
            this.Controls.Add(this.ListNameBox02);
            this.Controls.Add(this.ListNameBox01);
            this.Controls.Add(this.axKHOpenAPI1);
            this.Controls.Add(this.codeListBox02);
            this.Controls.Add(this.codeListButton02);
            this.Controls.Add(this.codeListBox01);
            this.Controls.Add(this.codeListButton01);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button codeListButton01;
        private System.Windows.Forms.ListBox codeListBox01;
        private System.Windows.Forms.Button codeListButton02;
        private System.Windows.Forms.ListBox codeListBox02;
        private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.ComboBox ListNameBox01;
        private System.Windows.Forms.ComboBox ListNameBox02;
        private System.Windows.Forms.ListBox codeListInfoListBox01;
        private System.Windows.Forms.Button codeListInfoButton01;
    }
}

