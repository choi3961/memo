﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeTest
{
    
    public partial class Form1 : Form
    {
        DateTime dateTime;
        
        double bottomFoundTime;

        public Form1()
        {
            InitializeComponent();

            dateTime = new DateTime();

            bottomFoundTime = (DateTime.Now - DateTime.MinValue).TotalMilliseconds;

            Console.WriteLine((DateTime.Now - DateTime.MinValue).TotalMilliseconds);

            //Console.WriteLine(DateTime.MinValue);

            //Console.WriteLine(DateTime.Now);

            //Console.WriteLine(DateTime.Now - DateTime.MinValue);
            while (true)
            {
                
                if (((DateTime.Now - DateTime.MinValue).TotalMilliseconds - bottomFoundTime) >= 10000 )
                {
                    //Console.WriteLine(bottomFoundTime);
                    bottomFoundTime = ((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                    //Console.WriteLine((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                    Console.WriteLine("10초 경과");
                }

                Thread.Sleep(2000);
            }

        }
    }
}
