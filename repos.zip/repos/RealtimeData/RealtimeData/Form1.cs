﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RealtimeData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            trRequestButton.Click += Button_Click;

            //axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData; 
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;      //실시간 데이터

            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;
            axKHOpenAPI1.CommConnect();

            
        }

        private void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            Console.WriteLine("TR 데이터 수신 완료");
            Console.WriteLine(e.ToString());

            /*
            e.sRealType;    // 실시간 타입
            e.sRealKey;     // 종목코드
            e.sRealData;    // 실시간 데이터
            */

            listBox.Items.Add(e.sPrevNext);
            listBox.Items.Add(e.GetType());
            listBox.Items.Add(e.sRQName);

            listBox.Items.Add(e.nDataLength);

            listBox.Items.Add(e.sRQName);
        }

        private void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            /*
            e.sRealType;    // 실시간 타입
            e.sRealKey;     // 종목코드
            e.sRealData;    // 실시간 데이터
            */

            listBox.Items.Add(e.sRealType);
            listBox.Items.Add(e.sRealKey);
            listBox.Items.Add(e.sRealData);

            string first = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);

            listBox.Items.Add(first);
            
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(trRequestButton))
            {
                string itemCode = itemCodeTextBox.Text;
                axKHOpenAPI1.SetInputValue("종목코드", itemCode);                                       // 일반 주식 TR 요청

                int result = axKHOpenAPI1.SetRealReg("1001", "000020", "9001;10", "0");
                //int result = axKHOpenAPI1.CommRqData("주식기본정보요청", "opt10001", 0, "1001");        // 일반 주식 TR 요청

                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                //axKHOpenAPI1.SetInputValue("종목코드", "101rc000");                                   // 코스피 200 선물 TR 요청

                //axKHOpenAPI1.SetInputValue("종목코드", itemCode);                                       // 코스피 200 선물 TR 요청
                //axKHOpenAPI1.SetInputValue("기준일자", "20210923");                                     // 코스피 200 선물 TR 요청

                //int result ;

                //result = axKHOpenAPI1.CommRqData("코스피200지수요청", "opt50037", 0, "1001");        // 코스피 200 선물 TR 요청
                /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                
                if (result == 0)
                {
                    Console.WriteLine("setRealReg 요청");
                }
                else
                {
                    Console.WriteLine("주식기본 정보 요청에 실패하였습니다.");
                }
                
            }
        }

        private void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            if(e.nErrCode ==0)
            {
                Console.WriteLine("success");
            }
            else
            {
                Console.WriteLine("failed");
            }
        }
    }
}
