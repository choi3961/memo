﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DateTimeTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Console.WriteLine(DateTime.MaxValue);
            //Console.WriteLine(DateTime.MaxValue.Ticks);
            //Console.WriteLine(DateTime.MinValue);
            //Console.WriteLine((DateTime.MaxValue- DateTime.MinValue).TotalSeconds);
            //Console.WriteLine(DateTime.MaxValue-DateTime.MinValue);

            //Test();
            Test2();
        }

        public void Test()
        {
            Console.WriteLine((950 / 1) * 1);
            Console.WriteLine((2543 / 5) * 5);
            Console.WriteLine((16374 / 10)*10);
            Console.WriteLine((26374 / 50) * 50);
            Console.WriteLine((76374 / 100) * 100);
            Console.WriteLine((156374 / 500)*500);               
            Console.WriteLine((636397 / 1000)*1000);            
        }

        public void Test2()
        {
            string[] str = new string[] { "abc,abc,abc" };

            string str2 = "abc,abd,abe";

            string[] temp = str2.Split(',');

            foreach (string each in temp)
            {
                Console.WriteLine(each);
                Console.WriteLine(temp.Length);
            }
        }
    }
}
