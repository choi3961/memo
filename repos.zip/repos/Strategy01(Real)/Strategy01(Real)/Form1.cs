﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Strategy01_Real_
{
    public partial class Form1 : Form
    {
        public int orderCount = 0;              // 매수 주문 종목 갯수
        public string accNumber = "";
        string currentPrice;      // for receiving data splited from the real time data
        int screenNumber = 1001;
        string codeList = "";       // for SetRealReg()        
        Stock[] stockArray;
        Stock[] stockArray02;
        Filter filter01;
        Group group01;
        Group group02;

        public Form1()
        {
            InitializeComponent();
            Init();
        }

        public void Test()
        {
            S_Daily50Drop Drop50 = new S_Daily50Drop("first");
            Console.WriteLine(Drop50.Title);
        }

        public void Init()
        {
            filter01 = new Filter(this);
            group01 = new Group();
            loginButton.Click += Button_Click;
            realDataButton.Click += Button_Click;               //substep 1 :  send "setrealreg" function of codeList to the server.
            btnSellAll.Click += Button_Click;                   // Sell All the stocks
            btnSellAll02.Click += Button_Click;
            btnCancelAllBuy.Click += Button_Click;              // 매수취소(전량)
            btnCancelAllSell.Click += Button_Click;             // 매도취소(전량)            
            btnRegRemove.Click += Button_Click;              // remove setrealreg 
            //btnResult.Click += Button_Click;            
            //btnStraDaily.Click += StrButton_Click;             //Strategy Button
            //btnStrWinds.Click += StrButton_Click;
            btnStrVolSoar.Click += StrButton_Click;
            btnReSet.Click += StrButton_Click;
            tcAccount.SelectedIndexChanged += Tabs_SelectedIndexChanged;    // TabControl Event
            tcStrategies.SelectedIndexChanged += Str_SelectedIndexChanged;    // TabControl Event
            listBoxAccount.SelectedIndexChanged += SelectedIndexChanged;
            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;            
            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;            
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;
            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;        // background event (system event) for real time data from Kiwoom Server.
            StaticSetting(100, 100, 200, 5, -30);            
        }        

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
                axKHOpenAPI1.CommConnect();
            else if (sender.Equals(realDataButton))         // send "SetRealReg"
                RQSetRealReg(codeList);
            else if (sender.Equals(btnSellAll))             // check account And Sell all the socks
                RQStocksState(accNumber, "일괄매도(시장가)");
            else if (sender.Equals(btnSellAll02))           // check account And Sell all the socks
                RQStocksState(accNumber, "일괄매도(지정가)");
            else if (sender.Equals(btnCancelAllBuy))        // check reserved stocks And Sell all the socks
                RQStocksState(accNumber, "전량매수주문취소");
            else if (sender.Equals(btnCancelAllSell))        // check reserved stocks And Sell all the socks
                RQMissedStock(accNumber, "전량매도주문취소1111");
            else if (sender.Equals(btnRegRemove))              // SetRealRegRemove                
                axKHOpenAPI1.SetRealRemove("ALL", "ALL");
            //else if (sender.Equals(btnResult))              // 종목별 손익결과                
                //RQStocksState(accNumber, "Result");
        }         
     

        public void RQStocksState(string accountNum, string RQName)
        {
            // 계좌 평가 현황 요청      // Invoke OnReceiveTrData()
            axKHOpenAPI1.SetInputValue("계좌번호", accountNum);
            axKHOpenAPI1.SetInputValue("비밀번호", "");
            axKHOpenAPI1.SetInputValue("상장폐지조회구분", "0");
            axKHOpenAPI1.SetInputValue("비밀번호입력매체구분", "00");
            axKHOpenAPI1.CommRqData(RQName, "OPW00004", 0, GetScreenNumber());       // Invoke OnReceiveTrData()
        }       // 계좌 평가 현황 요청 for 매도

        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {            
            if (e.sRQName == "일괄매도(시장가)")           // if 게좌평가현황요청일 경우
                AccountInfo();      // 시장가 일괄 매도    
            
            else if (e.sRQName == "일괄매도(지정가)")          // if 게좌평가현황요청일 경우
                AccountInfo02();      // 지정가 일괄 매도            

            else if (e.sRQName == "전량매수주문취소")
            {                
                //AccountInfo03();
                TradeAll(3);
            }

            else if (e.sRQName == "전량매도주문취소1111")
            {
                //p("전량매도주문취소1212");
                //AccountInfo04();
                TradeAll(4);
            }
            
            else if (e.sRQName == "미체결요청")
            {
                List<string> list = new List<string>() { "종목코드", "종목명", "주문수량", "주문가격", "현재가", "주문번호" }; // FID item
                MissedContract(list, "opt10075", "미체결요청");
            }           // 미체결 요청
            
            else if (e.sRQName == "원주문번호")
            {
                List<string> list = new List<string>() { "종목코드", "종목명", "주문수량", "주문가격", "주문수량", "현재가", "주문번호" }; // FID item
                p("원주문번호====");

            }           // 주문체결요청
            
            else if (e.sRQName == "매도주문")
            {

            }           // if 매도 주문일 경우

            else if (e.sRQName == "SendAccount")
            {
                List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "현재가", "평균단가", "손익금액", "손익율" }; // FID item
                ReceiveTr(list, "opw00004", "SendAccount");
            }

            else if (e.sRQName == "일봉차트a")
            {
                DailyCandleCollect();
            }

            else if(e.sRQName == "Result")
            {
                Result();
            }
        }

        public void Result()
        {            
            DataTable dt;
            DataColumn dc;

            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가", "현재가","M손익금액","M손익율" };        //step 1 : receive 계좌평가현황
            string[] csv = TRToCsvStyle(list, "opw00004", "Result");
            dt = CSVStyleToDataTable(csv);            

            for (int i = 0; i < csv.Length - 1; i++)                  //step 2 : caluate each stockcode
            {
                dt.Rows[i]["M손익금액"] = ((double.Parse(dt.Rows[i]["현재가"].ToString())) - (double.Parse(dt.Rows[i]["평균단가"].ToString()))) * (double.Parse(dt.Rows[i]["보유수량"].ToString()));
                dt.Rows[i]["M손익율"] = ((double.Parse(dt.Rows[i]["현재가"].ToString())) - (double.Parse(dt.Rows[i]["평균단가"].ToString()))) / (double.Parse(dt.Rows[i]["평균단가"].ToString()));
            }

            //PrintValues(dt);
            dgvResult.DataSource = dt;                              //step 4 : return the reault(show the result to the datagridview)            
        }

        private void PrintValues(DataTable table)
        {
            foreach (DataRow row in table.Rows)
            {
                foreach (DataColumn column in table.Columns)
                {
                    Console.Write(row[column]);
                    Console.Write(',');

                }
                //p();
                Console.WriteLine();
            }
        }


        // Return DataTable from csv styled data to show into DataGridView ================
        public DataTable CSVStyleToDataTable(string[] csvStyleData)
        {
            DataTable dt = new DataTable();
            DataRow rowData;
            DataColumn column;
            string[] cellData;
            int j = 0;

            foreach (string line in csvStyleData)
            {
                cellData = line.Split(',');
                if (j == 0)
                {
                    for (int i = 0; i < cellData.Length; i++)
                    {
                        column = new DataColumn(cellData[i]);
                        dt.Columns.Add(column);
                    }
                    j++;
                    continue;
                }

                rowData = dt.NewRow();
                for (int i = 0; i < cellData.Length; i++)
                {
                    rowData[i] = cellData[i];
                }
                dt.Rows.Add(rowData);
                j++;
            }
            return dt;
        }



        public void AccountInfo()
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가" }; // FID item
            string[] csv = TRToCsvStyle(list, "opw00004", "일괄매도(시장가)");

            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list04 = new List<string>();
            
            foreach (string code in list01)            
            {
                list04.Add(code.Remove(0, 1));
            }

            SellAllStocks(list04, list02, list03);          // 시장가 일괄 매도
        }           
        
        public void AccountInfo02()
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가", "매입금액" }; // FID item
            string[] csv = TRToCsvStyle(list, "opw00004", "일괄매도(시장가)");

            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list05 = ExtractColumndata(csv, "매입금액");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)            
                list04.Add(code.Remove(0, 1));            

            SellAllStocks02(list04, list02, list03);          // 시장가 일괄 매도
        }          

        private void StrButton_Click(object sender, EventArgs e)
        {             
            if (sender.Equals(btnStrVolSoar))        // Strategy : 거래량 급증
                StrVolSoar();
            else if (sender.Equals(btnReSet))        // check reserved stocks And Sell all the socks
                Setting();
        }

        public void StrDaily()
        {
            logListBox.Items.Clear();
            DynamicStrDaily("StrDaily.txt");
            Setting();
        }

        public void StrWinds()
        {
            logListBox.Items.Clear();
            // Step 1 : Collect stock codes from data of stock list
            string codeName = "";
            string[] codes = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\strategy11Winds\strWinds.txt");
            
            List<string> list = ExtractColumndata(codes, "code");
            List<string> name = ExtractColumndata(codes, "name");

            group02 = new Group(list, name);
            int length02 = group02.codeList.Count;
            stockArray02 = new Stock[length02];

            for (int i = 0; i < length02; i++)
            {
                stockArray02[i] = new Stock(this, group02.codeList[i], group02.codeName[i]);
            }
            RefreshCodeList(group02.codeList);

            // FilterDailyCandle();
            
            ShowFilteredCodeList(group02);          //Show the result of the filtered codelist before sending SetRealReg
        }

        public void StrVolSoar()            // Strategy : 거래량 급증
        {
            logListBox.Items.Clear();           
            DynamicStrVolSoar("strVolSoar.txt");
            Setting();
        }

        public void StaticSetting(double cap, double profit, double debt, int netProfitRate, double relToMaxP)//, int wave, int timing, int soaring)
        {
            StrategyStatic strategy01 = new StrategyStatic(cap, profit, debt, netProfitRate, relToMaxP);//, wave, timing, soaring);

            btnCapitalStr.Text = strategy01.capital.ToString();                   // static strategy
            btnProfitStr.Text = strategy01.profit.ToString();                     // static strategy
            btnDebtPortionStr.Text = strategy01.debt.ToString();                  // static strategy
            comboNetProfitRate.Text = strategy01.netProfitRate.ToString().Trim('%');        // static strategy
            comboRelToMaxP.Text = strategy01.relToMaxPrice.ToString();                // static strategy
        }
        public void Setting()
        {
            logListBox.Items.Clear();            

            var allCodesInfo = filter01.Start01();      // step 1 Filter the codelist from "first.txt"  // csv data filtering
            string str = btnCapitalStr.Text;            
            string str02 = btnProfitStr.Text;            
            string str03 = btnDebtPortionStr.Text;            
            string str04 = comboNetProfitRate.Text;            
            string str05 = comboRelToMaxP.Text;            
            //string str06 = (string)dgvDynamicStr.Rows[0].Cells[0].Value;                         // 거래량증가율

            int capital = int.Parse(str);
            int profit = int.Parse(str02);
            int debt = int.Parse(str03);
            int netProfitRate = int.Parse(str04);
            double relToMaxP = double.Parse(str05);
            //int volRate = int.Parse(str06);

            group01 = filter01.GroupProducer(allCodesInfo, capital, profit, debt, netProfitRate, relToMaxP);    // step 1.2 Group the code list
            int length = group01.codeList.Count;        // step 1.3 observe one code of market items
            stockArray = new Stock[length];

            for (int i = 0; i < length; i++)            
                stockArray[i] = new Stock(this, group01.codeList[i], group01.codeName[i]);
            
            RefreshCodeList(group01.codeList);      // refresh codelist for SetRealReg accoding to the strategy. e.g. code;code;code

            // FilterDailyCandle();

            //Show the result of the filtered codelist before sending SetRealReg
            ShowFilteredCodeList(group01);            
        }

        // Return a string to be sent as SetRealReg parameter from input
        public string FilterDailyCandle(Group group)
        {
            // step 1 : collect the daily candles according to the code list. And Save them to the file
            string[] list = group.codeList.ToArray();
            Arrange(list);
            // step 2 : Filter the daily candles.
            string str = FilterCandles("aa");

            return str;
        }
 
        public void DailyCandleCollect()
        {
            string str04 = "";
            string str05 = "";
            string strData1 = "";
            string strData2 = "";
            string strData3 = "";
            string strData4 = "";
            string strData5 = "";
            string strData6 = "";
            string strData7 = "";

            string title = "거래량,시가,고가,저가,현재가,거래일자\r\n";

            int nCnt = axKHOpenAPI1.GetRepeatCnt("opt10081", "일봉차트");

            str05 = title;

            for (int nIdx = 0; nIdx < nCnt; nIdx++)
            {
                if (nIdx == 0)
                {
                    strData7 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "종목코드").Trim();
                }
                strData1 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "거래량").Trim(); // nIdx번째의 거래량 데이터 구함
                strData2 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "시가").Trim();
                strData3 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "고가").Trim();
                strData4 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "저가").Trim();
                strData5 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "현재가").Trim();
                strData6 = axKHOpenAPI1.GetCommData("opt10081", "일봉차트", nIdx, "일자").Trim();

                str04 = str04 + strData1 + "," + strData2 + "," + strData3 + "," + strData4 + "," + strData5 + "," + strData6 + "\r\n";
                str05 += str04;

                str04 = "";
            }
            File.WriteAllText(@"C:\Users\user\Desktop\stock\strategy\server\dailyCandle" + strData7 + ".txt", str05);
        }

        // step 3 Arrange the list with code name.
        public void Arrange(string[] strArr)
        {
            foreach (string str in strArr)
            {
                // step 2 : Tr Data 요청 OnreceiveTrData
                axKHOpenAPI1.SetInputValue("종목코드", str);

                //기준일자 = YYYYMMDD(20160101 연도4자리, 월 2자리, 일 2자리 형식)
                axKHOpenAPI1.SetInputValue("기준일자", "");

                //수정주가구분 = 0 or 1, 수신데이터 1:유상증자, 2:무상증자, 4:배당락, 8:액면분할, 16:액면병합, 32:기업합병, 64:감자, 256:권리락
                axKHOpenAPI1.SetInputValue("수정주가구분", "");

                int result = axKHOpenAPI1.CommRqData("일봉차트a", "opt10081", 0, GetScreenNumber());
                Thread.Sleep(1000);
            }
        }

        // step 2 : Filter the daily candles. And return a string of newly filtered code list. e.g. "000020;000040;000050" (semi colon separated)
        public string FilterCandles(string str)
        {
            List<string> list09 = new List<string>();
            foreach (string str03 in list09)
            {
                // step 1 : file data to momory in csvstyle

                // step 2 : csvstyle to DataTable

                // step 3 : apply algorithm to the DataTable
                FilterCandle();

                // step 4 : for if

                // step 5 : return file name.
            }
            return "a";
        }

        public void FilterCandle()
        {

        } 

        public void ShowFilteredCodeList(Group group)
        {
            logListBox.Items.Add($"항목수 : {group.codeName.Count}");
            logListBox.Items.Add($"항목수02 : {group.codeList.Count}");
            foreach (string str05 in group.codeName)
            {
                logListBox.Items.Add(str05);            
            }
        }

        public void RefreshCodeList(List<string> codes)     // refresh codelist for SetRealReg accoding to the strategy. e.g. code;code;code
        {
            codeList = "";
            foreach (string str in codes)
                codeList = codeList + str + ";";
            codeList = codeList.Trim(';');
        }

        public void SelectedIndexChanged(object sender, EventArgs e)
        {
            accNumber = listBoxAccount.SelectedItem.ToString();
            RQStocksState(accNumber, "SendAccount");         // StockInfo to DataGridView
        }

        private void Tabs_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (tcAccount.SelectedTab == tabAccount)
            {                
                RQStocksState(accNumber, "SendAccount");         // StockInfo to DataGridView
            }
            else if (tcAccount.SelectedTab == tabMissed)
            {
                Console.WriteLine("미체결 요청 , MissContract");
                MissContract();
            }
            else if (tcAccount.SelectedTab == tabPage3)
            {
                Console.WriteLine("tabPage3");
                RQStocksState(accNumber, "Result");
            }
        }

        private void Str_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tcStrategies.SelectedTab == tabPage1)
            {
                Console.WriteLine("Strategies 1");
                StrDaily();
            }
            else if (tcStrategies.SelectedTab == tabPage2)
            {
                Console.WriteLine("Strategies 2");
                StrWinds();
            }
            else if (tcStrategies.SelectedTab == tabPage4)
            {
                StrVolSoar();
            }
        }

        // shows missed stocks to DataGridView
        public void MissContract()
        {
            RQMissedStock(accNumber, "미체결요청");           // step 1 : send request        // step 2 : Tr receive  : OnReceiveTrData
        }

         // oneventconnect
        private void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            listBoxAccount.Items.Clear();

            if (e.nErrCode == 0)
            {
                string accountList = axKHOpenAPI1.GetLoginInfo("ACCLIST");
                accountList = accountList.Trim(new char[] { ';' });
                string[] accountArray = accountList.Split(';');

                for (int i = 0; i < accountArray.Length; i++)                    
                    listBoxAccount.Items.Add(accountArray[i]);               

                //DynamicStrToDgvDynamicStr();
            }

            //StrDaily();         // strategy daily
            //RQSetRealReg(codeList);     // send SetRealReg
        }

        private void API_OnReceiveMsg(object sendeer, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            logListBox.Items.Add($"Msg from server : {e.sMsg}");
            Console.WriteLine($"Msg from server : {e.sMsg}");
        }

        public void TradeAll(int orderType)
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가", "주문번호" }; // FID item
            string[] csv = TRToCsvStyle(list, "opt10075", "매도주문취소1111");

            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list07 = ExtractColumndata(csv, "주문번호");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)
            {                
                list04.Add(code.Remove(0, 1).Trim());
            }
            //int result = axKHOpenAPI1.SendOrder("일괄매도(시장가)", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, 0, "03", null);     
            //SellAllStocks(list04, list02, list03);
            TradeEachAndEvery(list04, list02, list03, list07, orderType);
        }

        //Sell All the stocks in once.
        public void TradeEachAndEvery(List<string> stockcodes, List<string> boughtPrices, List<string> volumn, List<string> originNum, int orderType)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {
                //int boughtPrice = int.Parse(boughtPrices[i]);
                //int vol = int.Parse(volumn[i]);                     // 보유 수량
                int vol = 1;

                //boughtPrice = PriceUnit(boughtPrice);
                int result = axKHOpenAPI1.SendOrder("그냥", GetScreenNumber(), accNumber, orderType, stockcodes[i], vol, 0, "03", originNum[i]);

                Thread.Sleep(300);
            }
        }

        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            if (e.sGubun.Equals("0"))       // 접수 or 체결
            {
                axKHOpenAPI1.GetChejanData(9201);
                axKHOpenAPI1.GetChejanData(9203);
                string orderState = axKHOpenAPI1.GetChejanData(913);        // 접수 or 체결

                if (orderState.Equals("접수"))                
                    logListBox.Items.Add("접수 호출");                

                else if (orderState.Equals("체결"))
                {
                    logListBox.Items.Add("체결 호출");

                    string orderNum = axKHOpenAPI1.GetChejanData(9203);

                    string str = axKHOpenAPI1.GetChejanData(910);
                    string code = axKHOpenAPI1.GetChejanData(9001);
                    string distinguish = axKHOpenAPI1.GetChejanData(907);

                    code = code.Remove(0, 1).Trim();

                    logListBox.Items.Add($"매도수 구분 : {distinguish}");

                    //send_selling_order  here if "체결신호 and 매매가 매수 인경우"
                    if (distinguish == "2")
                    {
                        //SendOrder_Sell(code, str);
                    }
                }
            }

            else if (e.sGubun.Equals("1"))  // 잔고
            {
            }

            else if (e.sGubun.Equals("4"))  // 파생잔고
            {
            }
        }

        // Distribute each code(group01.filteredCodeList) to each object(StockCode class) to find best condition and send order
        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            string volumn;

            for (int i = 0; i < group01.codeList.Count; i++)
            {
                if (e.sRealKey == group01.codeList[i])
                {
                    // data splited from the real time data
                    currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가
                    volumn = axKHOpenAPI1.GetCommRealData(e.sRealKey, 15);    // 거래량                    

                    Distribute02(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice, volumn);
                }
            }

            /***
            for (int i = 0; i < group01.codeList.Count; i++)
            {
                if (e.sRealKey == group01.codeList[i])
                {
                    // data splited from the real time data
                    currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가

                    Distribute(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice);
                    //Thread th = new Thread(()=>Distribute(stockArray[i], group01.codeList[i], group01.codeName[i], currentPrice));
                    //th.Start();
                }
            }
            ***/
        }

        // 미체결 주식 요청
        public void RQMissedStock(string accountNum, string rqName)
        {
            axKHOpenAPI1.SetInputValue("계좌번호", accountNum);
            axKHOpenAPI1.SetInputValue("전체종목구분", "0");
            axKHOpenAPI1.SetInputValue("매매구분", "0");
            axKHOpenAPI1.SetInputValue("종목코드", "");
            axKHOpenAPI1.SetInputValue("체결구분", "1");        // 체결구분 0:전체, 체결구분 1 : 순수 미체결
            axKHOpenAPI1.CommRqData(rqName, "opt10075", 0, "2030");       // Invoke OnReceiveTrData()
        }

        //============TrRequest function===============


        //============TrReceive function===============
        // 미체결 정보

        public void ReceiveTr(List<string> list, string trCode, string rqName)
        {
            string[] list02 = TRToCsvStyle(list, trCode, rqName);
            DataTable dt = CSVStyleToDataTable(list02);
            dgvAccountInfo.DataSource = dt;            
        }

        public void MissedContract(List<string> list, string trCode, string rqName)
        {
            string[] list02 = TRToCsvStyle(list, trCode, rqName);
            DataTable dt = CSVStyleToDataTable(list02);            
            dgvMissed.DataSource = dt;
        }

        public string[] TRToCsvStyle(List<string> list, string orderCode, string rqName)         // Return csv-styled table data of List<string> from OnReceiveTrData
        {
            List<string> csvStyle = new List<string>();     // csv style in memory.
            string csvStyleHeader = "";         // header
            string rowData = "";                // rowdata

            //1. header part
            foreach (string item in list)            
                csvStyleHeader = csvStyleHeader + $"{item},";        
            csvStyleHeader = csvStyleHeader.TrimEnd(',');
            csvStyle.Add(csvStyleHeader);

            //2. body part
            int count = axKHOpenAPI1.GetRepeatCnt(orderCode, rqName);
            for (int i = 0; i < count; i++)
            {
                rowData = "";
                foreach (string item in list)                
                    rowData = rowData + axKHOpenAPI1.GetCommData(orderCode, rqName, i, item).Trim() + ",";                
                rowData = rowData.TrimEnd(',');
                csvStyle.Add(rowData);
            }
            string[] csvType = csvStyle.ToArray();
            return csvType;
        }
       
        //============TrReceive function===============


        //============Send order function===============
        public void SendOrder_Sell(string code, string executionPrice)
        {
            double temp = double.Parse(executionPrice);
            double sellingPrice = temp + (temp * 0.01);

            int result = axKHOpenAPI1.SendOrder("주식주문", GetScreenNumber(), accNumber, 2, code, 1, (int)sellingPrice, "00", null);
            if (result == 0)
            {
                logListBox.Items.Add($"매도 주문 요청 성공 : {code}, 매도 가격: {sellingPrice}");
            }
        }

        //Sell All the stocks in once.
        public void SellAllStocks(List<string> stockcodes, List<string> boughtPrices, List<string> volumn)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {
                int boughtPrice = int.Parse(boughtPrices[i]);
                int vol = int.Parse(volumn[i]);                     // 보유 수량
                boughtPrice = PriceUnit(boughtPrice);
                int result = axKHOpenAPI1.SendOrder("orderAll(시장가)", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, 0, "03", null);

                Thread.Sleep(300);
            }
        }

        //Sell All the stocks in once.
        public void SellAllStocks02(List<string> stockcodes, List<string> boughtPrices, List<string> volumn)
        {
            for (int i = 0; i < stockcodes.Count; i++)
            {
                int boughtPrice = int.Parse(boughtPrices[i]);
                int vol = int.Parse(volumn[i]);                     // 보유 수량
                boughtPrice = PriceUnit(boughtPrice);
                int result = axKHOpenAPI1.SendOrder("지정가매도주문", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, boughtPrice, "00", null);                
                
                Thread.Sleep(300);
            }
        }

        //============send order function===============

        // Distribute each code and price to each Stock object.        

        // 전량매수주문취소
        public void AccountInfo03()
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가" }; // FID item
            string[] csv = TRToCsvStyle(list, "opw00004", "SellAll(시장가)");

            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)
            {
                list04.Add(code.Remove(0, 1).Trim());
            }
            //int result = axKHOpenAPI1.SendOrder("일괄매도(시장가)", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, 0, "03", null);     
            //SellAllStocks(list04, list02, list03);
        }

        // 전량매도주문취소
        public void AccountInfo04()
        {
            List<string> list = new List<string>() { "종목코드", "종목명", "보유수량", "평균단가" }; // FID item
            string[] csv = TRToCsvStyle(list, "opw00004", "SellAll(시장가)");

            List<string> list01 = ExtractColumndata(csv, "종목코드");            // return column data from csvstyle data
            List<string> list02 = ExtractColumndata(csv, "평균단가");            // return column data from csvstyle data
            List<string> list03 = ExtractColumndata(csv, "보유수량");            // return column data from csvstyle data
            List<string> list04 = new List<string>();

            foreach (string code in list01)
            {
                list04.Add(code.Remove(0, 1).Trim());
            }
            //int result = axKHOpenAPI1.SendOrder("일괄매도(시장가)", GetScreenNumber(), accNumber, 2, stockcodes[i], vol, 0, "03", null);     
            //SellAllStocks(list04, list02, list03);
        }

        public void Distribute(Stock stock, string code, string name, string curPrice)
        {
            stock.Code = code;
            stock.Name = name;
            stock.currentPrice = curPrice;

            try
            {
                stock.GetTheChance();
            }

            catch
            {
                logListBox.Items.Add("exception occured");
            }
        }

        // Distribute each code and price to each Stock object.
        public void Distribute02(Stock stock, string code, string name, string curPrice, string volumn)
        {
            stock.Code = code;
            stock.Name = name;
            stock.currentPrice = curPrice;
            //stock.volumn.Add(volumn);

            try
            {
                stock.GetTheChance02(volumn);
            }

            catch
            {
                logListBox.Items.Add("exception occured");
            }
        }

        //================= 실시간 데이터 요청
        public void RQSetRealReg(string codeList)
        {
            logListBox.Items.Add("codeList : " + codeList);

            int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server               
            if (result == 0)
                logListBox.Items.Add("setRealReg 요청 성공");
        }
        //================= 실시간 데이터 요청


        //============== utility function ======================

        public List<string> ExtractColumndata(string[] csvStyleData, string columnName)     // extract column data from csvstyle data
        {
            int j = 0;
            int index = 0;      // for column index
            List<string> columnData = new List<string>();

            foreach (string str in csvStyleData)
            {
                string[] items = str.Split(',');

                // header part
                if (j == 0)
                {
                    for (int i = 0; i < items.Length; i++)
                    {
                        if (items[i] == columnName)     // find the index of column asked of the columName
                        {
                            index = i;
                        }
                    }
                }

                // body part
                else
                {
                    for (int k = 0; k < items.Length; k++)
                    {
                        if (k == index)
                        {
                            columnData.Add(items[k]);
                        }
                    }
                }
                j++;
            }
            return columnData;
        }

        public string GetScreenNumber()
        {
            if (screenNumber == 9999)
                screenNumber = 1001;

            screenNumber++;
            string str = screenNumber.ToString();
            return str;
        }

        public void p()
        {
            Console.WriteLine("here===================");
        }
        public void p(object obj)
        {
            Console.WriteLine(obj);
        }

        public int PriceUnit(int proposedPrice)
        {
            if (proposedPrice < 1000)
            {
                proposedPrice = (proposedPrice / 1) * 1;
            }

            else if (proposedPrice < 5000)
            {
                proposedPrice = (proposedPrice / 5) * 5;
            }
            else if (proposedPrice < 10000)
            {
                proposedPrice = (proposedPrice / 10) * 10;
            }
            else if (proposedPrice < 50000)
            {
                proposedPrice = (proposedPrice / 50) * 50;
            }
            else if (proposedPrice < 100000)
            {
                proposedPrice = (proposedPrice / 100) * 100;
            }
            else if (proposedPrice < 500000)
            {
                proposedPrice = (proposedPrice / 500) * 500;
            }

            else
            {
                proposedPrice = (proposedPrice / 1000) * 1000;
            }
            return proposedPrice;
        }

        public void DynamicStrDaily(string filename)     // Csv file (of DynamicStr) to datagridview (of DynamicStr) onEventConnect.
        {
            string filePath = @"C:\Users\user\Desktop\stock\strategy\commondata\DynamicStr\" + filename;            
            string[] csvStyle = File.ReadAllLines(filePath);            // step1  : file to csvstyle
            DataTable dt03 = CSVStyleToDataTable(csvStyle);         // step2  : csvstyle to datatable
            dgvDynamicStr.DataSource = dt03;            // step3  : datable to datagridview
        }

        public void DynamicStrVolSoar(string filename)     // Csv file (of DynamicStr) to datagridview (of DynamicStr) onEventConnect.
        {
            string filePath = @"C:\Users\user\Desktop\stock\strategy\commondata\DynamicStr\" + filename;            
            string[] csvStyle = File.ReadAllLines(filePath);        // step1  : file to csvstyle            
            DataTable dt04 = CSVStyleToDataTable(csvStyle);         // step2  : csvstyle to datatable            
            dgvStrVolSoar.DataSource = dt04;                        // step3  : datable to datagridview
        }

        public void CancelAll()
        {
            //step1: collect Account information
            //RQStocksState();
            //step1: Send order 
            //step1:
            //step1:
        }

        //============== utility function ======================
    }
}