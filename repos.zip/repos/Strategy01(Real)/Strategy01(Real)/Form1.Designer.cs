﻿
namespace Strategy01_Real_
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnRegRemove = new System.Windows.Forms.Button();
            this.listBoxAccount = new System.Windows.Forms.ListBox();
            this.btnCancelAllBuy = new System.Windows.Forms.Button();
            this.btnCancelAllSell = new System.Windows.Forms.Button();
            this.tcAccount = new System.Windows.Forms.TabControl();
            this.tabAccount = new System.Windows.Forms.TabPage();
            this.dgvAccountInfo = new System.Windows.Forms.DataGridView();
            this.tabMissed = new System.Windows.Forms.TabPage();
            this.dgvMissed = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgvResult = new System.Windows.Forms.DataGridView();
            this.tcStrategies = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvDynamicStr = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgvTest = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgvStrVolSoar = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.logListBox = new System.Windows.Forms.ListBox();
            this.comboSetRealReg = new System.Windows.Forms.ComboBox();
            this.comboAccount = new System.Windows.Forms.ComboBox();
            this.comboReserved02 = new System.Windows.Forms.ComboBox();
            this.btnSellAll02 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.comboRelToMaxP = new System.Windows.Forms.ComboBox();
            this.comboNetProfitRate = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDebtPortionStr = new System.Windows.Forms.ComboBox();
            this.btnProfitStr = new System.Windows.Forms.ComboBox();
            this.btnCapitalStr = new System.Windows.Forms.ComboBox();
            this.comboReserved = new System.Windows.Forms.ComboBox();
            this.btnReSet = new System.Windows.Forms.Button();
            this.btnStrVolSoar = new System.Windows.Forms.Button();
            this.btnSellAll = new System.Windows.Forms.Button();
            this.realDataButton = new System.Windows.Forms.Button();
            this.loginButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tcAccount.SuspendLayout();
            this.tabAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountInfo)).BeginInit();
            this.tabMissed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMissed)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).BeginInit();
            this.tcStrategies.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDynamicStr)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStrVolSoar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnRegRemove);
            this.groupBox1.Controls.Add(this.listBoxAccount);
            this.groupBox1.Controls.Add(this.btnCancelAllBuy);
            this.groupBox1.Controls.Add(this.btnCancelAllSell);
            this.groupBox1.Controls.Add(this.tcAccount);
            this.groupBox1.Controls.Add(this.tcStrategies);
            this.groupBox1.Controls.Add(this.logListBox);
            this.groupBox1.Controls.Add(this.comboSetRealReg);
            this.groupBox1.Controls.Add(this.comboAccount);
            this.groupBox1.Controls.Add(this.comboReserved02);
            this.groupBox1.Controls.Add(this.btnSellAll02);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.comboRelToMaxP);
            this.groupBox1.Controls.Add(this.comboNetProfitRate);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.axKHOpenAPI1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnDebtPortionStr);
            this.groupBox1.Controls.Add(this.btnProfitStr);
            this.groupBox1.Controls.Add(this.btnCapitalStr);
            this.groupBox1.Controls.Add(this.comboReserved);
            this.groupBox1.Controls.Add(this.btnReSet);
            this.groupBox1.Controls.Add(this.btnStrVolSoar);
            this.groupBox1.Controls.Add(this.btnSellAll);
            this.groupBox1.Controls.Add(this.realDataButton);
            this.groupBox1.Controls.Add(this.loginButton);
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1731, 732);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // btnRegRemove
            // 
            this.btnRegRemove.Location = new System.Drawing.Point(855, 362);
            this.btnRegRemove.Name = "btnRegRemove";
            this.btnRegRemove.Size = new System.Drawing.Size(92, 27);
            this.btnRegRemove.TabIndex = 47;
            this.btnRegRemove.Text = "RegRemove";
            this.btnRegRemove.UseVisualStyleBackColor = true;
            // 
            // listBoxAccount
            // 
            this.listBoxAccount.FormattingEnabled = true;
            this.listBoxAccount.ItemHeight = 12;
            this.listBoxAccount.Location = new System.Drawing.Point(1579, 362);
            this.listBoxAccount.Name = "listBoxAccount";
            this.listBoxAccount.Size = new System.Drawing.Size(120, 196);
            this.listBoxAccount.TabIndex = 40;
            // 
            // btnCancelAllBuy
            // 
            this.btnCancelAllBuy.Location = new System.Drawing.Point(32, 205);
            this.btnCancelAllBuy.Name = "btnCancelAllBuy";
            this.btnCancelAllBuy.Size = new System.Drawing.Size(109, 23);
            this.btnCancelAllBuy.TabIndex = 45;
            this.btnCancelAllBuy.Text = "매수취소(all)";
            this.btnCancelAllBuy.UseVisualStyleBackColor = true;
            // 
            // btnCancelAllSell
            // 
            this.btnCancelAllSell.Location = new System.Drawing.Point(32, 173);
            this.btnCancelAllSell.Name = "btnCancelAllSell";
            this.btnCancelAllSell.Size = new System.Drawing.Size(109, 23);
            this.btnCancelAllSell.TabIndex = 44;
            this.btnCancelAllSell.Text = "매도취소(all)";
            this.btnCancelAllSell.UseVisualStyleBackColor = true;
            // 
            // tcAccount
            // 
            this.tcAccount.Controls.Add(this.tabAccount);
            this.tcAccount.Controls.Add(this.tabMissed);
            this.tcAccount.Controls.Add(this.tabPage3);
            this.tcAccount.Location = new System.Drawing.Point(305, 377);
            this.tcAccount.Name = "tcAccount";
            this.tcAccount.SelectedIndex = 0;
            this.tcAccount.Size = new System.Drawing.Size(1000, 212);
            this.tcAccount.TabIndex = 39;
            // 
            // tabAccount
            // 
            this.tabAccount.Controls.Add(this.dgvAccountInfo);
            this.tabAccount.Location = new System.Drawing.Point(4, 22);
            this.tabAccount.Name = "tabAccount";
            this.tabAccount.Padding = new System.Windows.Forms.Padding(3);
            this.tabAccount.Size = new System.Drawing.Size(992, 186);
            this.tabAccount.TabIndex = 0;
            this.tabAccount.Text = "Account";
            this.tabAccount.UseVisualStyleBackColor = true;
            // 
            // dgvAccountInfo
            // 
            this.dgvAccountInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAccountInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAccountInfo.Location = new System.Drawing.Point(3, 3);
            this.dgvAccountInfo.Name = "dgvAccountInfo";
            this.dgvAccountInfo.RowTemplate.Height = 23;
            this.dgvAccountInfo.Size = new System.Drawing.Size(986, 180);
            this.dgvAccountInfo.TabIndex = 37;
            // 
            // tabMissed
            // 
            this.tabMissed.Controls.Add(this.dgvMissed);
            this.tabMissed.Location = new System.Drawing.Point(4, 22);
            this.tabMissed.Name = "tabMissed";
            this.tabMissed.Padding = new System.Windows.Forms.Padding(3);
            this.tabMissed.Size = new System.Drawing.Size(992, 186);
            this.tabMissed.TabIndex = 1;
            this.tabMissed.Text = "미체결";
            this.tabMissed.UseVisualStyleBackColor = true;
            // 
            // dgvMissed
            // 
            this.dgvMissed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMissed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvMissed.Location = new System.Drawing.Point(3, 3);
            this.dgvMissed.Name = "dgvMissed";
            this.dgvMissed.RowTemplate.Height = 23;
            this.dgvMissed.Size = new System.Drawing.Size(986, 180);
            this.dgvMissed.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgvResult);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(992, 186);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Result";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgvResult
            // 
            this.dgvResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvResult.Location = new System.Drawing.Point(3, 3);
            this.dgvResult.Name = "dgvResult";
            this.dgvResult.RowTemplate.Height = 23;
            this.dgvResult.Size = new System.Drawing.Size(986, 180);
            this.dgvResult.TabIndex = 0;
            // 
            // tcStrategies
            // 
            this.tcStrategies.Controls.Add(this.tabPage1);
            this.tcStrategies.Controls.Add(this.tabPage2);
            this.tcStrategies.Controls.Add(this.tabPage4);
            this.tcStrategies.Controls.Add(this.tabPage5);
            this.tcStrategies.Controls.Add(this.tabPage6);
            this.tcStrategies.Controls.Add(this.tabPage7);
            this.tcStrategies.Controls.Add(this.tabPage8);
            this.tcStrategies.Controls.Add(this.tabPage9);
            this.tcStrategies.Location = new System.Drawing.Point(320, 104);
            this.tcStrategies.Name = "tcStrategies";
            this.tcStrategies.SelectedIndex = 0;
            this.tcStrategies.Size = new System.Drawing.Size(989, 220);
            this.tcStrategies.TabIndex = 43;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvDynamicStr);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(981, 194);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "StrDaily";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvDynamicStr
            // 
            this.dgvDynamicStr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDynamicStr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDynamicStr.Location = new System.Drawing.Point(3, 3);
            this.dgvDynamicStr.Name = "dgvDynamicStr";
            this.dgvDynamicStr.RowTemplate.Height = 23;
            this.dgvDynamicStr.Size = new System.Drawing.Size(975, 188);
            this.dgvDynamicStr.TabIndex = 42;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgvTest);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(981, 194);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "StrWinds";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgvTest
            // 
            this.dgvTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTest.Location = new System.Drawing.Point(3, 3);
            this.dgvTest.Name = "dgvTest";
            this.dgvTest.RowTemplate.Height = 23;
            this.dgvTest.Size = new System.Drawing.Size(975, 188);
            this.dgvTest.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dgvStrVolSoar);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(981, 194);
            this.tabPage4.TabIndex = 2;
            this.tabPage4.Text = "StrVolSoaring";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dgvStrVolSoar
            // 
            this.dgvStrVolSoar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStrVolSoar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStrVolSoar.Location = new System.Drawing.Point(0, 0);
            this.dgvStrVolSoar.Name = "dgvStrVolSoar";
            this.dgvStrVolSoar.RowTemplate.Height = 23;
            this.dgvStrVolSoar.Size = new System.Drawing.Size(981, 194);
            this.dgvStrVolSoar.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(981, 194);
            this.tabPage5.TabIndex = 3;
            this.tabPage5.Text = "tabPag";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(981, 194);
            this.tabPage6.TabIndex = 4;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(981, 194);
            this.tabPage7.TabIndex = 5;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(981, 194);
            this.tabPage8.TabIndex = 6;
            this.tabPage8.Text = "tabPage8";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(981, 194);
            this.tabPage9.TabIndex = 7;
            this.tabPage9.Text = "tabPage9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // logListBox
            // 
            this.logListBox.FormattingEnabled = true;
            this.logListBox.ItemHeight = 12;
            this.logListBox.Location = new System.Drawing.Point(6, 391);
            this.logListBox.Name = "logListBox";
            this.logListBox.Size = new System.Drawing.Size(237, 172);
            this.logListBox.TabIndex = 17;
            // 
            // comboSetRealReg
            // 
            this.comboSetRealReg.FormattingEnabled = true;
            this.comboSetRealReg.Location = new System.Drawing.Point(171, 87);
            this.comboSetRealReg.Name = "comboSetRealReg";
            this.comboSetRealReg.Size = new System.Drawing.Size(94, 20);
            this.comboSetRealReg.TabIndex = 41;
            // 
            // comboAccount
            // 
            this.comboAccount.FormattingEnabled = true;
            this.comboAccount.IntegralHeight = false;
            this.comboAccount.Location = new System.Drawing.Point(166, 51);
            this.comboAccount.Name = "comboAccount";
            this.comboAccount.Size = new System.Drawing.Size(100, 20);
            this.comboAccount.TabIndex = 40;
            // 
            // comboReserved02
            // 
            this.comboReserved02.FormattingEnabled = true;
            this.comboReserved02.Location = new System.Drawing.Point(147, 144);
            this.comboReserved02.Name = "comboReserved02";
            this.comboReserved02.Size = new System.Drawing.Size(120, 20);
            this.comboReserved02.TabIndex = 34;
            // 
            // btnSellAll02
            // 
            this.btnSellAll02.Location = new System.Drawing.Point(32, 143);
            this.btnSellAll02.Name = "btnSellAll02";
            this.btnSellAll02.Size = new System.Drawing.Size(109, 23);
            this.btnSellAll02.TabIndex = 33;
            this.btnSellAll02.Text = "일괄매도(지정가)";
            this.btnSellAll02.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(802, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 12);
            this.label12.TabIndex = 32;
            this.label12.Text = "250 최고가 비율";
            // 
            // comboRelToMaxP
            // 
            this.comboRelToMaxP.FormattingEnabled = true;
            this.comboRelToMaxP.Items.AddRange(new object[] {
            "-100",
            "-90",
            "-80",
            "-70",
            "-60",
            "-50",
            "-40",
            "-30",
            "-20",
            "-10",
            "0"});
            this.comboRelToMaxP.Location = new System.Drawing.Point(793, 40);
            this.comboRelToMaxP.Name = "comboRelToMaxP";
            this.comboRelToMaxP.Size = new System.Drawing.Size(100, 20);
            this.comboRelToMaxP.TabIndex = 31;
            // 
            // comboNetProfitRate
            // 
            this.comboNetProfitRate.FormattingEnabled = true;
            this.comboNetProfitRate.Items.AddRange(new object[] {
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.comboNetProfitRate.Location = new System.Drawing.Point(681, 40);
            this.comboNetProfitRate.Name = "comboNetProfitRate";
            this.comboNetProfitRate.Size = new System.Drawing.Size(99, 20);
            this.comboNetProfitRate.TabIndex = 30;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(685, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 12);
            this.label11.TabIndex = 29;
            this.label11.Text = "순이익율(%)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(370, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 21);
            this.label9.TabIndex = 27;
            this.label9.Text = "Static Strategy";
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(1579, 189);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(575, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 12);
            this.label3.TabIndex = 20;
            this.label3.Text = "Debt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(471, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 19;
            this.label2.Text = "Profit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(359, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 12);
            this.label1.TabIndex = 18;
            this.label1.Text = "Capital";
            // 
            // btnDebtPortionStr
            // 
            this.btnDebtPortionStr.FormattingEnabled = true;
            this.btnDebtPortionStr.Location = new System.Drawing.Point(566, 40);
            this.btnDebtPortionStr.Name = "btnDebtPortionStr";
            this.btnDebtPortionStr.Size = new System.Drawing.Size(98, 20);
            this.btnDebtPortionStr.TabIndex = 11;
            // 
            // btnProfitStr
            // 
            this.btnProfitStr.FormattingEnabled = true;
            this.btnProfitStr.Items.AddRange(new object[] {
            "5000",
            "4000",
            "3000",
            "2000",
            "1000",
            "500",
            "300",
            "200",
            "100",
            "90",
            "80",
            "70",
            "60",
            "50",
            "40",
            "30",
            "20",
            "10",
            "9",
            "8",
            "7",
            "6",
            "5",
            "4",
            "3",
            "2",
            "1",
            "0"});
            this.btnProfitStr.Location = new System.Drawing.Point(462, 40);
            this.btnProfitStr.Name = "btnProfitStr";
            this.btnProfitStr.Size = new System.Drawing.Size(89, 20);
            this.btnProfitStr.TabIndex = 10;
            // 
            // btnCapitalStr
            // 
            this.btnCapitalStr.FormattingEnabled = true;
            this.btnCapitalStr.Items.AddRange(new object[] {
            "5000",
            "4000",
            "3000",
            "2000",
            "1000",
            "500",
            "100",
            "90",
            "80",
            "70",
            "60",
            "50",
            "40",
            "30",
            "20",
            "10",
            "0"});
            this.btnCapitalStr.Location = new System.Drawing.Point(350, 40);
            this.btnCapitalStr.Name = "btnCapitalStr";
            this.btnCapitalStr.Size = new System.Drawing.Size(94, 20);
            this.btnCapitalStr.TabIndex = 9;
            // 
            // comboReserved
            // 
            this.comboReserved.FormattingEnabled = true;
            this.comboReserved.Location = new System.Drawing.Point(147, 115);
            this.comboReserved.Name = "comboReserved";
            this.comboReserved.Size = new System.Drawing.Size(121, 20);
            this.comboReserved.TabIndex = 8;
            // 
            // btnReSet
            // 
            this.btnReSet.Location = new System.Drawing.Point(1559, 139);
            this.btnReSet.Name = "btnReSet";
            this.btnReSet.Size = new System.Drawing.Size(106, 23);
            this.btnReSet.TabIndex = 7;
            this.btnReSet.Text = "Reset";
            this.btnReSet.UseVisualStyleBackColor = true;
            // 
            // btnStrVolSoar
            // 
            this.btnStrVolSoar.Location = new System.Drawing.Point(1559, 78);
            this.btnStrVolSoar.Name = "btnStrVolSoar";
            this.btnStrVolSoar.Size = new System.Drawing.Size(106, 23);
            this.btnStrVolSoar.TabIndex = 5;
            this.btnStrVolSoar.Text = "StrVolSoaring";
            this.btnStrVolSoar.UseVisualStyleBackColor = true;
            // 
            // btnSellAll
            // 
            this.btnSellAll.Location = new System.Drawing.Point(32, 116);
            this.btnSellAll.Name = "btnSellAll";
            this.btnSellAll.Size = new System.Drawing.Size(109, 19);
            this.btnSellAll.TabIndex = 2;
            this.btnSellAll.Text = "일괄매도(시장가)";
            this.btnSellAll.UseVisualStyleBackColor = true;
            // 
            // realDataButton
            // 
            this.realDataButton.Location = new System.Drawing.Point(32, 85);
            this.realDataButton.Name = "realDataButton";
            this.realDataButton.Size = new System.Drawing.Size(109, 22);
            this.realDataButton.TabIndex = 1;
            this.realDataButton.Text = "SetRealReg";
            this.realDataButton.UseVisualStyleBackColor = true;
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(32, 44);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(109, 29);
            this.loginButton.TabIndex = 0;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1756, 806);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tcAccount.ResumeLayout(false);
            this.tabAccount.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountInfo)).EndInit();
            this.tabMissed.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMissed)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult)).EndInit();
            this.tcStrategies.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDynamicStr)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStrVolSoar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        public AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox btnDebtPortionStr;
        private System.Windows.Forms.ComboBox btnProfitStr;
        private System.Windows.Forms.ComboBox btnCapitalStr;
        private System.Windows.Forms.ComboBox comboReserved;
        private System.Windows.Forms.Button btnReSet;
        private System.Windows.Forms.Button btnStrVolSoar;
        private System.Windows.Forms.Button btnSellAll;
        private System.Windows.Forms.Button realDataButton;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboNetProfitRate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboRelToMaxP;
        private System.Windows.Forms.Button btnSellAll02;
        private System.Windows.Forms.ComboBox comboReserved02;
        private System.Windows.Forms.ComboBox comboAccount;
        private System.Windows.Forms.ComboBox comboSetRealReg;
        private System.Windows.Forms.TabControl tcStrategies;
        private System.Windows.Forms.TabPage tabPage1;
        public System.Windows.Forms.DataGridView dgvDynamicStr;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvTest;
        private System.Windows.Forms.Button btnCancelAllBuy;
        private System.Windows.Forms.Button btnCancelAllSell;
        private System.Windows.Forms.Button btnRegRemove;
        private System.Windows.Forms.ListBox listBoxAccount;
        private System.Windows.Forms.TabControl tcAccount;
        private System.Windows.Forms.TabPage tabAccount;
        private System.Windows.Forms.DataGridView dgvAccountInfo;
        private System.Windows.Forms.TabPage tabMissed;
        private System.Windows.Forms.DataGridView dgvMissed;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgvResult;
        public System.Windows.Forms.ListBox logListBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dgvStrVolSoar;
    }



}

