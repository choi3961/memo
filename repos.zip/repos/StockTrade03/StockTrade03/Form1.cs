﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockTrade03
{
    public partial class Form1 : Form
    {
        public Items_For_Buying items;                              // an object of class for buying order 
        List<string[]> listFromServer = new List<string[]>();       // container for real time data from Kiwoom Server.
        int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        int bLocation;                  // location of bottomPoints
        int flag;                       // flag for bottomPoints
        bool orderSent;                 // check if order is sent at the third bottom point.
        double bottomFoundTime;
        double currentTime;             // to compare the current time with elapsed time

        List<string> filteredCodeList;

        StockCode[] stockcodes;
        Strategy01 str01;                      // Strategy in perfect machine trading. One strategy for one stock item.
        Strategy01.Observer observer;
        
        // Information about the all the lowest bottom points
        BottomInfo firstBottom;         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        BottomInfo secondtBottom;       // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        BottomInfo thirdBottom;         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        List<BottomInfo> bottomsInfo;   // List that contains the information of all the bottoms

        int bottomCount = 0;             //temporary variable for onreceiveiverealData test.
        int eventCount = 0;                //temporary variable for onreceiveiverealData test.
        string lowPrice = "";              //temporary variable for onreceiveiverealData test.

        public Form1()
        {
            InitializeComponent();
            Trade();
        }

        private void Trade()
        {
            bLocation = 0;                          // location of bottomPoints
            bottomFoundTime = (DateTime.Now - DateTime.MinValue).TotalMilliseconds;
            bottomPoints = new int[2, 200];
            flag = 0;
            orderSent = false;
            bottomPoints[0, 0] = 200000;            // temporary

            filteredCodeList = new List<string>();
            str01 = new Strategy01(this);
            observer = new Strategy01.Observer(this);
            firstBottom = new BottomInfo();         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
            secondtBottom = new BottomInfo();       // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
            thirdBottom = new BottomInfo();         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)

            //Login
            Login();

            //Start trading
            str01.Init();
            str01.StartTrading();

            //Logout
            Logout();
            //end
        }

        //Login function
        private void Login()
        {
            int a = axKHOpenAPI1.CommConnect();
            if (a == 0)
            {
            }
        }

        //Logout function
        private void Logout()
        {
        }

        //Step 1 function : find best buying condition
        //     substep 1 : send "setrealreg" function of codeList to the server.
        //     substep 2 : call send order function
        public void Catch_Best_Condition(List<string> code)
        {
            //substep 1 :  send "setrealreg" function of codeList to the server.
            realDataButton.Click += Button_Click;

            // background event (system event) for real time data from Kiwoom Server.
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;
         
        }

        //Step 2 function
        private void Send_Order_Buying(string rqname, string scrNum, string accNum, int orderType, string itemCodee, int quantity, int price, string trType, string ori_Num)
        {
             // Send order to the server
            int result = axKHOpenAPI1.SendOrder(rqname, scrNum, accNum, orderType, itemCodee, quantity, price, trType, ori_Num);

            //int result = axKHOpenAPI1.SendOrder(items.rqname, items.scrNum, items.accNum, items.orderType, items.itemCode, items.quantity, items.price, items.trType, items.ori_Num);
            if (result == 0)       // 요청성공
            {
                Console.WriteLine("주문요청 성공");
            }
            else    // sendOrder failed
            {
            }
        }

        //Step 3 function
        private void Send_Order_Selling()
        {
            Console.WriteLine("Send order of selling");

            if (true)           // if sould out
            {
                Check_Market();
            }
            else
            {
                
            }
        }

        //Step 4 function
        private void Check_Market()
        {
            if (true)               // if the market is closed
            {
                Report_Result();
            }
        }

        //Step 5 function
        private void Report_Result()
        {
        }

        // algorithm for best buying condition
        public bool BestCondition()
        {
            if (flag == 3 && orderSent == false && bottomPoints[0, 2] != 0 && (currentTime - bottomFoundTime) >= 1000000)
            {
                orderSent = true;

                return true;
            }
            else
            {
                return false;
            }
            
        }

        // Find bottom Points to send order of buying. if lower price found, send the data to bottomPoints      
        // step 1 : compare the previous value with newly evented value
        // step 2 : if(true) insert the value, if not desert the value
        // step 3 : if(third bottom found) send order of buying stock.
        public void BottomPoints(int lowPrice, double currentTime)
        {
            // step 1 : compare the previous value with newly evented value
            int previous = bottomPoints[0, bLocation];  // extract data from in the bottomPoints
            int newly = lowPrice;                // extract data from the Kiwoom server
            Compare(previous, newly, bLocation);        // compare A with B

            // step 2 : if(true) insert the value, if not desert the value ;  insert function called from compare function

            // step 3 : if(third bottom found) send order of buying stock. : check if third bottomPoint is found

            if (BestCondition())
            {
                //send_buying_order  here
                Send_Order_Buying("주식주문", "1001", "8008765411", 1, "000020", 1, 0, "03", null);
            }
        }

        public void Compare(int previous, int newly, int bLoc)
        {
            if (previous > newly)
            {
                // step 2 of BottomPoints : if(true) insert the value, if not desert the value
                // next bottom point
                if ((currentTime - bottomFoundTime) >= 1000000)          //  5 minutes. 
                {
                    bLocation++;

                    // Register previous bottom information
                    flag++;
                    Insert(0, bLocation, newly);

                    //timeElapsed = 0;
                    bottomFoundTime = ((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                }
                else
                {
                    Insert(0, bLoc, newly);
                }

                Show_result(lowPrice);
            }
            else
            {

            }
        }

        public void Insert(int vertical, int location, int value)
        {
            bottomPoints[vertical, location] = value;
        }

        public void Show_result(string lowP)
        {
            listBox.Items.Add("저가 : " + lowP);
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(realDataButton))
            {
                ///int result = 35;
                //string itemCode = itemCodeTextBox.Text;
                //axKHOpenAPI1.SetInputValue("종목코드", "000020");                                       // 일반 주식 TR 요청


                /**
                int result = axKHOpenAPI1.SetRealReg("1001", "000020;000040", "9001;10", "0");
                if (result == 0)
                {
                    Console.WriteLine("setRealReg 요청 성공");
                }
                **/

                //int result = axKHOpenAPI1.CommRqData("주식기본정보요청", "opt10001", 0, "1001");        // 일반 주식 TR 요청

                string codeList = "";

                foreach (string str in filteredCodeList)
                {
                    codeList = codeList + str + ";";
                }

                char[] toTrim = {';'};
                codeList = codeList.TrimEnd(toTrim);

                Console.WriteLine("codeList : " + codeList );
                
                int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server               
                if (result == 0)
                {
                    Console.WriteLine("setRealReg 요청 성공");
                }
                else
                {
                    Console.WriteLine("주식기본 정보 요청에 실패하였습니다.");
                }

            }

            //foreach (int i in bottomPoints)
            //{
                //Console.WriteLine(i + " in bottomPoints");
            //}
        }

        // Distribute each code(filteredCodeList) to each object(StockCode class) to find best condition and send order
        private void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            for (int i = 0; i< filteredCodeList.Count; i++)
            {
                //if (code from the server == filteredcodelist[i])
                //{
                StockCode stockCode = new StockCode();
                //stockCode.function;
                //}

            }



            string first;       // for receiving data splited from the real time data
            string currentPrice;      // for receiving data splited from the real time data
            int price;

            //DateTime currentTime; // to compare the current time with elapsed time         
            currentTime = (DateTime.Now - DateTime.MinValue).TotalMilliseconds;

            string[] strArr = new string[10];
            eventCount++;

            if ((currentTime - bottomFoundTime) >= 10000)          //  5 minutes. 
            {
                Console.WriteLine("10초 경과");
                //timeElapsed = 0;
                bottomFoundTime = ((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
            }

            /*
            e.sRealType;    // 실시간 타입
            e.sRealKey;     // 종목코드
            e.sRealData;    // 실시간 데이터
            */

            // data splited from the real time data
            first = axKHOpenAPI1.GetCommRealData(e.sRealKey, 17);           // 고가
            currentPrice = axKHOpenAPI1.GetCommRealData(e.sRealKey, 10);    // 현재가
            strArr[0] = first;
            strArr[1] = currentPrice;

            Console.WriteLine("Getcommrealdata first : " + first);
            Console.WriteLine("Getcommrealdata curentPrice : " + currentPrice);

            listFromServer.Add(strArr);                     // container for real time data to use for algorithm from Kiwoom Server.

            // remove "-" 
            currentPrice = currentPrice.Trim();
            price = int.Parse(currentPrice);
            price = Math.Abs(price);

            BottomPoints(price, currentTime);    // Find bottom Points to send order of buying. if found, send the data to bottomPoints 
        }

        // strategy class for trading.    use Thread for each code.
        // step 1 Filter the codelist
        // step 2 Group the code list
        // step 3 observe one code of market items using Thread
        // step 4 send buying signal
        public class Strategy01             // perfect machine trading.
        {
            
            Filter filter01;
            Observer observer01;
            Group group01;
            
            //List<CodeInfo> allCodesInfo;
            private Form1 outer;

            public Strategy01(Form1 parent)
            {
                outer = parent;
            }

            public void Init()
            {
                filter01 = new Filter();
                observer01 = new Observer();
                group01 = new Group();
            }

            public void StartTrading()
            {
                //Filter filter = new Filter();
                // step 1 Filter the codelist
                var allCodesInfo = filter01.Start01();                                     // csv data filtering

                // step 2 Group the code list                                               // filtered csv data grouping; called from Filter.CsvToList()
                group01 = filter01.GroupProducer(allCodesInfo, 300);

                // step 3 observe one code of market items
                outer.filteredCodeList = observer01.Observe(group01);                   // Listen for the market ; use setrealreg() funceion to register code.

                /**************************************
                *****************************************/
                int length = outer.filteredCodeList.Count;
                outer.stockcodes = new StockCode[length];

                for (int i = 0; i< outer.filteredCodeList.Count; i++)
                {
                    outer.stockcodes[i] = new StockCode();
                }             
                /**************************************
                *****************************************/

                //outer.StartTrading();
                outer.Catch_Best_Condition(outer.filteredCodeList);
                // step 4 send buying signal
                // Send buying signal
            }

            // Filter the fundamental information of stocks, for example, 영업이익, 자본금, EPS from all the market stocks.
            public class Filter
            {
                List<CodeInfo> allCodesInfo;

                public List<CodeInfo> Start01()
                {
                    // csv file open into memory
                    string[] csv = File.ReadAllLines("first.txt");

                    // filter the csv file into List<class>
                    allCodesInfo = CsvToList(csv);
                    return allCodesInfo;
                }

                public List<CodeInfo> CsvToList(string[] csvLines)                    // filter to classList
                {
                    List<string> codeNum = new List<string>();
                    List<string> codeName = new List<string>();            // each value of each field from csv file.
                    List<string> month = new List<string>();            // each value of each field from csv file.
                    List<string> price = new List<string>();            // each value of each field from csv file.
                    List<string> capital = new List<string>();            // each value of each field from csv file.
                    allCodesInfo = new List<CodeInfo>();     // code object with fundamental information

                    for (int i = 0; i < csvLines.Length; i++)
                    {
                        string[] rowdata = csvLines[i].Split(',');

                        codeNum.Add(rowdata[0]);
                        codeName.Add(rowdata[1]);
                        month.Add(rowdata[2]);
                        price.Add(rowdata[3]);
                        capital.Add(rowdata[4]);

                        CodeInfo codeInfo = new CodeInfo(csvLines[i]);
                        allCodesInfo.Add(codeInfo);
                    }

                    return allCodesInfo;
                }
              
                public Group GroupProducer(List<CodeInfo> allInfo, int capitalCondition)
                {
                    var group01 = new Group();

                    group01.codeList = new List<string>();
                    group01.codeName = new List<string>();

                    foreach (CodeInfo codeInfo in allInfo)
                    {
                        //Console.WriteLine("how");
                        //Console.WriteLine(codeInfo.code);
                        if (codeInfo.capital == "자본금")          // csv header data skipped.
                            continue;
                        int num = int.Parse(codeInfo.capital);
                        if (num >= capitalCondition)
                        {
                            //Console.WriteLine(num);
                            string str = num.ToString();
                            group01.codeList.Add(codeInfo.code);
                            group01.codeName.Add(codeInfo.name);

                            Console.WriteLine("codeinfo");
                            Console.WriteLine("codeInfo.code : " + codeInfo.code);
                            Console.WriteLine("codeInfo.name : " + codeInfo.name);
                        }
                    }

                    return group01;
                }
            }

            // Information for each code
            public class CodeInfo
            {
                public string code;
                public string name;
                public string capital;
                public string volume;
                public string profit;

                public CodeInfo(string rowData)
                {
                    string[] rowInfo = rowData.Split(',');

                    this.code = rowInfo[0];
                    this.name = rowInfo[1];
                    this.capital = rowInfo[2];
                    this.volume = rowInfo[3];
                    this.profit = rowInfo[4];
                }
            }

            public class Group
            {
                public List<string> codeList = new List<string>();
                public List<string> codeName = new List<string>();

                public Group()
                {

                }

                public Group(List<string> codeList, List<string> codeName)
                {
                    this.codeList = codeList;
                    this.codeName = codeName;  
                }

                public class GroupType
                {

                }
            }

            public class Observer
            {
                public string second;
                public Form1 outer;             // outer class

                public Observer()
                {

                }

                public Observer(Form1 form1)
                {
                    outer = form1;
                }

                public List<string> Observe(Group group)
                {
                    Console.WriteLine("observing : group 01");

                    return group.codeList;
                }
            }

            private class Signal
            {
                public bool Sig { get; set; }

                public string Code { get; set; }
            }
        }

        // objects containing information about bottompoint
        public class BottomInfo
        {
            public string Name { set; get; }        // name of the bottompoint
            public bool Set { set; get; }           // Check if or not bottompoint is established.
            public int Location { set; get; }       // the location of the bottompoint in bottomPoints Array.
            public int Price { set; get; }          // the lowest price of the stock
        }

        // Items for Buying Order : for API.SendOrder
        public class Items_For_Buying
        {
            public string rqname;
            public string scrNum;
            public string accNum;
            public int orderType;
            public string itemCode;
            public int quantity;
            public int price;
            public string trType;
            public string ori_Num;
            public Items_For_Buying(string rqname, string scrNum, string accNum, int orderType, string itemCode, int quantity, int price, string tradingType, string ori_Num)
            {
                this.rqname = rqname;
                this.scrNum = scrNum;
                this.accNum = accNum;
                this.orderType = orderType;
                this.itemCode = itemCode;
                this.quantity = quantity;
                this.price = price;
                this.trType = tradingType;
                this.ori_Num = ori_Num;
            }
        }
    }

    class StockCode
    {
        public string code;
        public string codeName;
        public int[,] bottomPoints;                                       //container to contain bottom points and time to check the elapsed time.
        public int bLocation;                  // location of bottomPoints
        public int flag;                       // flag for bottomPoints
        public bool orderSent;                 // check if order is sent at the third bottom point.
        public double bottomFoundTime;
        public double currentTime;             // to compare the current time with elapsed time

       

        // Information about the all the lowest bottom points
        Form1.BottomInfo firstBottom;         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        Form1.BottomInfo secondtBottom;       // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        Form1.BottomInfo thirdBottom;         // objects containing information about bottompoint(ex: firstbottom, secondbottom, thirdbottom)
        List<Form1.BottomInfo> bottomsInfo;   // List that contains the information of all the bottoms

    }
}
