﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSVClass
{
    public partial class Form1 : Form
    {
        int rotate = 0;
        CsvClass csvObject; 
        //CsvClass csvObject02;


        public Form1()
        {
            InitializeComponent();
            csvObject = new CsvClass(this);
            Init();
            Test();            
        }

        public void Test()
        {
            DataTable dt = new DataTable();

            string[] files = Directory.GetFiles(@"C:\Users\user\Desktop\stock\strategy\server");
            foreach (string file in files)
            {
                Console.WriteLine(file);
                string[] csvStyle = File.ReadAllLines(file);
                dt = csvObject.CSVStyleToDataTable(csvStyle);
                bool result = csvObject.FilterDailyCandle(dt);
                Console.WriteLine(result);
            }
        }
        public void Test1()
        {
            string root = @"C:\Users\user\Desktop\stock\strategy\strategy";
            //string subdir = @"\strategy101";

            for (int i = 1; i <= 100; i++)
            {
                string subdir = root + i;

                if (!Directory.Exists(subdir))
                    Directory.CreateDirectory(subdir);

                subdir = "";
            }
            //Console.WriteLine(subdir);
        }

        public void Init()
        {
            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;
            loginButton.Click += Button_Click;

            //substep 1 :  send "setrealreg" function of codeList to the server.
            btnTrRQ.Click += Button_Click;
            btnRegister.Click += Button_Click;
            //btnSaveStockCode.Click += Button_Click;          // Save stock code and stock name to csv file
            btnSaveStockCode.MouseHover += Button_Enter;          // Save stock code and stock name to csv file
            btnFallFall.MouseHover += Button_Enter;          // Save stock code and stock name to csv file
            btnLongTail.MouseHover += Button_Enter;          // Save stock code and stock name to csv file

            // Sell All the stocks
            //btnSellAll.Click += Button_Click;
            //btnSellAll02.Click += Button_Click;

            // StockInfo to DataGridView
            //btnAccount.Click += Button_Click;

            // 미체결 주식
            //btnmissedStocks.Click += Button_Click;

            //Strategy Button
            //btnStrategy01.Click += StrButton_Click;

            // TabControl Event
            //tcAccount.SelectedIndexChanged += new EventHandler(Tabs_SelectedIndexChanged);
            //tcAccount.SelectedIndexChanged += Tabs_SelectedIndexChanged;

            // background event (system event) for real time data from Kiwoom Server.
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;
            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
            axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;
        }
        public void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            Console.WriteLine("Connected");
            int i = 0;
            // step 1 : Search the Stock code with the stock name.
            string str = axKHOpenAPI1.GetCodeListByMarket("0");
            str = str.TrimEnd(';');

            string rowData = "";

            
            string[] codeList = str.Split(';');
            string[] codeName = new string[codeList.Length];
            string[] csvStyleCode = new string[codeList.Length];

            foreach (string str02 in codeList)
            {
                codeName[i] = axKHOpenAPI1.GetMasterCodeName(str02);
                rowData = str02 + "," + codeName[i] + "\r\n";
                csvObject.CSVStyleToFile(@"C:\Users\user\Desktop\stock\strategy\strategy11Winds\strategy11Winds.txt", rowData);
                csvStyleCode[i] = rowData;
                Console.WriteLine(csvStyleCode[i]);
                i++;
            }

            Console.WriteLine(codeList.Length);
            // step 2 : register the name and code into the file.
        }
        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            if (e.sRQName == "SendAccount")
            {
                rotate++;

                Console.WriteLine("SendAccount");
                List<string> list = new List<string>() { "종목코드", "종목명", "보유수량" }; // FID item

                string[] list02 = csvObject.TRToCsvStyle(list, "opw00004", "SendAccount");


                //foreach (string str in list02)
                //{
                    //Console.WriteLine($"list02 : {str}");
                //}

                Console.WriteLine($"rotate : {rotate}");
                Console.WriteLine($"list02 num : {list02.Length}");

                DataTable dt = csvObject.CSVStyleToDataTable(list02);

                dgvAccount.DataSource = dt;

                //List<string> list03 = ExtractColumndata(list02, "종목코드");            // return column data from csvstyle data
                //List<string> list04 = new List<string>();

                //foreach (string code in list03)
                //{
                    //list04.Add(code.Remove(0, 1).Trim());
                //}
            }
            //
        }
        public void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {

        }
        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {

        }
        public void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
                axKHOpenAPI1.CommConnect();

            else if (sender.Equals(btnTrRQ))
                csvObject.AccountState("3380031111");

            else if (sender.Equals(btnRegister))
                csvObject.RegisterStockCode();
                //Console.WriteLine("Register");

        }
        public void Button_Enter(object sender, EventArgs e)
        {
            if (sender.Equals(btnSaveStockCode))
            {
                Console.WriteLine("enter");
                csvObject.UserInputToCSV(@"C:\Users\user\Desktop\strategy\", "strategyWinds.txt");
            }
            else if (sender.Equals(btnFallFall))
            {
                Console.WriteLine("enter");
                csvObject.UserInputToCSV(@"C:\Users\user\Desktop\strategy\", "straFallFall.txt");
            }
            else if (sender.Equals(btnLongTail))
            {
                Console.WriteLine("enter");
                csvObject.UserInputToCSV(@"C:\Users\user\Desktop\strategy\", "straLongTail.txt");
            }

        }

        private void PrintValues(DataTable table)               // print all values in datatable
        {
            foreach (DataRow row in table.Rows)
            {
                foreach (DataColumn column in table.Columns)
                {
                    Console.WriteLine(row[column]);
                }
            }
        }


    }

    class CsvClass
    {
        Form1 form1;
        public CsvClass()
        {

        }
        public CsvClass(Form1 form)
        {
            form1 = form;
        }
        public bool FilterDailyCandle(DataTable dt)         // return codelist which is passed against algorithm.
        {
            // step 1 : find mimimun value
            int count = dt.Rows.Count;
            int howmany = 10;

            string last = dt.Rows[count - 1][3].ToString();
            int lastPrice = int.Parse(last);

            string minimum = dt.Rows[count - 1][3].ToString();
            int minimumPrice = int.Parse(minimum);

            for (int i = 1; i <= howmany; i++)      // Compare new inpput value against minimumPrice. 
            {
                string str = dt.Rows[count - i][3].ToString();
                int val = int.Parse(str);

                if (minimumPrice > val)         //Change minimum value if new value is lower.
                {
                    minimumPrice = val;
                }
            }

            Console.WriteLine(minimumPrice);

            if (lastPrice <= minimumPrice)       // Comapare lastPrice with minimumPrice
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void RegisterStockCode()         // Register stock code from input with name.
        {
            string rowData = "";
            string input = form1.tbStockName.Text;

            // step 0 : check if the stock code and stock name is in the file.
            string[] fileToCheck = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\strategy11Winds\strWinds.txt");

            if (CheckStockCode(fileToCheck, input))
            {
                Console.WriteLine("already exist");
                return;
            }

            // step 1 : Search the Stock code with the stock name.
            string[] list = File.ReadAllLines(@"C:\Users\user\Desktop\stock\strategy\strategy11Winds\codeAndName.txt");

            string result = ExtractRowItem(list, input, "code");

            rowData = result + "," + input + "\r\n";

            // step 2 : register the name and code into the file.
            if (result == "")
            {
                Console.WriteLine("no no item");
                return;
            }
            else
            {
                File.AppendAllText(@"C:\Users\user\Desktop\stock\strategy\strategy11Winds\strWinds.txt", rowData);
                Console.WriteLine(@"코드가 입력되었습니다.C:\Users\user\Desktop\stock\\strategy\strategy11Winds");
            }
        }
        public bool CheckStockCode(string[] fileToCheck, string codeName)
        {
            foreach (string str in fileToCheck)
            {
                string[] splited02 = str.Split(',');
                foreach (string str05 in splited02)
                {
                    if (str05 == codeName)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public void AccountState(string accountNum)
        {
            //1. header part
            form1.axKHOpenAPI1.SetInputValue("계좌번호", accountNum);
            form1.axKHOpenAPI1.SetInputValue("비밀번호", "");
            form1.axKHOpenAPI1.SetInputValue("상장폐지조회구분", "0");
            form1.axKHOpenAPI1.SetInputValue("비밀번호입력매체구분", "00");
            //axKHOpenAPI1.SetInputValue("시간구분", "입력값 2");

            //2. body part
            form1.axKHOpenAPI1.CommRqData("SendAccount", "opw00004", 0, "5000");
        }

        public List<string> ControlsToMeMory()        //1. input from user
        {
            List<string> rowData = new List<string>();
            string str = form1.tbStockCode.Text;
            string str02 = form1.tbStockName.Text;

            rowData.Add(str);
            rowData.Add(str02);

            return rowData;
        }
        public string MemoryToCSVStyle(List<string> inputData)        //2. input data to csv style in memory
        {
            string row = "";
            foreach (string str in inputData)
                row = row + str + ",";

            row = row.Trim(',');
            row = row + "\r\n";
            return row;
        }
        public void CSVStyleToFile(string filePath, string str)        //3. csv style(NewLine) to csv file
        {
            File.AppendAllText(filePath, str);
        }
        public string[] TRToCsvStyle(List<string> getCommData, string orderCode, string rqName)         // Return csv-styled table data of string[] from OnReceiveTrData
        {
            List<string> csvStyle = new List<string>();     // csv style in memory.
            string csvStyleHeader = "";         // header
            string rowData = "";                // rowdata           

            //1. header part
            foreach (string item in getCommData)
            {
                csvStyleHeader = csvStyleHeader + $"{item},";
            }
            csvStyleHeader.Trim(',');
            csvStyle.Add(csvStyleHeader);

            //2. body part
            int count = form1.axKHOpenAPI1.GetRepeatCnt(orderCode, rqName);
            for (int i = 0; i < count; i++)
            {
                rowData = "";
                foreach (string item in getCommData)
                    rowData = rowData + form1.axKHOpenAPI1.GetCommData(orderCode, rqName, i, item).Trim() + ",";

                rowData.Trim(',');
                csvStyle.Add(rowData);
            }
            string[] csvType = csvStyle.ToArray();
            return csvType;
        }


        // Return DataTable from csv styled data to show into DataGridView ================
        public DataTable CSVStyleToDataTable(string[] csvStyleData)
        {
            DataTable dt = new DataTable();
            DataRow rowData;
            DataColumn column;

            string[] cellData;

            int j = 0;

            foreach (string line in csvStyleData)
            {
                cellData = line.Split(',');

                if (j == 0)
                {
                    for (int i = 0; i < cellData.Length; i++)
                    {
                        column = new DataColumn(i + " " + cellData[i]);
                        dt.Columns.Add(column);
                    }
                    j++;
                    continue;
                }

                rowData = dt.NewRow();

                for (int i = 0; i < cellData.Length; i++)
                {
                    rowData[i] = cellData[i];
                }

                dt.Rows.Add(rowData);

                j++;
            }
            // step 3 : Return DataTable object
            return dt;
        }
        public void UserInputToCSV(string filepath, string filename)        // from user input to csv file of stock code(stock name) of strategy.
        {
            string fullpath = filepath + filename;
            List<string> inputData = ControlsToMeMory();        //1. input from user
            string str = MemoryToCSVStyle(inputData);            //2. input data to csv style in memory
            CSVStyleToFile(fullpath, str);            //3. csv style(NewLine) to csv file
        }
        // Extract an row item with key word in the same rowdata.
        public string ExtractRowItem(string[] CSVStyle, string keyItem, string headerColumn)
        {
            int j = 0;
            int index = 0;
            string result = "";

            foreach (string str in CSVStyle)
            {
                string[] splited = str.Split(',');

                // header part : find index of headerColumn
                foreach (string header in splited)      // find index of headerColumn
                {
                    if (header == headerColumn)
                    {
                        index = j;
                        Console.WriteLine($"index : {index}");
                        break;
                    }

                    j++;
                }

                //2. body part
                foreach (string str03 in splited)
                {
                    if (str03 == keyItem)
                    {
                        result = splited[index];
                        break;
                    }
                }
            }
            //3. return
            return result;
        }
        public List<string> ExtractColumndata(string[] csvStyleData, string columnName)     // extract column data from csvstyle data
        {
            int j = 0;
            int index = 0;      // for column index
            List<string> columnData = new List<string>();

            foreach (string str in csvStyleData)
            {
                string[] items = str.Split(',');
                // header part
                if (j == 0)
                {
                    for (int i = 0; i < items.Length; i++)
                    {
                        if (items[i] == columnName)     // find the index of column asked of the columName
                        {
                            index = i;
                        }
                    }
                }
                // body part
                else
                {
                    for (int k = 0; k < items.Length; k++)
                    {
                        if (k == index)
                        {
                            columnData.Add(items[k]);
                        }
                    }
                }
                j++;
            }
            //3. return
            return columnData;
        }
    }

    // Algorithms for stock data.
    class CSVAlgorithm
    {

        public void VolumnSoaring()     // 거래량 증가 관련 알고리즘
        {
            // step 1 :  Reveive data from OnreceiveRealData
            // step 2 :  Distribute the data according to the stock code
            // step 3 :  Collect the data on each class.
            // step 4 :  check if the volumn is soaring.
            // step 5 :  return true if the volumn of data soaring
            // step 6 :  Send order of buying.
            // step 7 :  Send order of selling if bought.
            // step 8 :
            // step 9 :
            // step 10 :

        }
    }

    /************************
    // Template for making a function

        //Input : column name
        //output: string[] csvstyledata

        //Black Box

        public void ExtractColumndata()
        {
            //1. header part

            //2. body part

            //3. return
            return column data[];
        }
    ****************************/
}
