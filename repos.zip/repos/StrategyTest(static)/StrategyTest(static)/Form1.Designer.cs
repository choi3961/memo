﻿
namespace StrategyTest_static_
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.loginButton = new System.Windows.Forms.Button();
            this.realDataButton = new System.Windows.Forms.Button();
            this.logListBox = new System.Windows.Forms.ListBox();
            this.btnCapitalStr = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnProfitStr = new System.Windows.Forms.ComboBox();
            this.btnDebtPortionStr = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboTiming = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.combovolumn = new System.Windows.Forms.ComboBox();
            this.comboReserved = new System.Windows.Forms.ComboBox();
            this.btnSellAll = new System.Windows.Forms.Button();
            this.comboWave = new System.Windows.Forms.ComboBox();
            this.labelWave = new System.Windows.Forms.Label();
            this.btnStrategy05 = new System.Windows.Forms.Button();
            this.btnStrategy04 = new System.Windows.Forms.Button();
            this.btnStrategy03 = new System.Windows.Forms.Button();
            this.btnStrategy02 = new System.Windows.Forms.Button();
            this.btnStrategy01 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSeperation = new System.Windows.Forms.ComboBox();
            this.btnTailForm = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(1109, 484);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 0;
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(23, 37);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(119, 33);
            this.loginButton.TabIndex = 1;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            // 
            // realDataButton
            // 
            this.realDataButton.Location = new System.Drawing.Point(23, 90);
            this.realDataButton.Name = "realDataButton";
            this.realDataButton.Size = new System.Drawing.Size(119, 33);
            this.realDataButton.TabIndex = 2;
            this.realDataButton.Text = "SetRealReg";
            this.realDataButton.UseVisualStyleBackColor = true;
            // 
            // logListBox
            // 
            this.logListBox.FormattingEnabled = true;
            this.logListBox.ItemHeight = 12;
            this.logListBox.Location = new System.Drawing.Point(6, 322);
            this.logListBox.Name = "logListBox";
            this.logListBox.Size = new System.Drawing.Size(851, 160);
            this.logListBox.TabIndex = 3;
            // 
            // btnCapitalStr
            // 
            this.btnCapitalStr.FormattingEnabled = true;
            this.btnCapitalStr.Items.AddRange(new object[] {
            "1000",
            "2000",
            "3000",
            "4000",
            "5000",
            "6000",
            "7000",
            "8000",
            "9000",
            "10000"});
            this.btnCapitalStr.Location = new System.Drawing.Point(318, 92);
            this.btnCapitalStr.Name = "btnCapitalStr";
            this.btnCapitalStr.Size = new System.Drawing.Size(136, 20);
            this.btnCapitalStr.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(316, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 12);
            this.label1.TabIndex = 5;
            this.label1.Text = "Capital";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(477, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "Profit";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(641, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "Debt";
            // 
            // btnProfitStr
            // 
            this.btnProfitStr.FormattingEnabled = true;
            this.btnProfitStr.Items.AddRange(new object[] {
            "10",
            "20",
            "30",
            "40",
            "50",
            "60",
            "70",
            "80",
            "90",
            "100"});
            this.btnProfitStr.Location = new System.Drawing.Point(479, 92);
            this.btnProfitStr.Name = "btnProfitStr";
            this.btnProfitStr.Size = new System.Drawing.Size(136, 20);
            this.btnProfitStr.TabIndex = 8;
            // 
            // btnDebtPortionStr
            // 
            this.btnDebtPortionStr.FormattingEnabled = true;
            this.btnDebtPortionStr.Items.AddRange(new object[] {
            "50",
            "100",
            "200",
            "300",
            "400"});
            this.btnDebtPortionStr.Location = new System.Drawing.Point(643, 92);
            this.btnDebtPortionStr.Name = "btnDebtPortionStr";
            this.btnDebtPortionStr.Size = new System.Drawing.Size(136, 20);
            this.btnDebtPortionStr.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(317, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "Timing";
            // 
            // comboTiming
            // 
            this.comboTiming.FormattingEnabled = true;
            this.comboTiming.Items.AddRange(new object[] {
            "60",
            "120",
            "180",
            "240",
            "300",
            "360",
            "420",
            "490",
            "540",
            "600"});
            this.comboTiming.Location = new System.Drawing.Point(318, 248);
            this.comboTiming.Name = "comboTiming";
            this.comboTiming.Size = new System.Drawing.Size(88, 20);
            this.comboTiming.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.combovolumn);
            this.groupBox1.Controls.Add(this.comboReserved);
            this.groupBox1.Controls.Add(this.btnSellAll);
            this.groupBox1.Controls.Add(this.comboWave);
            this.groupBox1.Controls.Add(this.labelWave);
            this.groupBox1.Controls.Add(this.btnStrategy05);
            this.groupBox1.Controls.Add(this.btnStrategy04);
            this.groupBox1.Controls.Add(this.btnStrategy03);
            this.groupBox1.Controls.Add(this.btnStrategy02);
            this.groupBox1.Controls.Add(this.btnStrategy01);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.btnSeperation);
            this.groupBox1.Controls.Add(this.btnTailForm);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.comboTiming);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnDebtPortionStr);
            this.groupBox1.Controls.Add(this.btnProfitStr);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnCapitalStr);
            this.groupBox1.Controls.Add(this.logListBox);
            this.groupBox1.Controls.Add(this.realDataButton);
            this.groupBox1.Controls.Add(this.loginButton);
            this.groupBox1.Location = new System.Drawing.Point(11, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1081, 503);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(731, 233);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 28;
            this.label9.Text = "거래량";
            // 
            // combovolumn
            // 
            this.combovolumn.FormattingEnabled = true;
            this.combovolumn.Location = new System.Drawing.Point(733, 248);
            this.combovolumn.Name = "combovolumn";
            this.combovolumn.Size = new System.Drawing.Size(71, 20);
            this.combovolumn.TabIndex = 27;
            // 
            // comboReserved
            // 
            this.comboReserved.FormattingEnabled = true;
            this.comboReserved.Location = new System.Drawing.Point(166, 159);
            this.comboReserved.Name = "comboReserved";
            this.comboReserved.Size = new System.Drawing.Size(121, 20);
            this.comboReserved.TabIndex = 26;
            // 
            // btnSellAll
            // 
            this.btnSellAll.Location = new System.Drawing.Point(23, 150);
            this.btnSellAll.Name = "btnSellAll";
            this.btnSellAll.Size = new System.Drawing.Size(119, 30);
            this.btnSellAll.TabIndex = 25;
            this.btnSellAll.Text = "일괄매도";
            this.btnSellAll.UseVisualStyleBackColor = true;
            // 
            // comboWave
            // 
            this.comboWave.FormattingEnabled = true;
            this.comboWave.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
            this.comboWave.Location = new System.Drawing.Point(412, 249);
            this.comboWave.Name = "comboWave";
            this.comboWave.Size = new System.Drawing.Size(84, 20);
            this.comboWave.TabIndex = 24;
            // 
            // labelWave
            // 
            this.labelWave.AutoSize = true;
            this.labelWave.Location = new System.Drawing.Point(421, 231);
            this.labelWave.Name = "labelWave";
            this.labelWave.Size = new System.Drawing.Size(35, 12);
            this.labelWave.TabIndex = 23;
            this.labelWave.Text = "Wave";
            // 
            // btnStrategy05
            // 
            this.btnStrategy05.Location = new System.Drawing.Point(888, 246);
            this.btnStrategy05.Name = "btnStrategy05";
            this.btnStrategy05.Size = new System.Drawing.Size(97, 23);
            this.btnStrategy05.TabIndex = 22;
            this.btnStrategy05.Text = "Strategy05";
            this.btnStrategy05.UseVisualStyleBackColor = true;
            // 
            // btnStrategy04
            // 
            this.btnStrategy04.Location = new System.Drawing.Point(888, 203);
            this.btnStrategy04.Name = "btnStrategy04";
            this.btnStrategy04.Size = new System.Drawing.Size(97, 23);
            this.btnStrategy04.TabIndex = 21;
            this.btnStrategy04.Text = "Strategy04";
            this.btnStrategy04.UseVisualStyleBackColor = true;
            // 
            // btnStrategy03
            // 
            this.btnStrategy03.Location = new System.Drawing.Point(888, 163);
            this.btnStrategy03.Name = "btnStrategy03";
            this.btnStrategy03.Size = new System.Drawing.Size(97, 23);
            this.btnStrategy03.TabIndex = 20;
            this.btnStrategy03.Text = "Strategy03";
            this.btnStrategy03.UseVisualStyleBackColor = true;
            // 
            // btnStrategy02
            // 
            this.btnStrategy02.Location = new System.Drawing.Point(888, 118);
            this.btnStrategy02.Name = "btnStrategy02";
            this.btnStrategy02.Size = new System.Drawing.Size(97, 23);
            this.btnStrategy02.TabIndex = 19;
            this.btnStrategy02.Text = "WindsStrategy";
            this.btnStrategy02.UseVisualStyleBackColor = true;
            // 
            // btnStrategy01
            // 
            this.btnStrategy01.Location = new System.Drawing.Point(888, 78);
            this.btnStrategy01.Name = "btnStrategy01";
            this.btnStrategy01.Size = new System.Drawing.Size(97, 23);
            this.btnStrategy01.TabIndex = 18;
            this.btnStrategy01.Text = "Strategy01";
            this.btnStrategy01.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(334, 192);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(176, 21);
            this.label8.TabIndex = 17;
            this.label8.Text = "Dynamic Strategy";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(334, 39);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 21);
            this.label7.TabIndex = 16;
            this.label7.Text = "Static Strategy";
            // 
            // btnSeperation
            // 
            this.btnSeperation.FormattingEnabled = true;
            this.btnSeperation.Location = new System.Drawing.Point(643, 249);
            this.btnSeperation.Name = "btnSeperation";
            this.btnSeperation.Size = new System.Drawing.Size(66, 20);
            this.btnSeperation.TabIndex = 15;
            // 
            // btnTailForm
            // 
            this.btnTailForm.FormattingEnabled = true;
            this.btnTailForm.Location = new System.Drawing.Point(529, 248);
            this.btnTailForm.Name = "btnTailForm";
            this.btnTailForm.Size = new System.Drawing.Size(71, 20);
            this.btnTailForm.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(641, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 13;
            this.label6.Text = "이격도";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(536, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "TailForm";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1221, 562);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.axKHOpenAPI1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Button realDataButton;
        public System.Windows.Forms.ListBox logListBox;
        private System.Windows.Forms.ComboBox btnCapitalStr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox btnProfitStr;
        private System.Windows.Forms.ComboBox btnDebtPortionStr;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.ComboBox comboTiming;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox btnSeperation;
        private System.Windows.Forms.ComboBox btnTailForm;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnStrategy05;
        private System.Windows.Forms.Button btnStrategy04;
        private System.Windows.Forms.Button btnStrategy03;
        private System.Windows.Forms.Button btnStrategy02;
        private System.Windows.Forms.Button btnStrategy01;
        public System.Windows.Forms.ComboBox comboWave;
        private System.Windows.Forms.Label labelWave;
        private System.Windows.Forms.Button btnSellAll;
        private System.Windows.Forms.ComboBox comboReserved;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox combovolumn;
    }
}

