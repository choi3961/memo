﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BuyOrderSellOrderTest
{
    public partial class Form1 : Form
    {
        int screenNumber = 1000;

        public Form1()
        {
            InitializeComponent();

            Init();      
        }

        public void Init()
        {
            loginButton.Click += Button_Click;

            // Sell Test
            btnReserved.Click += Button_Click;

            // Sell Test
            btnSellTest.Click += Button_Click;

            // Sell all the stocks
            //btnSellAll.Click += Button_Click;

            //substep 1 :  send "setrealreg" function of codeList to the server.
            //realDataButton.Click += Button_Click;

            // background event (system event) for real time data from Kiwoom Server.
            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;
            axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;

            //axKHOpenAPI1.OnReceiveRealData += API_OnReceiveRealData;
            //axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;

        }

        public void SendOrder_Buy()
        {
            int result = axKHOpenAPI1.SendOrder("매수주문", "1001", "8008765411", 1, "000020", 1, 20000, "03", null);

            if (result == 0)
            {
                Console.WriteLine("매수 주문 요청 성공");
            }
        }

        public void SendOrder_Sell()
        {
            Console.WriteLine("selling test");

            int re = axKHOpenAPI1.SendOrder("매도주문", "1003", "8008765411", 2, "000400", 1, 0, "03", null);
            if (re == 0)
            {
                Console.WriteLine("매도..주문 성공");
            }
        }

        //Sell All the stocks in once.
        public void SellAllStocks(List<string> stockcodes)
        {
            for (int i = 0; i<stockcodes.Count; i++)
            {
                Console.WriteLine($"sell a stock {i}, {stockcodes[i]}, {GetScreenNumber()}");

                int result = axKHOpenAPI1.SendOrder("매도주문", GetScreenNumber(), "8008765411", 2, stockcodes[i], 1, 0, "03", null);     //("매도주문", GetScreenNumber(), "8008765411", 2, stockcodes[i], 1, 0, "03", null);

                if (result != 0)
                {
                    Console.WriteLine(result);
                }
                Thread.Sleep(300);
            }
            
        }

        public void Login()
        {
            int j = axKHOpenAPI1.CommConnect();

            if (j == 0)
            {
                Console.WriteLine("Login success");
            }
        }

        public void Set_RealReg()
        {
            Console.WriteLine("real data button");
            string codeList = "";

            char[] toTrim = { ';' };
            codeList = codeList.TrimEnd(toTrim);

            Console.WriteLine("codeList : " + codeList);

            int result = axKHOpenAPI1.SetRealReg("1001", codeList, "9001;10", "0");      // Register "item code list" for real time data from Kiwoom Server               
            if (result == 0)
            {
                Console.WriteLine("setRealReg 요청 성공");
            }
            else
            {
                Console.WriteLine("주식기본 정보 요청에 실패하였습니다.");
            }
        }

        public string GetScreenNumber()
        {
            if (screenNumber == 9999)
            {
                screenNumber = 1001;
            }
            screenNumber++;

            string str = screenNumber.ToString();

            return str;
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
            {
                Login();
            }

            // Sell Test
            else if (sender.Equals(btnSellTest))
            {
                SendOrder_Sell();
            }

            // sell all the stocks 
            //else if (sender.Equals(btnSellAll))
            //{
                //SellAllStocks();
            //}

            // send "SetRealReg"
            else if (sender.Equals(realDataButton))
            {
                Set_RealReg();
            }

            // check reserved stocks
            else if (sender.Equals(btnReserved))
            {
                // 계좌 평가 현황 요청      // Invoke OnReceiveTrData()
                axKHOpenAPI1.SetInputValue("계좌번호", "8008765411");
                axKHOpenAPI1.SetInputValue("비밀번호", "");
                axKHOpenAPI1.SetInputValue("상장폐지조회구분", "");
                axKHOpenAPI1.SetInputValue("비밀번호입력매체구분", "");
                axKHOpenAPI1.CommRqData("계좌평가현황", "OPW00004", 0, "1000");       // Invoke OnReceiveTrData()
            }
        }

        public void API_OnReceiveMsg(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            Console.WriteLine(e.sMsg);
            Console.WriteLine($"value : {e.ToString()}");
        }
        public void API_OnReceiveRealData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveRealDataEvent e)
        {
            SendOrder_Buy();
        }

        public void API_OnReceiveTrData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            int stockCount = 0;      // 종목수
            Console.WriteLine("Tr data received");
            string str = axKHOpenAPI1.GetCommData("opw00004", "주식평가현황", 0, "예탁자산평가액");

            Console.WriteLine($"str : {str}");

            int count = axKHOpenAPI1.GetRepeatCnt("opw00004", "계좌평가현황요청");

            Console.WriteLine($"{count} found");

            // if 게좌평가현황요청일 경우

            if (e.sRQName == "계좌평가현황")
            {
                Console.WriteLine("++++++++++++주문 : 계좌평가현황");

                List<string> stocks = new List<string>();

                for (int i = 0; i < count; i++)
                {
                    string code = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, i, "종목코드");

                    code = code.Remove(0, 1).Trim();

                    Console.WriteLine(code);

                    comboReserved.Items.Add(code);
                    stocks.Add(code);

 

                    Thread.Sleep(300);
                    stockCount = i;
                }

                Console.WriteLine($"{stockCount} Finished");

                // Sell all the stocks
                SellAllStocks(stocks);

            }


            // if 매도 주문일 경우

            else if (e.sRQName == "매도주문")
            {
                Console.WriteLine("++++++++++++주문 : 매도주문");
            }

            //e.

 
            
        }

        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            //logListBox.Items.Add("e.nitemCnt : " + e.nItemCnt);
            //logListBox.Items.Add("e.sFIdList : " + e.sFIdList);
            //logListBox.Items.Add("e.sGubun : " + e.sGubun);

            if (e.sGubun.Equals("0"))       // 접수 or 체결
            {
                string account = axKHOpenAPI1.GetChejanData(9201);
                string orderNumber = axKHOpenAPI1.GetChejanData(9203);
                string orderState = axKHOpenAPI1.GetChejanData(913);        // 접수 or 체결

                if (orderState.Equals("접수"))
                {
                    logListBox.Items.Add("접수 호출");
                }

                else if (orderState.Equals("체결"))
                {
                    logListBox.Items.Add("체결 호출");
                    string str = axKHOpenAPI1.GetChejanData(910);
                    string code = axKHOpenAPI1.GetChejanData(9001);
                    string distinguish = axKHOpenAPI1.GetChejanData(906);
                    code = code.Remove(0, 1);

                    Console.WriteLine($"매매구분 : {distinguish}");
                    //send_selling_order  here
                    //SendOrder_Sell(code, str);
                }

                logListBox.Items.Add("Jesus");
            }

            else if (e.sGubun.Equals("1"))  // 잔고
            {

            }

            else if (e.sGubun.Equals("4"))  // 파생잔고
            {

            }
        }
    }
}


