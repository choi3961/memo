﻿
namespace BuyOrderSellOrderTest
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axKHOpenAPI1 = new AxKHOpenAPILib.AxKHOpenAPI();
            this.loginButton = new System.Windows.Forms.Button();
            this.realDataButton = new System.Windows.Forms.Button();
            this.logListBox = new System.Windows.Forms.ListBox();
            this.btnSellAll = new System.Windows.Forms.Button();
            this.btnSellTest = new System.Windows.Forms.Button();
            this.comboReserved = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnReserved = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).BeginInit();
            this.SuspendLayout();
            // 
            // axKHOpenAPI1
            // 
            this.axKHOpenAPI1.Enabled = true;
            this.axKHOpenAPI1.Location = new System.Drawing.Point(675, 375);
            this.axKHOpenAPI1.Name = "axKHOpenAPI1";
            this.axKHOpenAPI1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axKHOpenAPI1.OcxState")));
            this.axKHOpenAPI1.Size = new System.Drawing.Size(100, 50);
            this.axKHOpenAPI1.TabIndex = 0;
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(47, 12);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(110, 34);
            this.loginButton.TabIndex = 1;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            // 
            // realDataButton
            // 
            this.realDataButton.Location = new System.Drawing.Point(47, 150);
            this.realDataButton.Name = "realDataButton";
            this.realDataButton.Size = new System.Drawing.Size(110, 38);
            this.realDataButton.TabIndex = 2;
            this.realDataButton.Text = "SetRealReg";
            this.realDataButton.UseVisualStyleBackColor = true;
            // 
            // logListBox
            // 
            this.logListBox.FormattingEnabled = true;
            this.logListBox.ItemHeight = 12;
            this.logListBox.Location = new System.Drawing.Point(34, 271);
            this.logListBox.Name = "logListBox";
            this.logListBox.Size = new System.Drawing.Size(535, 124);
            this.logListBox.TabIndex = 3;
            // 
            // btnSellAll
            // 
            this.btnSellAll.Location = new System.Drawing.Point(47, 106);
            this.btnSellAll.Name = "btnSellAll";
            this.btnSellAll.Size = new System.Drawing.Size(110, 38);
            this.btnSellAll.TabIndex = 4;
            this.btnSellAll.Text = "SellAllInOnce";
            this.btnSellAll.UseVisualStyleBackColor = true;
            // 
            // btnSellTest
            // 
            this.btnSellTest.Location = new System.Drawing.Point(47, 52);
            this.btnSellTest.Name = "btnSellTest";
            this.btnSellTest.Size = new System.Drawing.Size(101, 48);
            this.btnSellTest.TabIndex = 5;
            this.btnSellTest.Text = "SellTest";
            this.btnSellTest.UseVisualStyleBackColor = true;
            // 
            // comboReserved
            // 
            this.comboReserved.FormattingEnabled = true;
            this.comboReserved.Location = new System.Drawing.Point(268, 57);
            this.comboReserved.Name = "comboReserved";
            this.comboReserved.Size = new System.Drawing.Size(119, 20);
            this.comboReserved.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(266, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "보유종목";
            // 
            // btnReserved
            // 
            this.btnReserved.Location = new System.Drawing.Point(405, 55);
            this.btnReserved.Name = "btnReserved";
            this.btnReserved.Size = new System.Drawing.Size(94, 23);
            this.btnReserved.TabIndex = 8;
            this.btnReserved.Text = "보유종목조회";
            this.btnReserved.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnReserved);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboReserved);
            this.Controls.Add(this.btnSellTest);
            this.Controls.Add(this.btnSellAll);
            this.Controls.Add(this.logListBox);
            this.Controls.Add(this.realDataButton);
            this.Controls.Add(this.loginButton);
            this.Controls.Add(this.axKHOpenAPI1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axKHOpenAPI1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxKHOpenAPILib.AxKHOpenAPI axKHOpenAPI1;
        private System.Windows.Forms.Button loginButton;
        private System.Windows.Forms.Button realDataButton;
        private System.Windows.Forms.ListBox logListBox;
        private System.Windows.Forms.Button btnSellAll;
        private System.Windows.Forms.Button btnSellTest;
        private System.Windows.Forms.ComboBox comboReserved;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnReserved;
    }
}

