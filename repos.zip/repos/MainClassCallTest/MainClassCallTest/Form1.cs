﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainClassCallTest
{
    public partial class Form1 : Form
    {
        Stock first;


        public Form1()
        {
            InitializeComponent();

            sendOrderbtn.Click += ButtonClick;
            axKHOpenAPI1.OnReceiveChejanData += API_OnReceiveChejanData;
            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;

            first = new Stock(this);

            first.Second01();

            
        }

        public void Second02()
        {
            Console.WriteLine("hello This is Second02");
        }

        public void ButtonClick(object sender, EventArgs e)
        {
            first.SendOrder();         
        }

        public void API_OnReceiveChejanData(object sendeer, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            Console.WriteLine("접수 또는 체결 성공");
        }

        public void API_OnReceiveMsg(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            Console.WriteLine("주문 Msg");
        }
    }

    public class Stock
    {
        Form1 form01;

        public Stock()
        {

        }
        
        public Stock(Form1 form)
        {
            form01 = form;
        }

        public void Second01()
        {
            form01.Second02();

            form01.axKHOpenAPI1.CommConnect();
        }

        public void SendOrder()
        {
            int result = form01.axKHOpenAPI1.SendOrder("주식주문", "1001", "8008765411", 1, "000020", 1, 20000, "03", null);

            if (result == 0)
            {
                Console.WriteLine("주문 요청 성공");
            }
        }
    }
}


/********int result = form01.axKHOpenAPI1.SendOrder("주식주문", "1001", "8008765411", 1, "000020", 1, 20000, "03", null);*********/