﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TRDataRequest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            trRequestButton.Click += Button_Click;
            button2.Click += Button_Click;
            axKHOpenAPI1.OnEventConnect += API_OneventConnect;

            axKHOpenAPI1.CommConnect();
        }

        private void Button_Click(object sender, EventArgs e)
        {
            
            if (sender.Equals(trRequestButton))
            {
                Console.WriteLine("TR Request");
                string code = codeTextBox.Text;
                axKHOpenAPI1.SetInputValue("종목코드", code);
                int result = axKHOpenAPI1.CommRqData("주식기본정보요쳥", "opt10001", 0, "1001");

                if (result == 0 )
                {
                    Console.WriteLine("종목조회 요청 성공");
                    axKHOpenAPI1.OnReceiveTrData += API_OnReceiveTrData;
                }

                
            }

            else if (sender.Equals(button2))
            {
                Console.WriteLine("button2 clicked");
            }
        }

        private void API_OnReceiveTrData(object sendeer, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveTrDataEvent e)
        {
            Console.WriteLine(e.sPrevNext); 
            Console.WriteLine(e.sRecordName); 
            Console.WriteLine(e.sRQName); 
            Console.WriteLine(e.sScrNo); 
            Console.WriteLine(e.sTrCode);

            string itmeCode = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "종목코드").Trim();
            string itmeName = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "종목명").Trim();
            string price = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "현재가").Trim();
            string changeRate = axKHOpenAPI1.GetCommData(e.sTrCode, e.sRQName, 0, "등락율").Trim();

            Console.WriteLine(itmeCode);
            Console.WriteLine(itmeName);
            Console.WriteLine(price);
            Console.WriteLine(changeRate);
        }


        private void API_OneventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            if (e.nErrCode == 0)
            {
                // Login seccess
                Console.WriteLine("Login Seccess");

            }
            else
            {
                Console.WriteLine("Login failed");
            }
        }
    }
}
