﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Send_Order
{
    public partial class Form1 : Form
    {
        int screenNum = 1000;
        public Form1()
        {
            InitializeComponent();
            loginButton.Click += ButtonClick;
            orderButton.Click += ButtonClick;

            axKHOpenAPI1.OnEventConnect += API_OnEventConnect;

            axKHOpenAPI1.OnReceiveMsg += API_OnReceiveMsg;

            //axKHOpenAPI1.OnReceiveChejanData


            //SendOrder();
        }

        public void SendOrder()
        {
            int a = axKHOpenAPI1.CommConnect();
            Console.WriteLine("Jesus");
            //Send_Order_Buying("주식주문", "1000", "8008765411", 1, "000020", 1,10000, "03", null);

            if (a == 0)
            {
                Console.WriteLine("로그인 성공");
                int result = axKHOpenAPI1.SendOrder("주식주문","1001","8008765411",10,"000020",1,10000,"00","");
                Console.WriteLine("result : " + result);
            }                 
        }

        private void Send_Order_Buying(string rqname, string scrNum, string accNum, int orderType, string itemCodee, int quantity, int price, string trType, string ori_Num)
        {
            // Create an object of "items for buying order
            //items = new Items_For_Buying("주식주문", "1001", "8008765411", 1, "000020", 1, 10000, "03", null);

            // Send order to the server
            int result = axKHOpenAPI1.SendOrder(rqname, scrNum, accNum, orderType, itemCodee, quantity, price, trType, ori_Num);
            //int result = axKHOpenAPI1.SendOrder(items.rqname, items.scrNum, items.accNum, items.orderType, items.itemCode, items.quantity, items.price, items.trType, items.ori_Num);
            if (result == 0)       // 요청성공
            {
                Console.WriteLine("주문요청 성공");
            }
            else    // sendOrder failed
            {
            }

            // Calls the Selling order if a stock is bought.
            if (true)       // if bought
            {
                //Send_Order_Selling();
            }
            else
            {
                //waiting...
            }
        }

        private void ButtonClick(object sender, EventArgs e)
        {
            if (sender.Equals(loginButton))
            {
                logListBox.Items.Add("로그인 버튼 클릭");
                axKHOpenAPI1.CommConnect();
            }
            

            else if (sender.Equals(orderButton))
            {
                logListBox.Items.Add("주문 버튼 클릭");
                string orderType = orderTypeComboBox.Text;
                string itemCode = ItemCodeTextBox.Text;
                int orderTypeNum = OrderTypeCode(orderType);
                int quantity = (int)quantityNumericUpDown.Value;
                int price = (int)priceNumericUpDown.Value;
                string tradingType = TradingTypeComboBox.Text;
                string originalNumber = orderNumberTextBox.Text;

                int result = axKHOpenAPI1.SendOrder("주식주문", GetScreenNumber(), accountComBoBox.Text, orderTypeNum, itemCode, quantity, price, TradingTypeCode(tradingType), originalNumber );
                if (result == 0)
                {
                    logListBox.Items.Add("주문 요청 성공");
                }
                else
                {
                    logListBox.Items.Add("주문 요청 실패");
                }

                Console.WriteLine("orderTypeNum : " + orderTypeNum);
            }
        }

        private void API_OnEventConnect(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnEventConnectEvent e)
        {
            if (e.nErrCode ==0) 
            {
                string accountList = axKHOpenAPI1.GetLoginInfo("ACCLIST");
                accountList = accountList.Trim(new char[] { ';'});
                string[] accountArray = accountList.Split(';');

                for (int i = 0; i < accountArray.Length; i++)
                {
                    accountComBoBox.Items.Add(accountArray[i]);
                }
            }
        }

        private void API_OnReceiveMsg(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveMsgEvent e)
        {
            string msg = e.sMsg;
            string rqName = e.sRQName;
            string screenNumber = e.sScrNo;
            string trCode = e.sTrCode;

            logListBox.Items.Add("OnReceiveMsg() - " + "msg : " + msg + "rqName : " + rqName + "screenNumber : " + screenNum + "trCode : " + trCode);
        }

        private void API_OnReceiveChejanData(object sender, AxKHOpenAPILib._DKHOpenAPIEvents_OnReceiveChejanDataEvent e)
        {
            logListBox.Items.Add("e.nitemCnt : " + e.nItemCnt);
            logListBox.Items.Add("e.sFIdList : " + e.sFIdList);
            logListBox.Items.Add("e.sGubun : " + e.sGubun);

            if (e.sGubun.Equals("0"))       // 접수 or 체결
            {
                string account = axKHOpenAPI1.GetChejanData(9201);
                string orderNumber = axKHOpenAPI1.GetChejanData(9203);
                string orderState = axKHOpenAPI1.GetChejanData(913);        // 접수 or 체결

                if (orderState.Equals("접수"))
                {
                    logListBox.Items.Add("접수 호출");
                }

                else if (orderState.Equals("체결"))
                {
                    logListBox.Items.Add("체결 호출");
                }

                logListBox.Items.Add("Jesus");
            }

            else if (e.sGubun.Equals("1"))  // 잔고
            {

            }

            else if (e.sGubun.Equals("4"))  // 파생잔고
            {

            }

        }

        private string GetScreenNumber()
        {
            if (screenNum >= 9999)
                screenNum = 1000;

            screenNum++;

            return screenNum.ToString();
        }

        private int OrderTypeCode(string orderType)
        {
            switch(orderType)
            {
                case "신규매수":
                    return 1;
                case "신규매도":
                    return 2;
                case "매수취소":
                    return 3;
                case "매도취소":
                    return 4;
                case "매수정정":
                    return 5;

                case "매도정정":
                    return 6;

                default:
                    return -1;

            }

        }

        private string TradingTypeCode(string tradingType)
        {
            switch (tradingType)
            {
                case "지정가":
                    return "00";
                case "시장가":
                    return "03";
                case "조건부지정가":
                    return "05";

                default:
                    return "";

            }

        }

    }
}
