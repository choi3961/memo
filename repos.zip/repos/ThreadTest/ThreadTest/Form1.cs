﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThreadTest
{
    public partial class Form1 : Form
    {
        int i = 0;

        public Form1()
        {
            InitializeComponent();

            Thread thread1 = new Thread(ThreadWork.DoWork);
            thread1.Start();
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("In main.");
                //Thread.Sleep(100);
            }

        }
    }

    public class ThreadWork
    {
        public static void DoWork()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Working thread...");
                //Thread.Sleep(100);
            }
        }
    }
}
