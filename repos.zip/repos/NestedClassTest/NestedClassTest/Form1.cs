﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NestedClassTest
{
    public partial class Form1 : Form
    {
        Test first01;
        Test first02;

        public Form1()
        {
            InitializeComponent();
            //Test01();

            first01 = new Test();
            first02 = new Test(this);


            first01.Trade();
            first02.Trade03();
            //first.


        }

        public void Test01()
        {
            Console.WriteLine("testing...");
        }

        public void Test03()
        {
            Console.WriteLine("Test03");
        }





        public class Test
        {
            private Form1 dog;

            public Test()
            {

            }

            public Test(Form1 cat)
            {
                this.dog = cat;

                //dog.ToString();

            }

            public void Trade03()
            {
                dog.Test03();
            }

            public void Trade()
            {
                Console.WriteLine("Trading...");
            }
        }
    }
}
